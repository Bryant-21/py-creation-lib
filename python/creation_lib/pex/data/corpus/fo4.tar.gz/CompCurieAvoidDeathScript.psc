Scriptname CompCurieAvoidDeathScript Extends ActiveMagicEffect

Float Property PercentHealth Auto
globalvariable Property PerkAvoidDeathTimer Auto
globalvariable Property GameDaysPassed Auto
actorvalue Property Health Auto Const
spell Property HealSpell Auto

Event OnEffectStart(actor akTarget, actor akCaster)
EndEvent
