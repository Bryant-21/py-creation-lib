Scriptname DefaultAliasOnTriggerEnter Extends DefaultAlias

Bool Property PlayerTriggerOnly Auto
referencealias[] Property TriggeredByAliases Auto
objectreference[] Property TriggeredByReferences Auto
faction[] Property TriggeredByFactions Auto

Event OnTriggerEnter(objectreference akActionRef)
EndEvent
