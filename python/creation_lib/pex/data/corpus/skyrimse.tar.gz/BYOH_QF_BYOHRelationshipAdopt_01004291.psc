Scriptname BYOH_QF_BYOHRelationshipAdopt_01004291 Extends Quest

referencealias Property Alias_ConstanceMichel Auto

Function Fragment_2() Native
Function Fragment_5() Native
String Function GetState() Native
Function GotoState(String newState) Native
