Scriptname DefaultAliasParent Extends ReferenceAlias

Int Property StageToSet Auto
Bool Property xxxPlaceHolderForEmptyGroup_LocationToCheckxxx Auto
Bool Property DoOnce Auto
Bool Property SkipBusyState Auto
Bool Property ShowTraces Auto
Bool Property FailOnDeadActor Auto
conditionform Property ConditionFormToTest Auto
Int Property PrereqStage Auto
Int Property TurnOffStage Auto
Int Property TurnOffStageDone Auto
Bool Property xxxPlaceHolderForEmptyGroupxxx Auto
Bool Property xxxPlaceHolderForEmptyGroup_RefToCheckxxx Auto

Function CheckAndSetStageAndCallDoSpecificThing(defaultscriptfunctions:parentscriptfunctionparams ParentScriptFunctionParams) Native
Function DoSpecificThing(defaultscriptfunctions:parentscriptfunctionparams ParentScriptFunctionParams, objectreference RefToDoThingWith, Bool LastRefToDoThingWith) Native
referencealias[] Function GetAliasesToCheckAgainst() Native
faction[] Function GetFactionsToCheckAgainst() Native
locationalias[] Function GetLocationAliasesToCheckAgainst() Native
Bool Function GetLocationMatchIfChild() Native
location[] Function GetLocationsToCheckAgainst() Native
Bool Function GetPlayerOnly() Native
objectreference[] Function GetReferencesToCheckAgainst() Native
objectreference[] Function GetRefsToDoSpecificThingsWith() Native
Function RegisterOnHitFilters() Native
