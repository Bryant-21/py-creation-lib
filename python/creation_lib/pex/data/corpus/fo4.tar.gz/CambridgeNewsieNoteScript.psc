Scriptname CambridgeNewsieNoteScript Extends ObjectReference

ObjectReference Property DiamondCityMapMarkerRef Auto Const

Event onRead()
EndEvent
