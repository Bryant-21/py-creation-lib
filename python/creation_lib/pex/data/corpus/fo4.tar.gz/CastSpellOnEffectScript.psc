Scriptname CastSpellOnEffectScript Extends ActiveMagicEffect

spell Property OnEffectSpell Auto Const

Event OnEffectStart(actor akTarget, actor akCaster)
EndEvent
