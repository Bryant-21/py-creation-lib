Scriptname CGNukeFXControlScript Extends ObjectReference

soundcategorysnapshot Property CSChargenNuke Auto
globalvariable Property TrailerGlobal Auto Const
sound Property CGNukeFlashSound Auto Const
ObjectReference Property ShockwaveFXRef Auto Const
imagespacemodifier Property FadeOutImod Auto Const
ObjectReference Property NukeLocationRef Auto Const
weather Property NukeWeatherClearFog Auto Const
imagespacemodifier Property WaveHitImod Auto Const
sound Property CGNukeShockwave Auto Const
explosion Property NukeExplosionRef Auto Const
globalvariable Property TimescaleGlobal Auto
imagespacemodifier Property CGNukeImageSpaceLong Auto Const
ObjectReference Property ElevatorRef Auto Const

CustomEvent CGShockWaveAnimEvent

Function NukeBlast() Native
Event OnAnimationEvent(ObjectReference akSource, String asEventName)
EndEvent

Event OnCellDetach()
EndEvent

Event OnTimer(Int aiTimerID)
EndEvent
