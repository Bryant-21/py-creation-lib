Scriptname BoSPrimeButtonScript Extends ObjectReference

quest Property BoS304 Auto
sound Property mySound Auto
quest Property BoS301 Auto

Event OnActivate(ObjectReference akActionRef)
EndEvent
