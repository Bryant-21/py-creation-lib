Scriptname BoSVBAliasBoardingScript Extends ReferenceAlias

globalvariable Property BoardingGlobal Auto Const
quest Property QuestCheck Auto Const
Int Property QuestCheckStage Auto Const
ReferenceAlias Property Alias_Vertibird Auto Const
ReferenceAlias Property Alias_QuestPassenger Auto Const
globalvariable Property OptionalConditionalGlobal Auto Const

Event OnActivate(objectreference akActionRef)
EndEvent
