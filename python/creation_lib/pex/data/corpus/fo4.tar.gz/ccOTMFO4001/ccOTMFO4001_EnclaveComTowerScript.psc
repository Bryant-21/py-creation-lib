Scriptname ccOTMFO4001:ccOTMFO4001_EnclaveComTowerScript Extends ObjectReference

quest Property ccOTMFO4001_Quest Auto Const
Float Property MaxDaysForRespawn Auto Const
String Property AnimationOn Auto Const
Bool Property StartsOn Auto Const
globalvariable Property ActiveStateGlobal Auto Const
message Property ccOTMFO4001_EnclaveComTowerOffMessage Auto Const
Float Property MinDaysForRespawn Auto Const
message Property ccOTMFO4001_EnclaveComTowerOnMessage Auto Const
String Property AnimationOff Auto Const
keyword Property ccOTMFO4001_EnclaveComTowerLink Auto Const

Function OnActivate(ObjectReference akActionRef) Native
Function OnCellAttach() Native
Function OnCellDetach() Native
Function OnInit() Native
Function TryToPrepareForRespawn() Native
