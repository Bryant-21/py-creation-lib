Scriptname DefaultTopicInfo Extends TopicInfo

Bool Property ShowTraces Auto
quest Property QuestToSetStageOn Auto
Int Property TurnOffStageDone Auto
Int Property TurnOffStage Auto
Int Property StageToSet Auto
Int Property PrereqStage Auto

Function TryToSetStage() Native
