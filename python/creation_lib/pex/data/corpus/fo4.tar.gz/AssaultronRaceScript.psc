Scriptname AssaultronRaceScript Extends ActiveMagicEffect

keyword Property LinkAssaultronPad Auto

Event OnActivate(objectreference akActionRef)
EndEvent

Event OnEffectStart(actor akTarget, actor akCaster)
EndEvent
