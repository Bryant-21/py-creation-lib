Scriptname CryopodLever01SpouseScript Extends ReferenceAlias

ReferenceAlias Property SpouseCryopod Auto

Event OnActivate(objectreference akActionRef)
EndEvent

Event OnClose(objectreference akActionRef)
EndEvent

Event OnOpen(objectreference akActionRef)
EndEvent
