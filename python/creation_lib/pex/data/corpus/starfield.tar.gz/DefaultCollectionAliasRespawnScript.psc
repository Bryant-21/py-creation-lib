Scriptname DefaultCollectionAliasRespawnScript Extends RefCollectionAlias

Bool Property RespawningOn Auto

Event OnDeath(objectreference akSenderRef, objectreference akKiller)
EndEvent
