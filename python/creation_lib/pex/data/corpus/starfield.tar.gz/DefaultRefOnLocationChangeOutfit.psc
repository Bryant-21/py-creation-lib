Scriptname DefaultRefOnLocationChangeOutfit Extends Actor

Struct OutfitChange
    location NewLocation
    outfit ChangeToOutfit
    location OldLocation
EndStruct

outfitchange[] Property OutfitChangeList Auto

Event OnLocationChange(location akOldLoc, location akNewLoc)
EndEvent
