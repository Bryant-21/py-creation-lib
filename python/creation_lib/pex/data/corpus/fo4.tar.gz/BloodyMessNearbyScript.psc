Scriptname BloodyMessNearbyScript Extends ActiveMagicEffect

Float Property ChanceDismember Auto

Event OnEffectStart(actor akTarget, actor akCaster)
EndEvent
