Scriptname CA_DB_Event13 Extends ca_dialoguebump_basescript

Function InitializeEventID() Native
