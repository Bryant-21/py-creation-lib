Scriptname DefaultAliasReadWhileSittingScript Extends ReferenceAlias

idle Property IdleBookReadStart Auto Const
package[] Property ReadingPackages Auto Const

Event OnSit(objectreference akFurniture)
EndEvent
