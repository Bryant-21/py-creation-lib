Scriptname DefaultQuestDistanceCheckScript Extends Quest

Struct DistanceCheckStage
    Int TurnOffStage
    Int PrereqStage
    Bool DistanceLessThan
    Float TargetDistance
    referencealias TargetAlias
    Int StageToSet
EndStruct

distancecheckstage[] Property DistanceCheckStages Auto

Function CheckDistanceStages(Bool bDistanceLessThan, objectreference theRef) Native
Event OnDistanceGreaterThan(objectreference akObj1, objectreference akObj2, Float afDistance, Int aiEventID)
EndEvent

Event OnDistanceLessThan(objectreference akObj1, objectreference akObj2, Float afDistance, Int aiEventID)
EndEvent

Event OnQuestInit()
EndEvent

Function OnStageSet(Int auiStageID, Int auiItemID) Native
Function RegisterForDistanceCheck(distancecheckstage theDistanceCheck, objectreference targetRef) Native
