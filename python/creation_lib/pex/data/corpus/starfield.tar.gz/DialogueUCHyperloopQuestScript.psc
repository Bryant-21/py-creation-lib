Scriptname DialogueUCHyperloopQuestScript Extends Quest

Int Property DepartureLocation Auto
referencealias Property Speaker_Spaceport Auto
Int Property ArrivalLocation Auto

Function UpdateDeparture() Native
