Scriptname CommonArrayFunctions Extends ScriptObject

Bool Function CheckActorAgainstFactionArray(actor ObjectToCheck, faction[] ArrayToCheck, Bool returnValueIfArrayIsEmpty = false) Global Native
Bool Function CheckFormAgainstArray(form FormToCheck, form[] ArrayToCheck, Bool returnValueIfArrayIsEmpty = false) Global Native
Bool Function CheckFormAgainstKeywordArray(form ObjectToCheck, keyword[] ArrayToCheck, Bool returnValueIfArrayIsEmpty = false) Global Native
Bool Function CheckLocationAgainstArray(location ObjectToCheck, location[] ArrayToCheck, location LocationToCheckIsDifferent = false, Bool returnValueIfArrayIsEmpty = false, Bool matchIfChildLocation) Global Native
Bool Function CheckLocationAgainstLocationAliasArray(location ObjectToCheck, locationalias[] ArrayToCheck, location LocationToCheckIsDifferent = false, Bool returnValueIfArrayIsEmpty = false, Bool matchIfChildLocation) Global Native
Bool Function CheckObjectAgainstKeywordArray(objectreference ObjectToCheck, keyword[] ArrayToCheck, Bool returnValueIfArrayIsEmpty = false) Global Native
Bool Function CheckObjectReferenceAgainstArray(objectreference ObjectToCheck, objectreference[] ArrayToCheck, Bool returnValueIfArrayIsEmpty = false) Global Native
Bool Function CheckObjectReferenceAgainstReferenceAliasArray(objectreference ObjectToCheck, referencealias[] ArrayToCheck, Bool returnValueIfArrayIsEmpty = false) Global Native
actor[] Function CopyActorArray(actor[] input) Global Native
actor[] Function CopyAndRandomizeActorArray(actor[] input) Global Native
objectreference[] Function CopyAndRandomizeObjArray(objectreference[] input) Global Native
objectreference[] Function CopyObjArray(objectreference[] input) Global Native
Int Function FindInReferenceAliasArray(objectreference ObjectToCheck, referencealias[] ArrayToCheck) Global Native
actor[] Function GetActorArrayFromAliasArray(referencealias[] AliasArrayToGetActorsFrom) Global Native
objectreference[] Function GetAllRefsInTriggers(objectreference[] triggers) Global Native
Int Function GetCountAliveStateFromAliasArray(referencealias[] AliasArrayToCheck, Bool CheckAlive) Global Native
Int Function GetCountAliveStateFromArray(actor[] ArrayToCheck, Bool CheckAlive) Global Native
Int Function GetCountLoadedAndAliveStateFromAliasArray(referencealias[] AliasArrayToCheck, Bool Check3DLoaded, Bool CheckAlive) Global Native
Int Function GetCountLoadedAndAliveStateFromArray(actor[] ArrayToCheck, Bool Check3DLoaded, Bool CheckAlive) Global Native
Int Function GetCountLoadedStateFromAliasArray(referencealias[] AliasArrayToCheck, Bool Check3DLoaded) Global Native
Int Function GetCountLoadedStateFromArray(objectreference[] ArrayToCheck, Bool Check3DLoaded) Global Native
faction Function GetFirstFoundFactionInArrayForActor(actor ActorToCheck, faction[] ArrayToCheck) Global Native
keyword Function GetFirstFoundKeywordInArrayForLocation(location LocationToCheck, keyword[] ArrayToCheck) Global Native
Int Function GetRandomIndex(Int ArrayLength) Global Native
Int[] Function GetRandomizedIndexes(Int ArrayLength) Global Native
refcollectionalias[] Function GetRefCollectionAliasesFromAliasArray(alias[] ArrayOfVariousTypesOfAliases) Global Native
referencealias[] Function GetReferenceAliasesFromAliasArray(alias[] ArrayOfVariousTypesOfAliases) Global Native
objectreference[] Function GetReferenceArrayFromAliasArray(referencealias[] AliasArrayToGetActorsFrom) Global Native
objectreference[] Function GetReferencesFromAliasArray(alias[] ArrayOfVariousTypesOfAliases) Global Native
objectreference[] Function GetReferencesWithMatchingKeyword(objectreference[] ArrayOfRefsToCheck, keyword KeywordToMatch) Global Native
Bool Function IsActorInArrayHostileToActor(actor ActorToCheck, objectreference[] ArrayToCheck) Global Native
objectreference[] Function SortRefsByValue(objectreference[] input, actorvalue sortAV) Global Native
