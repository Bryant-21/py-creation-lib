Scriptname CA_SkillMagazineScript Extends ObjectReference

keyword Property CA_Event_ReadSkillBook Auto Const

Event OnActivate(ObjectReference akActionRef)
EndEvent
