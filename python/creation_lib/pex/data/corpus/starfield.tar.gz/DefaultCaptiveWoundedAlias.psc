Scriptname DefaultCaptiveWoundedAlias Extends ReferenceAlias

globalvariable Property SQ_WoundedState_2_Healed Auto
faction Property WoundedFaction Auto
actorvalue Property SQ_WoundedState Auto
Bool Property DeleteWhenCleanedUp Auto
Bool Property RemoveFromFactions Auto
Int Property StageToSetOnCleanUp Auto
Int Property StageToSetWhenHealed Auto
globalvariable Property SQ_WoundedState_0_Unset Auto
Bool Property AlsoRemoveFromCaptiveFaction Auto
Bool Property DisableOnUnload Auto
Bool Property StartWounded Auto
keyword Property SQ_Captive_FurnitureType_Wounded Auto
keyword Property SQ_Wounded_DialogueSubtype_HealedActorGratitude Auto
faction Property CaptiveFaction Auto
sq_captivescript Property SQ_Captive Auto
keyword Property SQ_Link_CaptiveFurniture Auto
quest Property QuestToSet Auto
globalvariable Property SQ_WoundedState_1_Wounded Auto

Function AddToFactions() Native
Function CleanupIfReady() Native
Function ClearFactions() Native
Function HealActor(Bool playerIsHealer) Native
Function OnAliasChanged(objectreference akObject, Bool abRemove) Native
Function OnAliasInit() Native
Function OnAliasShutdown() Native
Function OnLoad() Native
Function OnUnload() Native
Function RemoveFromCaptiveFactionIfNeeded() Native
Function ResetAVs() Native
Function SetState() Native
