Scriptname DefaultAliasOnActivate Extends DefaultAlias

Bool Property BlockWhilePlayerIsInCombat Auto Const
faction[] Property ActivatedByFactions Auto Const
Bool Property PlayerActivateOnly Auto Const
message Property CombatNoActivate Auto Const
Bool Property BlockWhilePlayerIsSitting Auto Const
objectreference[] Property ActivatedByReferences Auto Const
message Property PowerArmorNoActivate Auto Const
referencealias[] Property ActivatedByAliases Auto Const
Bool Property BlockWhilePlayerIsInPowerArmor Auto Const

Event OnActivate(objectreference akActionRef)
EndEvent
