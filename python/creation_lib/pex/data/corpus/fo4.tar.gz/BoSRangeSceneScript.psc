Scriptname BoSRangeSceneScript Extends Quest

Event OnTimerGameTime(Int aiTimerID)
EndEvent

Function SetRangeSceneTimer() Native
