Scriptname DefaultRefDamageSpaceshipOnLoad Extends SpaceshipReference

Struct ActorValueDatum
    actorvalue ActorValueToDamage
    Float DamagePercent
EndStruct

sq_parentscript Property SQ_Parent Auto
sq_parentscript:actorvaluedatum[] Property AdditionalActorValuesToDamage Auto
Bool Property ShouldBlockRepairOfDestroyedParts Auto
Bool Property ShouldDisableExteriorLights Auto
Bool Property ShouldDamageRandomSystems Auto
Bool Property ShouldBeDestroyed Auto
Bool Property ShouldApplyDerelictName Auto
Bool Property ShouldBeDerelict Auto

Function OnLoad() Native
