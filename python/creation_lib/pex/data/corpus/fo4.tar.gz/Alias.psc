Scriptname Alias Extends ScriptObject

quest Function GetOwningQuest() Native
Event OnAliasInit()
EndEvent

Event OnAliasReset()
EndEvent

Event OnAliasShutdown()
EndEvent

Function StartObjectProfiling() Native
Function StopObjectProfiling() Native
