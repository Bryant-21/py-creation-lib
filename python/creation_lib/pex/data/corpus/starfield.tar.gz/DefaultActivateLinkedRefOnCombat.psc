Scriptname DefaultActivateLinkedRefOnCombat Extends DefaultActor

Bool Property ActivatorIsRefToCheck Auto
Bool Property ShouldUseLinkedRefChain Auto
keyword Property LinkedRefKeyword Auto
Int Property CombatStateToCheckFor Auto
Bool Property IncludeOnHitEvent Auto
Bool Property xxxPlaceHolderForEmptyGroup2xxx Auto

Function CombatStateChangedOrHit(objectreference TargetOrAggressor) Native
Function DoSpecificThing(defaultscriptfunctions:parentscriptfunctionparams ParentScriptFunctionParams, objectreference RefToDoThingWith, Bool LastRefToDoThingWith) Native
objectreference[] Function GetRefsToDoSpecificThingsWith() Native
Function OnCombatStateChanged(objectreference akTarget, Int aeCombatState) Native
Function OnHit(objectreference akTarget, objectreference akAggressor, form akSource, projectile akProjectile, Bool abPowerAttack, Bool abSneakAttack, Bool abBashAttack, Bool abHitBlocked, String asMaterialName) Native
Function OnLoad() Native
Function OnUnload() Native
