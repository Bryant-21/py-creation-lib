Scriptname BFBdragonFlyoverSCRIPT Extends objectReference

quest Property BFBquest Auto
objectReference Property BFBdragon Auto
objectReference Property dragonsEnabled Auto
objectReference Property initialPosition Auto

String Function GetState() Native
Function GotoState(String newState) Native
Function OnTriggerEnter(objectReference actronaut) Native
Function OnTriggerLeave(objectReference actronaut) Native
