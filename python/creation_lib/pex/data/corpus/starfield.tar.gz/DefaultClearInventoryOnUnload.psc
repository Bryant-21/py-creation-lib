Scriptname DefaultClearInventoryOnUnload Extends ObjectReference

Function OnUnload() Native
