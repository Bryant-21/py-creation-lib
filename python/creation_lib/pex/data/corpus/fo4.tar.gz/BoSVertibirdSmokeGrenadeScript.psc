Scriptname BoSVertibirdSmokeGrenadeScript Extends ObjectReference

message Property VFTDispatchMessage Auto Const
keyword Property BoSVertibirdGrenadeKW Auto Const
message Property VFTNoLandingMessage Auto Const
globalvariable Property BoSFastTravelCanUse Auto Const
quest Property VFT Auto Const
message Property VFTInProgressMessage Auto Const

Event OnInit()
EndEvent
