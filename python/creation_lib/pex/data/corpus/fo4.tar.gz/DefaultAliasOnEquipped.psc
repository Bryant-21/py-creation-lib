Scriptname DefaultAliasOnEquipped Extends DefaultAlias

Bool Property PlayerEquippedOnly Auto Const
objectreference[] Property EquippedByReferences Auto Const
referencealias[] Property EquippedByAliases Auto Const
faction[] Property EquippedByFactions Auto Const

Event OnEquipped(actor akActor)
EndEvent
