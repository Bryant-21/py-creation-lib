Scriptname CZPostQuestScript Extends Quest

Quest Property myQuest Auto Const
location Property CombatZoneLocation Auto Const

Event OnTimerGameTime(Int aiTimerID)
EndEvent

Function SetPostQuestTimer() Native
