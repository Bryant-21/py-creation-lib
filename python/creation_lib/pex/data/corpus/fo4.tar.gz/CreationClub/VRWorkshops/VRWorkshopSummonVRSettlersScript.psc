Scriptname CreationClub:VRWorkshops:VRWorkshopSummonVRSettlersScript Extends Quest

actorvalue Property WorkshopBellDistance Auto
referencealias Property Alias_SummonMarker Auto
refcollectionalias Property Alias_WorkshopNPCs Auto
Int Property StartupStage Auto
workshopparentscript Property WorkshopParent Auto
referencealias Property Alias_Workshop Auto
Bool Property IsAlarm Auto

Event OnStageSet(Int auiStageID, Int auiItemID)
EndEvent

Event OnTimerGameTime(Int aiTimerID)
EndEvent

Function StartUp() Native
