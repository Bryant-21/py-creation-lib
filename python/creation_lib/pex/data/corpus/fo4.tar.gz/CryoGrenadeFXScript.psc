Scriptname CryoGrenadeFXScript Extends ObjectReference

Int Property flyForceApplied Auto
Float Property rndAngleRange Auto

Event OnLoad()
EndEvent

Event OnTimer(Int aiTimerID)
EndEvent
