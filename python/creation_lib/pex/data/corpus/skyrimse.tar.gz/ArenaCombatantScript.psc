Scriptname ArenaCombatantScript Extends ReferenceAlias

String Function GetState() Native
Function GotoState(String newState) Native
Function OnDying(actor akKiller) Native
Function OnEnterBleedout() Native
Function OnInit() Native
Function TellMainQuestImDown() Native
