Scriptname blackreachExitElevatorScript Extends ObjectReference

globalvariable Property ElevatorPoweredVariable Auto

String Function GetState() Native
Function GotoState(String newState) Native
Function onActivate(ObjectReference akActivator) Native
Function OnInit() Native
