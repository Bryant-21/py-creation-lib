Scriptname DefaultEnableAliasesQuestScript Extends Quest

Struct AliasEnableDatum
    alias AliasToEnable
    Int StageToEnable
EndStruct

aliasenabledatum[] Property AliasEnableData Auto

Function EnableAliasByStage(Int EnableStage) Native
Function OnQuestStarted() Native
Function OnStageSet(Int auiStageID, Int auiItemID) Native
