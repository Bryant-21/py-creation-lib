Scriptname AbLegendaryScript Extends ActiveMagicEffect

Bool Property PoweredUp Auto
sound Property PowerUpSound Auto
message Property LegendaryPowerUpMsg Auto
Float Property HealthThreshhold Auto
actorvalue Property Health Auto
spell Property LegendaryPowerUp Auto

Event OnEffectFinish(actor akTarget, actor akCaster)
EndEvent

Event OnEffectStart(actor akTarget, actor akCaster)
EndEvent

Event OnHit(objectreference akTarget, objectreference akAggressor, form akSource, projectile akProjectile, Bool abPowerAttack, Bool abSneakAttack, Bool abBashAttack, Bool abHitBlocked, String apMaterial)
EndEvent
