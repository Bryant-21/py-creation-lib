Scriptname CCT_StayInBleedoutEffectScript Extends ActiveMagicEffect

Float Property IgnoreHitsTimeSeconds Auto

Function OnEffectStart(objectreference akTarget, actor akCaster, magiceffect akBaseEffect, Float afMagnitude, Float afDuration) Native
Function OnHit(objectreference akTarget, objectreference akAggressor, form akSource, projectile akProjectile, Bool abPowerAttack, Bool abSneakAttack, Bool abBashAttack, Bool abHitBlocked, String asMaterialName) Native
Function OnTimer(Int aiTimerID) Native
