Scriptname DefaultEmptyInvIntoLinkOnLoad Extends ObjectReference

Event OnLoad()
EndEvent
