Scriptname DBTestPCMAIScript Extends Quest

refcollectionalias Property FoundPackins Auto
Int Property AtTargetLocationStage Auto
scene Property DBTestPCMAI_InvestigatePackinScene Auto
referencealias Property NearbyPackin Auto

Bool Function CheckForNearbyPackin() Native
Function OnQuestInit() Native
Function OnTimer(Int aiTimerID) Native
