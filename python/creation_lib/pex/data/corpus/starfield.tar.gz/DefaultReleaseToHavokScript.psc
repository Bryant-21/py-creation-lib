Scriptname DefaultReleaseToHavokScript Extends ObjectReference

keyword Property LinkHavokPartner Auto
Bool Property ReleaseAllLinkedHavokPartners Auto
Bool Property HavokOnHit Auto
Bool Property HavokOnActivate Auto

Function OnActivate(ObjectReference triggerRef) Native
Function OnHit(ObjectReference akTarget, ObjectReference akAggressor, form akSource, projectile akProjectile, Bool abPowerAttack, Bool abSneakAttack, Bool abBashAttack, Bool abHitBlocked, String apMaterial) Native
Function OnLoad() Native
Function ReleaseToHavok() Native
