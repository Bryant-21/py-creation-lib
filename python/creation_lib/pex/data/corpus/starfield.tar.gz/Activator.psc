Scriptname Activator Extends Form

Bool Function IsRadio() Native
