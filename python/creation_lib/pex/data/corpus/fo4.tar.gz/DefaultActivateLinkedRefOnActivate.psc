Scriptname DefaultActivateLinkedRefOnActivate Extends ObjectReference

Bool Property ShowTraces Auto
objectreference[] Property ActivatedByReferences Auto
faction[] Property ActivatedByFactions Auto
referencealias[] Property ActivatedByAliases Auto
keyword Property LinkedRefKeyword Auto
Bool Property DoOnce Auto
Bool Property PlayerActivatedOnly Auto

Event OnActivate(ObjectReference akActionRef)
EndEvent
