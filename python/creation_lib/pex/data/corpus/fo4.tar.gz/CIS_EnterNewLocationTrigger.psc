Scriptname CIS_EnterNewLocationTrigger Extends ObjectReference

keyword Property CIS_ENL_Keyword Auto Const

Event OnTriggerEnter(ObjectReference akActionRef)
EndEvent
