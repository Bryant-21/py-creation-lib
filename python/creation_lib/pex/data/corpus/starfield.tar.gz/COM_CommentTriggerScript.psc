Scriptname COM_CommentTriggerScript Extends ObjectReference

sq_companionsscript Property SQ_Companions Auto
affinityevent Property AffinityEventToSend Auto
conditionform Property COM_CND_Comment_CommentsAllowed Auto
Bool Property OncePerCompanion Auto
keyword Property COM_CommentTriggerStart Auto

Bool Function IsCompanionOrPlayerInCombat() Native
Function OnTriggerEnter(ObjectReference akActionRef) Native
Function OnUnload() Native
Function SendAffinityEvent(companionactorscript CompanionActorRef, ObjectReference TargetRef) Native
Function StartCommentSceneQuest() Native
Bool Function Trace(ScriptObject CallingObject, String asTextToPrint, Int aiSeverity, String MainLogName, String SubLogName, Bool bShowNormalTrace, Bool bShowWarning, Bool bPrefixTraceWithLogNames) Native
Bool Function warning(ScriptObject CallingObject, String asTextToPrint, Int aiSeverity, String MainLogName, String SubLogName, Bool bShowNormalTrace, Bool bShowWarning, Bool bPrefixTraceWithLogNames) Native
