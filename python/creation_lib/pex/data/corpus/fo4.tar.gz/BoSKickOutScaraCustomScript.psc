Scriptname BoSKickOutScaraCustomScript Extends ReferenceAlias

globalvariable Property BoSLiSlain Auto
quest Property BoS301 Auto
quest Property BoSKickOut Auto

Event OnDying(actor akKiller)
EndEvent
