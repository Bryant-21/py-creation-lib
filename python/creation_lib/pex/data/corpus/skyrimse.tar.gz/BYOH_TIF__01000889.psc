Scriptname BYOH_TIF__01000889 Extends TopicInfo

favordialoguescript Property DialogueFavorGeneric Auto

Function Fragment_0(ObjectReference akSpeakerRef) Native
String Function GetState() Native
Function GotoState(String newState) Native
