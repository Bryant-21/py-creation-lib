Scriptname BoSPoliceStationChangeLocationScript Extends ReferenceAlias

quest Property BoSScene_PoliceStation Auto
Int Property iStageToSet Auto
ReferenceAlias Property PASoldier Auto
ReferenceAlias Property FieldScribe Auto
location Property CambridgePDLocation Auto
Int Property iPrereqStage Auto

Event OnLocationChange(location akOldLoc, location akNewLoc)
EndEvent
