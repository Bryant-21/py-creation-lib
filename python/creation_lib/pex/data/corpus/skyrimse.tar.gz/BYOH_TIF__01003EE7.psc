Scriptname BYOH_TIF__01003EE7 Extends TopicInfo

referencealias Property HjaalmarchHouse Auto

Function Fragment_0(ObjectReference akSpeakerRef) Native
String Function GetState() Native
Function GotoState(String newState) Native
