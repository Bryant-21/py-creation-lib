Scriptname ccBGSFO4116:TerminalSelectScript Extends Terminal

quest Property MyQuest Auto Const

Function OnMenuItemRun(Int auiMenuItemID, objectreference akTerminalRef) Native
