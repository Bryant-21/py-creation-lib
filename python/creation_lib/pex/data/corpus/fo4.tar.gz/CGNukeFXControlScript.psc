Scriptname CGNukeFXControlScript Extends ObjectReference

soundcategorysnapshot Property CSChargenNuke Auto
globalvariable Property TrailerGlobal Auto
sound Property CGNukeFlashSound Auto
ObjectReference Property ShockwaveFXRef Auto
imagespacemodifier Property FadeOutImod Auto
ObjectReference Property NukeLocationRef Auto
weather Property NukeWeatherClearFog Auto
imagespacemodifier Property WaveHitImod Auto
sound Property CGNukeShockwave Auto
explosion Property NukeExplosionRef Auto
globalvariable Property TimescaleGlobal Auto
imagespacemodifier Property CGNukeImageSpaceLong Auto
ObjectReference Property ElevatorRef Auto

Function NukeBlast() Native
Event OnAnimationEvent(ObjectReference akSource, String asEventName)
EndEvent

Event OnCellDetach()
EndEvent

Event OnTimer(Int aiTimerID)
EndEvent
