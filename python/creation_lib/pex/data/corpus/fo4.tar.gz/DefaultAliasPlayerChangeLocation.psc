Scriptname DefaultAliasPlayerChangeLocation Extends DefaultAlias

Bool Property EnteringIgnoreIfNewLocIsChild Auto
Bool Property LeavingIgnoreIfNewLocIsChild Auto
locationalias[] Property LeavingOneOfTheseAliases Auto
location[] Property LeavingOneOfTheseLocations Auto
Bool Property LeavingIgnoreIfOldLocIsChild Auto
Bool Property EnteringIgnoreIfOldLocIsChild Auto
locationalias[] Property EnteringOneOfTheseAliases Auto
location[] Property EnteringOneOfTheseLocations Auto

Event OnLocationChange(location akOldLoc, location akNewLoc)
EndEvent
