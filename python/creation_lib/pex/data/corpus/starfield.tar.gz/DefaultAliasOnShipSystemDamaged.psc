Scriptname DefaultAliasOnShipSystemDamaged Extends ReferenceAlias

Struct SystemDamageStage
    Int TurnOffStage
    Int PrereqStage
    Bool SetStageOnlyFromNormalDamage
    Int StageToSet
    Bool SetStageOnlyWhenFullyDamaged
    actorvalue TargetSystem
EndStruct

Bool Property ShowTraces Auto
Int Property TurnOffStageDone Auto
systemdamagestage[] Property SystemDamageStages Auto
Int Property TurnOffStage Auto
Int Property PrereqStage Auto

Function OnShipSystemDamaged(actorvalue akSystem, Int aBlocksLost, Bool aElectromagneticDamage, Bool aFullyDamaged) Native
