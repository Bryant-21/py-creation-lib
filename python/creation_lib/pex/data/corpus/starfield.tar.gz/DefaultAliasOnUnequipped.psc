Scriptname DefaultAliasOnUnequipped Extends DefaultAlias

Function OnEquipped(actor akActor) Native
