Scriptname CZToggleButtonScript Extends ObjectReference

globalvariable Property CZLift2Active Auto
Bool Property shouldAutoReset Auto
Bool Property IsLiftOne Auto
String Property inactiveStateAnimation Auto
globalvariable Property CZLift1Active Auto
message Property ToggleButtonInactiveMessage Auto
dn134questscript Property DN134 Auto
Bool Property playerActivationOnly Auto
String Property animationName Auto
String Property activeStateAnimation Auto

Function CheckIfShouldBeActive() Native
Event OnActivate(ObjectReference akActionRef)
EndEvent

Event OnBeginState(String asOldState)
EndEvent

Event OnLoad()
EndEvent

Event OnUnload()
EndEvent

Function SetBusy(Bool shouldBeBusy, Bool returnToActive = True) Native
