Scriptname BoSR03PlayerScript Extends ReferenceAlias

alias Property BoSR03Squire Auto
quest Property BoSR03 Auto
location Property PrydwenLocation Auto

Event OnLocationChange(location akOldLoc, location akNewLoc)
EndEvent
