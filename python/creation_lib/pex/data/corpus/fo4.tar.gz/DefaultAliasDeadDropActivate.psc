Scriptname DefaultAliasDeadDropActivate Extends DefaultAlias

Bool Property BlockWhilePlayerIsInCombat Auto
objectreference[] Property ActivatedByReferences Auto
Bool Property PlayerActivateOnly Auto
message Property DeadDropMessage Auto
referencealias[] Property ActivatedByAliases Auto
faction[] Property ActivatedByFactions Auto

Event OnActivate(objectreference akActionRef)
EndEvent
