Scriptname DeaconUnloadScript Extends Actor

Int Property nStage Auto Const
quest Property qQuest Auto Const

Event OnUnload()
EndEvent
