Scriptname DefaultPlayAnimationOnLoadScript Extends ObjectReference

String Property AnimationToPlay Auto
Bool Property PlayAnimationOnlyOnce Auto

Function OnLoad() Native
