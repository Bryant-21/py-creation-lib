Scriptname CompanionGivePlayerItemInfoScript Extends TopicInfo

Event OnBegin(objectreference akSpeakerRef, Bool abHasBeenSaid)
EndEvent
