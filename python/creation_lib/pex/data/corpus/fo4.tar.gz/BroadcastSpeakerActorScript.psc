Scriptname BroadcastSpeakerActorScript Extends Actor

keyword Property LinkedRefBroadcastSpeaker Auto Const
objectreference[] Property SpeakerRefs Auto Const

Function ToggleSpeakers(Bool ShouldTurnOn = True) Native
