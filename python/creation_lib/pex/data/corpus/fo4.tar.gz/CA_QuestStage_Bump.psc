Scriptname CA_QuestStage_Bump Extends Quest

Struct QuestStageBumpDatum
    Int EventID
    Int QuestStage
EndStruct

queststagebumpdatum[] Property QuestStageBumpData Auto

Event OnInit()
EndEvent

Event OnStageSet(Int auiStageID, Int auiItemID)
EndEvent
