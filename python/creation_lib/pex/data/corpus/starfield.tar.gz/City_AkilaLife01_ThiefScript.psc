Scriptname City_AkilaLife01_ThiefScript Extends ReferenceAlias

quest Property City_AkilaLife01 Auto

Function OnHit(objectreference akTarget, objectreference akAggressor, form akSource, projectile akProjectile, Bool abPowerAttack, Bool abSneakAttack, Bool abBashAttack, Bool abHitBlocked, String apMaterial) Native
Function OnLoad() Native
