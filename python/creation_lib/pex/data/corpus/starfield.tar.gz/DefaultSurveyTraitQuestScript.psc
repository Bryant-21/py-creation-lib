Scriptname DefaultSurveyTraitQuestScript Extends Quest

Struct PlanetTraitData
    globalvariable discoverCountRequired
    keyword PlanetTrait
    globalvariable discoverCountCurrent
    Int ObjectiveToUpdate
    Int StageToSet
    Bool traitFound
EndStruct

Int Property PlanetTraitsCompleteStage Auto
keyword Property LocTypeStarSystem Auto
planettraitdata[] Property PlanetTraits Auto
keyword Property LocTypeMajorOrbital Auto
locationalias Property TargetSystemLocation Auto
locationalias Property TargetPlanetLocation Auto
sq_parentscript Property SQ_Parent Auto

Function HandlePlanetTraitEvent(Var[] akArgs, Bool isDiscoveredEvent) Native
Function OnQuestInit() Native
