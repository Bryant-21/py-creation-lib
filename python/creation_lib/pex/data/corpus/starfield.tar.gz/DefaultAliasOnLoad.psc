Scriptname DefaultAliasOnLoad Extends DefaultAliasParent

Event OnLoad()
EndEvent
