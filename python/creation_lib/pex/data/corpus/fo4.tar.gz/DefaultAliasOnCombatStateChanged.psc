Scriptname DefaultAliasOnCombatStateChanged Extends DefaultAlias

Int Property CombatStateToCheckFor Auto Const
referencealias[] Property TargetIsOneOfTheseAliases Auto Const
faction[] Property TargetIsOneOfTheseFactions Auto Const
objectreference[] Property TargetIsOneOfTheseReferences Auto Const

Event OnCombatStateChanged(actor akTarget, Int aeCombatState)
EndEvent
