Scriptname CreationClub:VRWorkshops:VRWorkshopAttackEnemyRefScript Extends RefCollectionAlias

RefCollectionAlias Property AttackEnemiesRefCol Auto Const
Int Property ObjectiveComplete Auto Const
quest Property VRAttackQuest Auto Const
Int Property StageHostilesCleared Auto Const
sound Property TeleportSound Auto Const
effectshader Property HologramShaunFXS Auto Const
effectshader Property TeleportInFXS Auto Const
effectshader Property TeleportOutFXS Auto Const

Event OnDying(objectreference akSender, actor akKiller)
EndEvent

Event OnLoad(objectreference akSender)
EndEvent

Function RemoveEnemyFromRefCollection(objectreference enemyToRemove) Native
