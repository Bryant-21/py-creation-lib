Scriptname ccFSVFO4007:Fragments:Terminals:TERM_010000AA Extends Terminal

quest Property myQuest Auto

Function Fragment_Terminal_01(objectreference akTerminalRef) Native
