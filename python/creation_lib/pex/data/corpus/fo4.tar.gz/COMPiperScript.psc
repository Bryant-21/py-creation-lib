Scriptname COMPiperScript Extends Quest

Int Property iPlayerAdmirationChoice Auto
Int Property iPlayerApologizedDisdain Auto
