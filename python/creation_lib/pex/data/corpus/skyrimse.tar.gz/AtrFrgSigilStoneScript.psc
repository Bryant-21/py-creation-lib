Scriptname AtrFrgSigilStoneScript Extends ObjectReference

ObjectReference Property sigilStoneREF Auto
miscobject Property sigilStone Auto
atronachforgescript Property Forge Auto
message Property defaultLackTheItemMSG Auto

String Function GetState() Native
Function GotoState(String newState) Native
Function onActivate(ObjectReference actronaut) Native
