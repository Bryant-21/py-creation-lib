Scriptname BYOH_TIF__01007B35 Extends TopicInfo

spell Property FavorJobsBeggarsAbility Auto
message Property FavorJobsBeggarMessage Auto

Function Fragment_0(ObjectReference akSpeakerRef) Native
String Function GetState() Native
Function GotoState(String newState) Native
