Scriptname AddFactionToPlayerOnEnter Extends ObjectReference

faction Property FactionToAdd Auto

Function OnTriggerEnter(ObjectReference akActionRef) Native
