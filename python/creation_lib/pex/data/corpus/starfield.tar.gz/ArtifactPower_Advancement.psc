Scriptname ArtifactPower_Advancement Extends ActiveMagicEffect

perk Property PowerPerk Auto
spell Property PowerSpell Auto

Function OnEffectStart(objectreference akTarget, actor akCaster, magiceffect akBaseEffect, Float afMagnitude, Float afDuration) Native
