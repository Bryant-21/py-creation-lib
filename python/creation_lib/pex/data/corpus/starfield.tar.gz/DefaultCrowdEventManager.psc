Scriptname DefaultCrowdEventManager Extends Quest

Struct CrowdEventData
    keyword EventKeyword
    objectreference EventRef2
    objectreference EventRef1
EndStruct

Int Property StopSendingOnCrippleAfterStage Auto
referencealias Property FindOrigin Auto
refcollectionalias Property RefCollection Auto
referencealias[] Property OnDeathEventSenders Auto
referencealias[] Property OnCrippleEventSenders Auto
referencealias[] Property OnHitEventSenders Auto
Int Property StopSendingOnDeathAfterStage Auto
keyword Property CrowdEvent_OnDeath Auto
Int Property FindRadius Auto
keyword Property CrowdEvent_OnHit Auto
Int Property StopSendingOnHitAfterStage Auto
keyword Property CrowdEvent_OnCripple Auto
keyword Property CrowdEventMember Auto

Function CreateCrowdInLoadedArea() Native
Event OnHit(objectreference akTarget, objectreference akAggressor, form akSource, projectile akProjectile, Bool abPowerAttack, Bool abSneakAttack, Bool abBashAttack, Bool abHitBlocked, String asMaterialName)
EndEvent

Function OnQuestStarted() Native
Function RegisterForOnHitEvents() Native
Function SendCrowdEvent(keyword EventToSend, objectreference EventRef1, objectreference EventRef2) Native
Function UnregisterForOnHitEvents() Native
