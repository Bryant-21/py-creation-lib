Scriptname DefaultRefOnHit Extends DefaultRef

Event OnHit(objectreference akTarget, objectreference akAggressor, form akSource, projectile akProjectile, Bool abPowerAttack, Bool abSneakAttack, Bool abBashAttack, Bool abHitBlocked, String apMaterial)
EndEvent

Event OnLoad()
EndEvent

Event OnUnload()
EndEvent
