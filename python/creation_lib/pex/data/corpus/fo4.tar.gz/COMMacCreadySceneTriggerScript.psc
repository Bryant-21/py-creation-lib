Scriptname COMMacCreadySceneTriggerScript Extends ObjectReference

quest Property pCOMMacCready Auto
Int Property pTriggered Auto

Event OnTriggerEnter(ObjectReference akActionRef)
EndEvent
