Scriptname DialogueCrimeGuardsQuestScript Extends Quest

Struct CrimeFactionGlobals
    globalvariable CountResist
    globalvariable CountPayFine
    faction CrimeFaction
    globalvariable CountJail
    globalvariable CountArrests
EndStruct

Quest Property City_Akila_Ashta01 Auto
sq_parentscript Property SQ_Parent Auto
referencealias Property Alias_Guard Auto
Int Property Ashta01_StageToSet Auto
Int Property Ashta01_StageRequired Auto
location Property CityAkilaCityLocation Auto
crimefactionglobals[] Property CrimeFactions Auto
globalvariable Property CrimeBribeAmount Auto
globalvariable Property CrimeAllowBribePlayerCreditsRequired Auto
globalvariable Property CrimeBountyAmount Auto
keyword Property LocTypeSettlement Auto

Function IncrementCrimeGlobal(Int globalTypeEnum) Native
Function PlayerGoToJail() Native
Function PlayerPayFine(Bool abRemoveStolenItems, Bool abGoToJail) Native
Function PlayerResistingArrest() Native
Function PlayerSmuggling() Native
Function PlayerTryToArrest() Native
Function TestGoToJail(faction CrimeFaction, Bool realJail) Native
