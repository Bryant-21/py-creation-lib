Scriptname AtronachFrostScript Extends ActiveMagicEffect

explosion Property deathExplosion Auto
effectshader Property AtronachFrostFXS Auto
effectshader Property AtronachUnsummonDeathFXS Auto

String Function GetState() Native
Function GotoState(String newState) Native
Function onDying(Actor myKiller) Native
Function OnEffectFinish(Actor akTarget, Actor akCaster) Native
Function OnEffectStart(Actor Target, Actor Caster) Native
