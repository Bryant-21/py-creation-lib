Scriptname BoS302DanseKillHandlerScript Extends ReferenceAlias

quest Property BOS302 Auto Const
globalvariable Property BoS302DanseExecuted Auto Const

Event OnDying(actor akKiller)
EndEvent
