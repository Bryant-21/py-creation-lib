Scriptname ccOTMFO4001:ccOTMFO4001_CagedMirelurkScript Extends Actor

faction Property ccOTMFO4001_EnclaveFaction Auto Const
faction Property CreatureFaction Auto Const
actorvalue Property Suspicious Auto Const
actorvalue Property Aggression Auto Const
Float Property aggressionOnReset Auto Const
Float Property suspicionOnRelease Auto Const
faction Property MirelurkFaction Auto Const
Float Property suspicionOnReset Auto Const
Float Property aggressionOnRelease Auto Const

Function CellDoorOpened() Native
Function OnReset() Native
