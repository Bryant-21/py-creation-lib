Scriptname DefaultAliasOnEnterFurniture Extends DefaultAlias

Bool Property AllowDuringCombat Auto
message Property NotAllowedDuringCombat Auto

Function OnEnterFurniture(actor akActionRef) Native
