Scriptname COM_Barrett_EpilogueTimerScript Extends Quest

Int Property StageToSet Auto
Int Property cooldownHours Auto
Int Property idNumber Auto

Function OnTimerGameTime(Int aiTimerID) Native
Function StartCooldownTimer() Native
