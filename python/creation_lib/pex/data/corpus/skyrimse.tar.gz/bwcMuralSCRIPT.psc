Scriptname bwcMuralSCRIPT Extends ObjectReference

ObjectReference Property mural Auto
effectshader Property glow Auto
Bool Property glowTRIG Auto
Bool Property disableTRIG Auto

String Function GetState() Native
Function GotoState(String newState) Native
Function onTriggerEnter(ObjectReference obj) Native
Function onTriggerLeave(ObjectReference obj) Native
