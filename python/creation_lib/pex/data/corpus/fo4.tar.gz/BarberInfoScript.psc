Scriptname BarberInfoScript Extends TopicInfo

Event OnEnd(objectreference akSpeakerRef, Bool abHasBeenSaid)
EndEvent
