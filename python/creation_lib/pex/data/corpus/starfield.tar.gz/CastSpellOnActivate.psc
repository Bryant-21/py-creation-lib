Scriptname CastSpellOnActivate Extends ObjectReference

spell Property SpellToCast Auto

Function ArcElectricityToTarget(ObjectReference target) Native
Function OnActivate(ObjectReference akActionRef) Native
