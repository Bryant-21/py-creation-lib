Scriptname CustomItemQuestScript Extends Quest

Struct ItemDatum
    referencealias AliasToForceItemInto
    Bool PlaceAtMeInstead
    referencealias AliasToSpawnIn
    objectreference ReferenceToSpawnIn
    formlist ModsFormlist
    leveleditem LeveledListToSpawnFrom
    String ID
    Int QuestStage
EndStruct

itemdatum[] Property ItemData Auto

Event OnStageSet(Int auiStageID, Int auiItemID)
EndEvent

form Function SpawnCustomItem(leveleditem LeveledListToSpawnFrom, formlist ModsFormlist, objectreference ReferenceToSpawnIn, Bool PlaceAtMeInstead = false, referencealias AliasToForceItemInto = none) Global Native
