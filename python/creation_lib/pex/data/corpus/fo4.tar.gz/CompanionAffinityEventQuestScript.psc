Scriptname CompanionAffinityEventQuestScript Extends Quest

Quest Property MQ104 Auto Const
Quest Property MQ206RR Auto Const
keyword Property CA_CustomEvent_MacCreadyDislikes Auto Const
Quest Property BoSR05 Auto Const
keyword Property CA_CustomEvent_CaitDislikes Auto Const
Quest Property BoS101 Auto Const
keyword Property CA_CustomEvent_MacCready__UNSET Auto Const
Quest Property MinVsInst Auto Const
Quest Property MQ302Min Auto Const
Quest Property BoS203 Auto Const
Quest Property DialogueGoodneighborEntrance Auto Const
keyword Property CA_CustomEvent_DeaconDislikes Auto Const
Quest Property MinRecruit09 Auto Const
keyword Property CA_CustomEvent_MacCreadyLoves Auto Const
keyword Property CA_CustomEvent_Hancock__UNSET Auto Const
Quest Property DN083_Barney Auto Const
Quest Property FFDiamondCity01 Auto Const
keyword Property CA_CustomEvent_ValentineLikes Auto Const
companionactorscript Property BoSPaladinDanseRef Auto Const
Quest Property DialogueVault81 Auto Const
Quest Property BoS302 Auto Const
keyword Property CA_CustomEvent_Valentine__UNSET Auto Const
Quest Property BoS202 Auto Const
Quest Property DialogueConcordArea Auto Const
Quest Property MQ105 Auto Const
Quest Property FFBunkerHill03 Auto Const
Quest Property BoSM02 Auto Const
keyword Property CA_CustomEvent_X688__UNSET Auto Const
Quest Property DN053 Auto Const
keyword Property CA_CustomEvent_CodsworthHates Auto Const
keyword Property CA_CustomEvent_DeaconLikes Auto Const
keyword Property CA_CustomEvent_HancockDislikes Auto Const
Quest Property DialogueDiamondCitySchoolhouse Auto Const
Quest Property MS14 Auto Const
Quest Property RR303 Auto Const
Quest Property InstM01 Auto Const
keyword Property CA_CustomEvent_CodsworthLikes Auto Const
Quest Property Min01 Auto Const
Quest Property BoSM01 Auto Const
keyword Property CA_CustomEvent_ValentineLoves Auto Const
Quest Property DN036 Auto Const
Quest Property InstM03 Auto Const
Quest Property Inst306 Auto Const
Quest Property MS13CookeDies Auto Const
keyword Property CA_CustomEvent_ValentineDislikes Auto Const
keyword Property CA_CustomEvent_MacCreadyHates Auto Const
Quest Property BoS301 Auto Const
Quest Property FFDiamondCity08 Auto Const
Quest Property DialogueDrinkingBuddy Auto Const
Quest Property MQ302BoS Auto Const
Quest Property MQ302RR Auto Const
Quest Property Inst302 Auto Const
Quest Property MS16 Auto Const
Quest Property MinRecruit03 Auto Const
Quest Property RR102 Auto Const
Quest Property DialogueDiamondCity Auto Const
Quest Property MS05BPostQuest Auto Const
Quest Property DialogueDrumlinDiner Auto Const
Quest Property DialogueDiamondCityEntrance Auto Const
globalvariable Property MinCastleAttacker Auto Const
Quest Property DiamondCitySuperMutantIntro Auto Const
Quest Property RETravelKMK_BoSM02 Auto Const
Quest Property MS01 Auto Const
Quest Property DialogueRailroad Auto Const
Quest Property MS13FindPhoto Auto Const
Quest Property MS17 Auto Const
Quest Property RRR08 Auto Const
globalvariable Property Cait_EventCondition_DislikesPlayerTakingChems Auto Const
Quest Property BoS200 Auto Const
companionactorscript Property X688Ref Auto Const
keyword Property CA_CustomEvent_X688Loves Auto Const
Quest Property MS13 Auto Const
companionactorscript Property StrongRef Auto Const
companionactorscript Property CurieRef Auto Const
companionactorscript Property CaitRef Auto Const
companionactorscript Property CompMacCreadyRef Auto Const
Quest Property DN109 Auto Const
Quest Property MQ00MamaMurphy Auto Const
keyword Property CA_CustomEvent_PiperLoves Auto Const
companionactorscript Property CodsworthRef Auto Const
companionactorscript Property PrestonRef Auto Const
keyword Property CA_CustomEvent_DanseLikes Auto Const
keyword Property CA_CustomEvent_CurieLikes Auto Const
companionactorscript Property PiperRef Auto Const
keyword Property CA_CustomEvent_X688Hates Auto Const
Quest Property Min207 Auto Const
Quest Property Min02 Auto Const
keyword Property CA_CustomEvent_X688Dislikes Auto Const
Quest Property DN102 Auto Const
Quest Property REAssaultSC01_DN123SkylanesAssault Auto Const
Quest Property MinDestBOS Auto Const
keyword Property CA_CustomEvent_CaitHates Auto Const
keyword Property CA_CustomEvent_X688Likes Auto Const
Quest Property BoS201 Auto Const
companionactorscript Property ValentineRef Auto Const
Quest Property Min301 Auto Const
keyword Property CA_CustomEvent_ValentineHates Auto Const
keyword Property CA_CustomEvent_Strong__UNSET Auto Const
Quest Property MS07c Auto Const
keyword Property CA_CustomEvent_HancockLoves Auto Const
Quest Property DN079 Auto Const
Quest Property Min03 Auto Const
Quest Property MQ206 Auto Const
keyword Property CA_CustomEvent_StrongHates Auto Const
Quest Property MQ203 Auto Const
keyword Property CA_CustomEvent_StrongDislikes Auto Const
keyword Property CA_CustomEvent_StrongLikes Auto Const
Quest Property DN119Fight Auto Const
keyword Property CA_CustomEvent_StrongLoves Auto Const
Quest Property DN101 Auto Const
Quest Property RRR04 Auto Const
keyword Property CA_CustomEvent_Preston__UNSET Auto Const
keyword Property CA_CustomEvent_CodsworthDislikes Auto Const
keyword Property CA_CustomEvent_MacCreadyLikes Auto Const
keyword Property CA_CustomEvent_PiperLikes Auto Const
keyword Property CA_CustomEvent_CodsworthLoves Auto Const
keyword Property CA_CustomEvent_HancockHates Auto Const
Quest Property FFDiamondCity07 Auto Const
Quest Property MS05B Auto Const
keyword Property CA_CustomEvent_PrestonLoves Auto Const
keyword Property CA_CustomEvent_Piper__UNSET Auto Const
Quest Property RESceneLC01 Auto Const
Quest Property MS04 Auto Const
keyword Property CA_CustomEvent_PiperHates Auto Const
Quest Property RR201 Auto Const
keyword Property CA_CustomEvent_PiperDislikes Auto Const
keyword Property CA_CustomEvent_PrestonDislikes Auto Const
Quest Property RR101 Auto Const
companionactorscript Property DeaconRef Auto Const
keyword Property CA_CustomEvent_PrestonHates Auto Const
keyword Property CA_CustomEvent_DeaconHates Auto Const
Quest Property InstR03NEW Auto Const
keyword Property CA_CustomEvent_CaitLikes Auto Const
Quest Property InstR05 Auto Const
keyword Property CA_CustomEvent_Deacon__UNSET Auto Const
keyword Property CA_CustomEvent_Cait__UNSET Auto Const
Quest Property DialogueGoodneighborRufus Auto Const
Quest Property FFDiamondCity10 Auto Const
Quest Property RETravelSC01_DN123SkylanesPointer Auto Const
keyword Property CA_CustomEvent_PrestonLikes Auto Const
Quest Property DN019JoinCult Auto Const
keyword Property CA_CustomEvent_HancockLikes Auto Const
keyword Property CA_CustomEvent_CurieLoves Auto Const
keyword Property CA_CustomEvent_DeaconLoves Auto Const
keyword Property CA_CustomEvent_Danse__UNSET Auto Const
Quest Property RR302 Auto Const
Quest Property RRM01 Auto Const
keyword Property CA_CustomEvent_DanseHates Auto Const
Quest Property RRR02aQuest Auto Const
keyword Property CA_CustomEvent_DanseDislikes Auto Const
keyword Property CA_CustomEvent_DanseLoves Auto Const
Quest Property RECampLC01 Auto Const
keyword Property CA_CustomEvent_Codsworth__UNSET Auto Const
keyword Property CA_CustomEvent_Curie__UNSET Auto Const
keyword Property CA_CustomEvent_CurieHates Auto Const
Quest Property BoS204 Auto Const
keyword Property CA_CustomEvent_CurieDislikes Auto Const
Quest Property DialogueGraygarden Auto Const
Quest Property DialogueGoodneighbor Auto Const
globalvariable Property MQ302Faction Auto Const
Quest Property DN036_Post Auto Const
Quest Property Inst307 Auto Const
Quest Property RRR05 Auto Const
Quest Property DN015 Auto Const
Quest Property DialogueWarwickHomestead Auto Const
Quest Property V81_03 Auto Const
Quest Property V81_01 Auto Const
Quest Property InstM02 Auto Const
Quest Property MS13PaulDies Auto Const
Quest Property DialogueBunkerHill Auto Const
Quest Property MS07a Auto Const
Quest Property BoS303 Auto Const
Quest Property RRM02 Auto Const
Quest Property BoS100 Auto Const
Quest Property MS13NelsonDies Auto Const
Quest Property MS19 Auto Const
Quest Property Inst301 Auto Const
Quest Property DialogueTheSlog Auto Const
Quest Property MS07b Auto Const
Quest Property RRAct3PickUp Auto Const
Quest Property MS11 Auto Const
Quest Property MS09 Auto Const
keyword Property CA_CustomEvent_CaitLoves Auto Const
Quest Property DialogueAbernathyFarm Auto Const
Quest Property MQ302 Auto Const
Quest Property MinDefendCastle Auto Const
Quest Property V81_00_Intro Auto Const
Quest Property DN121 Auto Const
Quest Property FFGoodneighbor07 Auto Const
Quest Property InstR04 Auto Const
companionactorscript Property HancockRef Auto Const
Quest Property MQ201 Auto Const

CustomEvent CompanionAffinityEvent

Function Cait__UNSET() Native
Function Cait_Dislikes(Bool CheckCompanionProximity = true) Native
Function Cait_Hates(Bool CheckCompanionProximity = true) Native
Function Cait_Likes(Bool CheckCompanionProximity = true) Native
Function Cait_Loves(Bool CheckCompanionProximity = true) Native
Function Cait_Neutral(Bool CheckCompanionProximity = true) Native
Function Codsworth__UNSET() Native
Function Codsworth_Dislikes(Bool CheckCompanionProximity = true) Native
Function Codsworth_Hates(Bool CheckCompanionProximity = true) Native
Function Codsworth_Likes(Bool CheckCompanionProximity = true) Native
Function Codsworth_Loves(Bool CheckCompanionProximity = true) Native
Function Codsworth_Neutral(Bool CheckCompanionProximity = true) Native
Function Curie__UNSET() Native
Function Curie_Dislikes(Bool CheckCompanionProximity = true) Native
Function Curie_Hates(Bool CheckCompanionProximity = true) Native
Function Curie_Likes(Bool CheckCompanionProximity = true) Native
Function Curie_Loves(Bool CheckCompanionProximity = true) Native
Function Curie_Neutral(Bool CheckCompanionProximity = true) Native
Function Danse__UNSET() Native
Function Danse_Dislikes(Bool CheckCompanionProximity = true) Native
Function Danse_Hates(Bool CheckCompanionProximity = true) Native
Function Danse_Likes(Bool CheckCompanionProximity = true) Native
Function Danse_Loves(Bool CheckCompanionProximity = true) Native
Function Danse_Neutral(Bool CheckCompanionProximity = true) Native
Function Deacon__UNSET() Native
Function Deacon_Dislikes(Bool CheckCompanionProximity = true) Native
Function Deacon_Hates(Bool CheckCompanionProximity = true) Native
Function Deacon_Likes(Bool CheckCompanionProximity = true) Native
Function Deacon_Loves(Bool CheckCompanionProximity = true) Native
Function Deacon_Neutral(Bool CheckCompanionProximity = true) Native
CompanionAffinityEventQuestScript Function GetScript() Global Native
Function Hancock__UNSET() Native
Function Hancock_Dislikes(Bool CheckCompanionProximity = true) Native
Function Hancock_Hates(Bool CheckCompanionProximity = true) Native
Function Hancock_Likes(Bool CheckCompanionProximity = true) Native
Function Hancock_Loves(Bool CheckCompanionProximity = true) Native
Function Hancock_Neutral(Bool CheckCompanionProximity = true) Native
Function HandleDialogueBump_BoS100(Quest eventQuest, Int eventID) Native
Function HandleDialogueBump_BoS101(Quest eventQuest, Int eventID) Native
Function HandleDialogueBump_BoS201(Quest eventQuest, Int eventID) Native
Function HandleDialogueBump_BoS202(Quest eventQuest, Int eventID) Native
Function HandleDialogueBump_BoS203(Quest eventQuest, Int eventID) Native
Function HandleDialogueBump_BoS301(Quest eventQuest, Int eventID) Native
Function HandleDialogueBump_BoS302(Quest eventQuest, Int eventID) Native
Function HandleDialogueBump_BoS303(Quest eventQuest, Int eventID) Native
Function HandleDialogueBump_BoSM01(Quest eventQuest, Int eventID) Native
Function HandleDialogueBump_BoSM02(Quest eventQuest, Int eventID) Native
Function HandleDialogueBump_BoSR05(Quest eventQuest, Int eventID) Native
Function HandleDialogueBump_DialogueAbernathyFarm(Quest eventQuest, Int eventID) Native
Function HandleDialogueBump_DialogueBunkerHill(Quest eventQuest, Int eventID) Native
Function HandleDialogueBump_DialogueConcordArea(Quest eventQuest, Int eventID) Native
Function HandleDialogueBump_DialogueDiamondCity(Quest eventQuest, Int eventID) Native
Function HandleDialogueBump_DialogueDiamondCityEntrance(Quest eventQuest, Int eventID) Native
Function HandleDialogueBump_DialogueDiamondCitySchoolhouse(Quest eventQuest, Int eventID) Native
Function HandleDialogueBump_DialogueDrumlinDiner(Quest eventQuest, Int eventID) Native
Function HandleDialogueBump_DialogueGoodneighbor(Quest eventQuest, Int eventID) Native
Function HandleDialogueBump_DialogueGoodneighborEntrance(Quest eventQuest, Int eventID) Native
Function HandleDialogueBump_DialogueGraygarden(Quest eventQuest, Int eventID) Native
Function HandleDialogueBump_DialogueRailroad(Quest eventQuest, Int eventID) Native
Function HandleDialogueBump_DialogueTheSlog(Quest eventQuest, Int eventID) Native
Function HandleDialogueBump_DialogueVault81(Quest eventQuest, Int eventID) Native
Function HandleDialogueBump_DialogueWarwickHomestead(Quest eventQuest, Int eventID) Native
Function HandleDialogueBump_DiamondCitySuperMutantIntro(Quest eventQuest, Int eventID) Native
Function HandleDialogueBump_DN019JoinCult(Quest eventQuest, Int eventID) Native
Function HandleDialogueBump_DN053(Quest eventQuest, Int eventID) Native
Function HandleDialogueBump_DN102(Quest eventQuest, Int eventID) Native
Function HandleDialogueBump_FFDiamondCity01(Quest eventQuest, Int eventID) Native
Function HandleDialogueBump_FFDiamondCity07(Quest eventQuest, Int eventID) Native
Function HandleDialogueBump_FFDiamondCity08(Quest eventQuest, Int eventID) Native
Function HandleDialogueBump_FFDiamondCity10(Quest eventQuest, Int eventID) Native
Function HandleDialogueBump_FFGoodneighbor07(Quest eventQuest, Int eventID) Native
Function HandleDialogueBump_Inst301(Quest eventQuest, Int eventID) Native
Function HandleDialogueBump_Inst302(Quest eventQuest, Int eventID) Native
Function HandleDialogueBump_Inst306(Quest eventQuest, Int eventID) Native
Function HandleDialogueBump_InstM01(Quest eventQuest, Int eventID) Native
Function HandleDialogueBump_InstM02(Quest eventQuest, Int eventID) Native
Function HandleDialogueBump_InstM03(Quest eventQuest, Int eventID) Native
Function HandleDialogueBump_Min01(Quest eventQuest, Int eventID) Native
Function HandleDialogueBump_Min03(Quest eventQuest, Int eventID) Native
Function HandleDialogueBump_MinRecruit03(Quest eventQuest, Int eventID) Native
Function HandleDialogueBump_MinRecruit09(Quest eventQuest, Int eventID) Native
Function HandleDialogueBump_MinVsInst(Quest eventQuest, Int eventID) Native
Function HandleDialogueBump_MQ00MamaMurphy(Quest eventQuest, Int eventID) Native
Function HandleDialogueBump_MQ104(Quest eventQuest, Int eventID) Native
Function HandleDialogueBump_MQ105(Quest eventQuest, Int eventID) Native
Function HandleDialogueBump_MQ201(Quest eventQuest, Int eventID) Native
Function HandleDialogueBump_MQ206(Quest eventQuest, Int eventID) Native
Function HandleDialogueBump_MQ206RR(Quest eventQuest, Int eventID) Native
Function HandleDialogueBump_MQ302BoS(Quest eventQuest, Int eventID) Native
Function HandleDialogueBump_MQ302Min(Quest eventQuest, Int eventID) Native
Function HandleDialogueBump_MQ302RR(Quest eventQuest, Int eventID) Native
Function HandleDialogueBump_MS01(Quest eventQuest, Int eventID) Native
Function HandleDialogueBump_MS04(Quest eventQuest, Int eventID) Native
Function HandleDialogueBump_MS05B(Quest eventQuest, Int eventID) Native
Function HandleDialogueBump_MS07a(Quest eventQuest, Int eventID) Native
Function HandleDialogueBump_MS09(Quest eventQuest, Int eventID) Native
Function HandleDialogueBump_MS11(Quest eventQuest, Int eventID) Native
Function HandleDialogueBump_MS13(Quest eventQuest, Int eventID) Native
Function HandleDialogueBump_MS13CookeDies(Quest eventQuest, Int eventID) Native
Function HandleDialogueBump_MS13FindPhoto(Quest eventQuest, Int eventID) Native
Function HandleDialogueBump_MS13NelsonDies(Quest eventQuest, Int eventID) Native
Function HandleDialogueBump_MS13PaulDies(Quest eventQuest, Int eventID) Native
Function HandleDialogueBump_MS14(Quest eventQuest, Int eventID) Native
Function HandleDialogueBump_MS16(Quest eventQuest, Int eventID) Native
Function HandleDialogueBump_MS17(Quest eventQuest, Int eventID) Native
Function HandleDialogueBump_MS19(Quest eventQuest, Int eventID) Native
Function HandleDialogueBump_REAssaultSC01_DN123SkylanesAssault(Quest eventQuest, Int eventID) Native
Function HandleDialogueBump_RECampLC01(Quest eventQuest, Int eventID) Native
Function HandleDialogueBump_RESceneLC01(Quest eventQuest, Int eventID) Native
Function HandleDialogueBump_RETravelKMK_BoSM02(Quest eventQuest, Int eventID) Native
Function HandleDialogueBump_RETravelSC01_DN123SkylanesPointer(Quest eventQuest, Int eventID) Native
Function HandleDialogueBump_RR101(Quest eventQuest, Int eventID) Native
Function HandleDialogueBump_RR102(Quest eventQuest, Int eventID) Native
Function HandleDialogueBump_RR302(Quest eventQuest, Int eventID) Native
Function HandleDialogueBump_RR303(Quest eventQuest, Int eventID) Native
Function HandleDialogueBump_RRM01(Quest eventQuest, Int eventID) Native
Function HandleDialogueBump_RRM02(Quest eventQuest, Int eventID) Native
Function HandleDialogueBump_RRR02a(Quest eventQuest, Int eventID) Native
Function HandleDialogueBump_RRR05(Quest eventQuest, Int eventID) Native
Function HandleDialogueBump_RRR08(Quest eventQuest, Int eventID) Native
Function HandleDialogueBump_V81_00_Intro(Quest eventQuest, Int eventID) Native
Function HandleDialogueBump_V81_01(Quest eventQuest, Int eventID) Native
Function HandleDialogueBump_V81_03(Quest eventQuest, Int eventID) Native
Function HandleQuestStageBump_BoS200(Quest eventQuest, Int eventID) Native
Function HandleQuestStageBump_BoS202(Quest eventQuest, Int eventID) Native
Function HandleQuestStageBump_BoS203(Quest eventQuest, Int eventID) Native
Function HandleQuestStageBump_BoS204(Quest eventQuest, Int eventID) Native
Function HandleQuestStageBump_BoS301(Quest eventQuest, Int eventID) Native
Function HandleQuestStageBump_BoS302(Quest eventQuest, Int eventID) Native
Function HandleQuestStageBump_BoSM01(Quest eventQuest, Int eventID) Native
Function HandleQuestStageBump_BoSM02(Quest eventQuest, Int eventID) Native
Function HandleQuestStageBump_BoSR05(Quest eventQuest, Int eventID) Native
Function HandleQuestStageBump_DialogueDrinkingBuddy(Quest eventQuest, Int eventID) Native
Function HandleQuestStageBump_DialogueGoodneighborRufus(Quest eventQuest, Int eventID) Native
Function HandleQuestStageBump_DN015(Quest eventQuest, Int eventID) Native
Function HandleQuestStageBump_DN036(Quest eventQuest, Int eventID) Native
Function HandleQuestStageBump_DN036_Post(Quest eventQuest, Int eventID) Native
Function HandleQuestStageBump_DN053(Quest eventQuest, Int eventID) Native
Function HandleQuestStageBump_DN079(Quest eventQuest, Int eventID) Native
Function HandleQuestStageBump_DN083_Barney(Quest eventQuest, Int eventID) Native
Function HandleQuestStageBump_DN101(Quest eventQuest, Int eventID) Native
Function HandleQuestStageBump_DN109(Quest eventQuest, Int eventID) Native
Function HandleQuestStageBump_DN119Fight(Quest eventQuest, Int eventID) Native
Function HandleQuestStageBump_DN121(Quest eventQuest, Int eventID) Native
Function HandleQuestStageBump_FFBunkerHill03(Quest eventQuest, Int eventID) Native
Function HandleQuestStageBump_FFGoodneighbor07(Quest eventQuest, Int eventID) Native
Function HandleQuestStageBump_Inst301(Quest eventQuest, Int eventID) Native
Function HandleQuestStageBump_Inst307(Quest eventQuest, Int eventID) Native
Function HandleQuestStageBump_InstM01(Quest eventQuest, Int eventID) Native
Function HandleQuestStageBump_InstR03NEW(Quest eventQuest, Int eventID) Native
Function HandleQuestStageBump_InstR04(Quest eventQuest, Int eventID) Native
Function HandleQuestStageBump_InstR05(Quest eventQuest, Int eventID) Native
Function HandleQuestStageBump_Min01(Quest eventQuest, Int eventID) Native
Function HandleQuestStageBump_Min02(Quest eventQuest, Int eventID) Native
Function HandleQuestStageBump_Min03(Quest eventQuest, Int eventID) Native
Function HandleQuestStageBump_Min207(Quest eventQuest, Int eventID) Native
Function HandleQuestStageBump_Min301(Quest eventQuest, Int eventID) Native
Function HandleQuestStageBump_MinDefendCastle(Quest eventQuest, Int eventID) Native
Function HandleQuestStageBump_MinDestBOS(Quest eventQuest, Int eventID) Native
Function HandleQuestStageBump_MQ203(Quest eventQuest, Int eventID) Native
Function HandleQuestStageBump_MQ302(Quest eventQuest, Int eventID) Native
Function HandleQuestStageBump_MS01(Quest eventQuest, Int eventID) Native
Function HandleQuestStageBump_MS04(Quest eventQuest, Int eventID) Native
Function HandleQuestStageBump_MS05B(Quest eventQuest, Int eventID) Native
Function HandleQuestStageBump_MS05BPostQuest(Quest eventQuest, Int eventID) Native
Function HandleQuestStageBump_MS07a(Quest eventQuest, Int eventID) Native
Function HandleQuestStageBump_MS07b(Quest eventQuest, Int eventID) Native
Function HandleQuestStageBump_MS07c(Quest eventQuest, Int eventID) Native
Function HandleQuestStageBump_MS09(Quest eventQuest, Int eventID) Native
Function HandleQuestStageBump_MS11(Quest eventQuest, Int eventID) Native
Function HandleQuestStageBump_MS16(Quest eventQuest, Int eventID) Native
Function HandleQuestStageBump_MS17(Quest eventQuest, Int eventID) Native
Function HandleQuestStageBump_RECampLC01(Quest eventQuest, Int eventID) Native
Function HandleQuestStageBump_RESceneLC01(Quest eventQuest, Int eventID) Native
Function HandleQuestStageBump_RR101(Quest eventQuest, Int eventID) Native
Function HandleQuestStageBump_RR102(Quest eventQuest, Int eventID) Native
Function HandleQuestStageBump_RR201(Quest eventQuest, Int eventID) Native
Function HandleQuestStageBump_RR303(Quest eventQuest, Int eventID) Native
Function HandleQuestStageBump_RRAct3PickUp(Quest eventQuest, Int eventID) Native
Function HandleQuestStageBump_RRM01(Quest eventQuest, Int eventID) Native
Function HandleQuestStageBump_RRM02(Quest eventQuest, Int eventID) Native
Function HandleQuestStageBump_RRR04(Quest eventQuest, Int eventID) Native
Function HandleQuestStageBump_RRR08(Quest eventQuest, Int eventID) Native
Function HandleQuestStageBump_V81_01(Quest eventQuest, Int eventID) Native
Function MacCready__UNSET() Native
Function MacCready_Dislikes(Bool CheckCompanionProximity = true) Native
Function MacCready_Hates(Bool CheckCompanionProximity = true) Native
Function MacCready_Likes(Bool CheckCompanionProximity = true) Native
Function MacCready_Loves(Bool CheckCompanionProximity = true) Native
Function MacCready_Neutral(Bool CheckCompanionProximity = true) Native
Event OnInit()
EndEvent

Function Piper__UNSET() Native
Function Piper_Dislikes(Bool CheckCompanionProximity = true) Native
Function Piper_Hates(Bool CheckCompanionProximity = true) Native
Function Piper_Likes(Bool CheckCompanionProximity = true) Native
Function Piper_Loves(Bool CheckCompanionProximity = true) Native
Function Piper_Neutral(Bool CheckCompanionProximity = true) Native
Function Preston__UNSET() Native
Function Preston_Dislikes(Bool CheckCompanionProximity = true) Native
Function Preston_Hates(Bool CheckCompanionProximity = true) Native
Function Preston_Likes(Bool CheckCompanionProximity = true) Native
Function Preston_Loves(Bool CheckCompanionProximity = true) Native
Function Preston_Neutral(Bool CheckCompanionProximity = true) Native
Function SendAffinityBumpEvent(ScriptObject sender, Int eventID) Native
Function SendAffinityEvent(keyword affinityKeyword, Bool CheckCompanionProximity = true) Native
Function Strong__UNSET() Native
Function Strong_Dislikes(Bool CheckCompanionProximity = true) Native
Function Strong_Hates(Bool CheckCompanionProximity = true) Native
Function Strong_Likes(Bool CheckCompanionProximity = true) Native
Function Strong_Loves(Bool CheckCompanionProximity = true) Native
Function Strong_Neutral(Bool CheckCompanionProximity = true) Native
Function Valentine__UNSET() Native
Function Valentine_Dislikes(Bool CheckCompanionProximity = true) Native
Function Valentine_Hates(Bool CheckCompanionProximity = true) Native
Function Valentine_Likes(Bool CheckCompanionProximity = true) Native
Function Valentine_Loves(Bool CheckCompanionProximity = true) Native
Function Valentine_Neutral(Bool CheckCompanionProximity = true) Native
Function X688__UNSET() Native
Function X688_Dislikes(Bool CheckCompanionProximity = true) Native
Function X688_Hates(Bool CheckCompanionProximity = true) Native
Function X688_Likes(Bool CheckCompanionProximity = true) Native
Function X688_Loves(Bool CheckCompanionProximity = true) Native
Function X688_Neutral(Bool CheckCompanionProximity = true) Native
