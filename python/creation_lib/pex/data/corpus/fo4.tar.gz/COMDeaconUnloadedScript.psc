Scriptname COMDeaconUnloadedScript Extends ReferenceAlias

globalvariable Property pCOMDeaconUnloaded Auto Const

Event OnLoad()
EndEvent

Event OnUnload()
EndEvent
