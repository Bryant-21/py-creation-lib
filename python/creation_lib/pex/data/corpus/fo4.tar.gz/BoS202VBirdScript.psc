Scriptname BoS202VBirdScript Extends ReferenceAlias

action Property ActionPropellersOn Auto Const
action Property ActionPropellersOff Auto Const

Event OnLoad()
EndEvent
