Scriptname BlackreachDoorScript Extends ObjectReference

Bool Property isOpen Auto
String Property openAnim Auto
Bool Property isAnimating Auto
String Property openEvent Auto

String Function GetState() Native
Function GotoState(String newState) Native
Function onActivate(ObjectReference triggerRef) Native
Function OnLoad() Native
Function SetOpen(Bool abOpen) Native
