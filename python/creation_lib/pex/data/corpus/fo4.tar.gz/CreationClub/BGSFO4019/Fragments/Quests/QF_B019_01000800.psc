Scriptname CreationClub:BGSFO4019:Fragments:Quests:QF_B019_01000800 Extends Quest

Function Fragment_Stage_0100_Item_00() Native
Function Fragment_Stage_1000_Item_00() Native
