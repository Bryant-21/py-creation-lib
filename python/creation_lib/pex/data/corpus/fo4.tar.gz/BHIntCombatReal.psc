Scriptname BHIntCombatReal Extends ObjectReference

keyword Property LinkCustom01 Auto
keyword Property LinkCustom02 Auto
keyword Property LinkCustom03 Auto
keyword Property LinkCustom04 Auto

Event OnTriggerEnter(ObjectReference akActionRef)
EndEvent
