Scriptname AstridEndScript Extends ObjectReference

quest Property DB10 Auto
referencealias Property AstridEndAlias Auto

String Function GetState() Native
Function GotoState(String newState) Native
Function OnHit(ObjectReference aggressor, Form weap, Projectile proj, Bool abPowerAttack, Bool abSneakAttack, Bool abBashAttack, Bool abHitBlocked) Native
