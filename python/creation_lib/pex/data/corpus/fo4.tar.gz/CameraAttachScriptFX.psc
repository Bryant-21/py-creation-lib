Scriptname CameraAttachScriptFX Extends ObjectReference

visualeffect Property CameraAttachFX2 Auto
Int Property timeLimit Auto
visualeffect Property CameraAttachFX Auto
sound Property LoopSound Auto

Event ONTRIGGERENTER(ObjectReference akActionRef)
EndEvent

Event OnTriggerLeave(ObjectReference akActionRef)
EndEvent

Event OnUnLoad()
EndEvent
