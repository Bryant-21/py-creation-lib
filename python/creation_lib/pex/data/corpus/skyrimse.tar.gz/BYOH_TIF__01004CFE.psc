Scriptname BYOH_TIF__01004CFE Extends TopicInfo

globalvariable Property HDRiftenEnchanting Auto
objectreference Property DecorateMarker Auto
miscobject Property Gold Auto
Int Property GoldAmount Auto

Function Fragment_1(objectreference akSpeakerRef) Native
String Function GetState() Native
Function GotoState(String newState) Native
