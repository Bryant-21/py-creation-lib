Scriptname BYOH_TIF__01015D54 Extends TopicInfo

faction Property DismissedFollowerFaction Auto
quest Property pDialogueFollower Auto

Function Fragment_0(ObjectReference akSpeakerRef) Native
String Function GetState() Native
Function GotoState(String newState) Native
