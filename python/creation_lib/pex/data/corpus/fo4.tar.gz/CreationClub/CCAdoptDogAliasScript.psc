Scriptname CreationClub:CCAdoptDogAliasScript Extends ReferenceAlias

idle Property PairedDogmeatHumanGreetHand Auto Const
message Property messageAdopt Auto Const
idle Property PairedDogmeatHumanGreetPetKneel Auto Const
workshopparentscript Property WorkshopParent Auto Const
genericgohomescript Property GenericGoHome Auto Const
keyword Property CC_PetDogs_HasBeenAdopted Auto Const

Event OnActivate(objectreference akActionRef)
EndEvent

Event OnWorkshopNPCTransfer(location akNewWorkshop, keyword akActionKW)
EndEvent
