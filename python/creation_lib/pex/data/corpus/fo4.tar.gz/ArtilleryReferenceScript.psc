Scriptname ArtilleryReferenceScript Extends ObjectReference

weapon Property WorkshopArtilleryWeapon Auto Const
idle Property ArtilleryStop Auto Const
idle Property ArtilleryTurnCounterClockwise Auto Const
activator Property WorkshopArtilleryStrikeProjectileShooterFar Auto Const
sound Property WPNArtilleryMinutemenFire Auto Const
activator Property WorkshopArtilleryStrikeProjectileShooterClose Auto Const
explosion Property WorkshopArtilleryForce Auto Const
idle Property ArtilleryTurnClockwise Auto Const
explosion Property MinArtilleryMuzzleFlash Auto Const
idle Property ArtilleryFire Auto Const
activator Property WorkshopArtilleryFakeProjectile Auto Const
sound Property FXProjectileArtilleryMinutemen Auto Const
form Property XmarkerHeading Auto Const

CustomEvent FinishedFiring

Function FireAtTarget(ObjectReference TargetToFireAt, Bool turnToTargetOnly = false) Native
Function FireMortar(Bool fakeFire = false) Native
Bool Function GetTurnDirection(Int P, Int N) Native
Event OnAnimationEvent(ObjectReference akSource, String asEventName)
EndEvent

Function PlaceMortarExplosion() Native
Function PlaceTargetMarker() Native
Function PlayAnimOrIdle(idle myIdle, String myAnim) Native
Function Test(Bool justAim) Native
Function TurnToTarget(ObjectReference TargetToFireAt, Bool doNotFire = false) Native
