Scriptname DefaultAliasOnOpen Extends DefaultAlias

referencealias[] Property TriggeredByAliases Auto Const
objectreference[] Property TriggeredByReferences Auto Const
Bool Property PlayerTriggerOnly Auto Const
faction[] Property TriggeredByFactions Auto Const

Event OnOpen(objectreference akActionRef)
EndEvent
