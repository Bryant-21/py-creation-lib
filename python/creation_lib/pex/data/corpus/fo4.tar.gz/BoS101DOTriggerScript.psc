Scriptname BoS101DOTriggerScript Extends ObjectReference

ObjectReference Property BoS101OTMarker Auto Const
referencealias Property BoS101Danse Auto Const
cell Property ArcjetSystems01 Auto Const
quest Property BoS101 Auto Const

Event OnTriggerEnter(ObjectReference akActionRef)
EndEvent
