Scriptname CF05_DisguiseScript Extends Quest

faction[] Property MyFaction Auto
Float Property TimeDelay Auto
keyword Property CF05_EnsignArmorKeyword_Disguise Auto

Function AddPlayerToFaction() Native
Function OnTimer(Int timerID) Native
Function RemovePlayerFromFaction() Native
Function RunTimer() Native
