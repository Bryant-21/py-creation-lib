Scriptname CF_Main_QuestScript Extends Quest

Quest Property CF06 Auto
globalvariable Property CF04_UCArrested Auto
Quest Property CF03 Auto
globalvariable Property CF05_UCArrested Auto
Quest Property CF02 Auto
faction Property CrimeFactionUC Auto
Quest Property CF07 Auto
Quest Property CF04 Auto
Quest Property CF05 Auto

Function OnMenuOpenCloseEvent(String asMenuName, Bool abOpening) Native
Function RegisterForLoadScreenEvent() Native
Function SendPlayerToJail() Native
Function SysDefShutdown() Native
