Scriptname BYOH_PF_BYOHUrchin_AlesanRunn_01004024 Extends Package

Function Fragment_1(Actor akActor) Native
Function Fragment_2(Actor akActor) Native
Function Fragment_3(Actor akActor) Native
String Function GetState() Native
Function GotoState(String newState) Native
