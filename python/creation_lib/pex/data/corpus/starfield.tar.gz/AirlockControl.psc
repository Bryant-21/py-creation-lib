Scriptname AirlockControl Extends ObjectReference

keyword Property LinkKeyword1 Auto
message Property BusyActivatorMessage Auto
keyword Property LinkPassOpenCloseEvent Auto
keyword Property LinkKeyword2 Auto

Function onBeginState(String asOldState) Native
Function OnInit() Native
Function OnTimer(Int aiTimerID) Native
