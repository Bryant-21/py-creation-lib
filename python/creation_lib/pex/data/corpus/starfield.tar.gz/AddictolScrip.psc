Scriptname AddictolScrip Extends ActiveMagicEffect

spell Property Addiction Auto

Event OnEffectStart(objectreference akTarget, actor akCaster, magiceffect akBaseEffect, Float afMagnitude, Float afDuration)
EndEvent
