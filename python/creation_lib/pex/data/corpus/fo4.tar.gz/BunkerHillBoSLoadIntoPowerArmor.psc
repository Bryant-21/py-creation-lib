Scriptname BunkerHillBoSLoadIntoPowerArmor Extends Actor

keyword Property LinkPowerArmor Auto Const

Event OnCellLoad()
EndEvent
