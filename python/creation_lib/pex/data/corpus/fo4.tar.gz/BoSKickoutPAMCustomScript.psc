Scriptname BoSKickoutPAMCustomScript Extends ReferenceAlias

quest Property BoSKickOut Auto
quest Property BoS302B Auto

Event OnDying(actor akKiller)
EndEvent
