Scriptname bobbyPinBoxSCRIPT Extends ObjectReference

leveleditem Property LL_BobbyPinBox Auto Const

Event OnActivate(ObjectReference akActionRef)
EndEvent

Event OnLoad()
EndEvent
