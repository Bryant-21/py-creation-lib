Scriptname CastleArmoryTriggerScript Extends ObjectReference

weapon Property BoSVertibirdGrenade Auto
globalvariable Property MinArtilleryCanBuild Auto
globalvariable Property BoSFastTravelPilot Auto
quest Property Min01 Auto
weapon Property ArtillerySmokeFlare Auto
ammo Property AmmoFlareGun Auto

Event OnLoad()
EndEvent

Event OnTriggerEnter(ObjectReference akActionRef)
EndEvent

Function RefreshSmokeFlares() Native
