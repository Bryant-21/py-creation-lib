Scriptname AttachAshPile Extends ActiveMagicEffect

Bool Property onEffectStartOveride Auto
Bool Property bSetAlphaZero Auto
activator Property AshPileObject Auto
Float Property ShaderDuration Auto
Float Property fDelayEnd Auto
Bool Property bSetAlphaToZeroEarly Auto
effectshader Property MagicEffectShader Auto
Float Property fDelay Auto

Event OnDying(actor Killer)
EndEvent

Event OnEffectStart(actor Target, actor Caster)
EndEvent

Event OnInit()
EndEvent

Event OnTimer(Int aiTimerID)
EndEvent
