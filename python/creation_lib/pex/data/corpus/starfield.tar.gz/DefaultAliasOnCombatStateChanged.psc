Scriptname DefaultAliasOnCombatStateChanged Extends DefaultAlias

Bool Property IncludeOnHitEvent Auto
Int Property CombatStateToCheckFor Auto
Bool Property SpellHits_HostileOnly Auto

Function CombatStateChangedOrHit(objectreference TargetOrAggressor) Native
Function OnAliasInit() Native
Event OnCombatStateChanged(objectreference akTarget, Int aeCombatState)
EndEvent

Function OnHit(objectreference akTarget, objectreference akAggressor, form akSource, projectile akProjectile, Bool abPowerAttack, Bool abSneakAttack, Bool abBashAttack, Bool abHitBlocked, String asMaterialName) Native
Function OnLoad() Native
Function OnUnload() Native
