Scriptname BYOH_SF_RelationshipAdoption__0101652E Extends Scene

referencealias Property Child2 Auto
referencealias Property Child1 Auto
keyword Property WIGamesTagStart Auto

Function Fragment_2() Native
Function Fragment_5() Native
Function Fragment_7() Native
String Function GetState() Native
Function GotoState(String newState) Native
