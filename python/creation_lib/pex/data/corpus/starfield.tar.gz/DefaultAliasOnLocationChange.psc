Scriptname DefaultAliasOnLocationChange Extends DefaultAliasParent

location[] Property LocationsToCheckAgainst Auto
Bool Property CheckNewLocation Auto
Bool Property LocationMatchIfChild Auto
locationalias[] Property LocationAliasesToCheckAgainst Auto

locationalias[] Function GetLocationAliasesToCheckAgainst() Native
Bool Function GetLocationMatchIfChild() Native
location[] Function GetLocationsToCheckAgainst() Native
Function OnLocationChange(location akOldLoc, location akNewLoc) Native
