Scriptname CityCYRedTape01QuestScript Extends Quest

referencealias Property Player Auto
refcollectionalias Property IronDeposits Auto
miscobject Property InorgCommonIron Auto
Int Property ResourceObjective Auto
referencealias Property DepositBin Auto
Int Property TurnInObjective Auto
globalvariable Property City_CY_RedTape01Resource01Total Auto
Int Property GatherResourcesStage Auto
Int Property IronQTStage Auto
Int Property GatheredResourcesCompleteStage Auto
Int Property TrevorApplicationPlanStage Auto
globalvariable Property City_CY_RedTape01Resource01Count Auto

Function DebugGiveResources() Native
Function OnStageSet(Int auiStageID, Int auiItemID) Native
Function RegisterPlayerforInventoryFilter(Bool bRegister) Native
Function ResourceCheck() Native
