Scriptname DebugSceneScript Extends Scene

Event OnAction(Int auiActionID, referencealias akAlias)
EndEvent

Event OnBegin()
EndEvent

Event OnEnd()
EndEvent

Event OnPhaseBegin(Int auiPhaseIndex)
EndEvent

Event OnPhaseEnd(Int auiPhaseIndex)
EndEvent
