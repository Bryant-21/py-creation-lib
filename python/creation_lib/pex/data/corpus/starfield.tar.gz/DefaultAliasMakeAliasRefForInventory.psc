Scriptname DefaultAliasMakeAliasRefForInventory Extends ReferenceAlias

Bool Property ShowTraces Auto
Bool Property DoOnce Auto
Int Property TurnOffStageDone Auto
form Property TargetObject Auto
Int Property PrereqStage Auto
refcollectionalias Property CollectionToAddTo Auto
ReferenceAlias Property AliasToForce Auto

Function OnAliasInit() Native
Function OnItemAdded(form akBaseItem, Int aiItemCount, objectreference akItemReference, objectreference akSourceContainer, Int aiTransferReason) Native
Function ProcessMakingRef(form akBaseItem) Native
