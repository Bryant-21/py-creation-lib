Scriptname CA_DB_Event26 Extends ca_dialoguebump_basescript

Function InitializeEventID() Native
