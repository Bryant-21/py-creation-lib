Scriptname DefaultAliasOnHit Extends DefaultAlias

Bool Property PlayerHitOnly Auto Const
referencealias[] Property HitByAliases Auto Const
faction[] Property HitByFactions Auto Const
objectreference[] Property HitByReferences Auto Const

Event OnAliasInit()
EndEvent

Event OnHit(objectreference akTarget, objectreference akAggressor, form akSource, projectile akProjectile, Bool abPowerAttack, Bool abSneakAttack, Bool abBashAttack, Bool abHitBlocked, String asMaterialName)
EndEvent
