Scriptname ArenaCombatQuest Extends Quest

Int Property TotalOpponents Auto
Bool Property IsTransitionFight Auto
Bool Property IsBluntedQuest Auto

Function Cleanup() Native
String Function GetState() Native
Function GotoState(String newState) Native
Function NextWave() Native
Function OpponentDowned() Native
Function PlayerEnteredArena() Native
Function Setup() Native
Bool Function ShouldEnd() Native
