Scriptname BoSM02QuestScript Extends Quest

location Property BostonAirportRuinsLocation Auto Const
Quest Property BoSM02DanseOverrides Auto Const
scene Property BoSM02_ClarkeStage150_Follow0b Auto Const
referencealias Property BoSM02PaladinDanse Auto Const
Bool Property playerSeenByClarke Auto
scene Property BoSM02_ClarkeStage150_Follow0c Auto Const
Int Property rewardLevel Auto
referencealias Property Companion Auto Const
referencealias Property BoSClarke Auto Const

Event OnTimer(Int timerID)
EndEvent

Function StartClarkeMonitor() Native
Function StartDanseOverride() Native
Function StopDanseOverride() Native
