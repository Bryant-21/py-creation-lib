Scriptname ccBGSFO4116:SpigotLoadGameScript Extends ReferenceAlias

cell Property SaugusIronworks01 Auto
ccbgsfo4116:smeltersoundscript Property ObjectReferenceScript Auto

Function OnPlayerLoadGame() Native
