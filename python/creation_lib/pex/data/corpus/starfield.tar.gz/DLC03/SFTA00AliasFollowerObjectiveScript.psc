Scriptname DLC03:SFTA00AliasFollowerObjectiveScript Extends ReferenceAlias

Float Property GreaterDistance Auto
Int Property TurnOffStageDone Auto
Int Property FollowerObjective Auto
Float Property LesserDistance Auto

Function OnDistanceGreaterThan(objectreference akObj1, objectreference akObj2, Float afDistance, Int aiEventID) Native
Function OnDistanceLessThan(objectreference akObj1, objectreference akObj2, Float afDistance, Int aiEventID) Native
Function RegisterGreaterThan() Native
Function RegisterLessThan() Native
Function StartFollow() Native
Function Unregister() Native
