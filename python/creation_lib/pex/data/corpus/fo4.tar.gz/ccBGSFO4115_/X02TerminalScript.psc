Scriptname ccBGSFO4115_:X02TerminalScript Extends Terminal

Struct QuestStage
    Int MenuSelection
    Int StageToSet
EndStruct

quest Property MyQuest Auto Const
queststage[] Property Digits Auto Const

Function OnMenuItemRun(Int auiMenuItemID, objectreference akTerminalRef) Native
