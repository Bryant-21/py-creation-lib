Scriptname CityCYRedTape01HRTerminalScript Extends TerminalMenu

Struct ExpData
    globalvariable ExperienceValue
    message ExperienceMSG
EndStruct

Struct QualityData
    globalvariable QualityRangeValue
    message QualityMSG
EndStruct

Struct EdData
    globalvariable EducationValue
    message EducationMSG
EndStruct

keyword Property LinkCustom10 Auto
message[] Property QualityMessage Auto
message[] Property EdMessage Auto
message[] Property ExpMessage Auto
Int Property QualityBodyTextIndex Auto
Int Property EducationBodyTextIndex Auto
Int Property ExperienceBodyTextIndex Auto
Int Property PlayerNameBodyTextIndex Auto
TerminalMenu Property City_CY_RedTape01_HRSubTerminal_Applications_Player_Genesis Auto
TerminalMenu Property City_CY_RedTape01_HRSubTerminal_Applications_Genesis Auto
globalvariable Property City_CY_RedTape01_Education Auto
globalvariable Property City_CY_RedTape01ApplicationTotal Auto
globalvariable Property City_CY_RedTape01_Experience Auto
globalvariable Property City_CY_RedTape01Quality01 Auto
Float Property fDistance Auto
globalvariable Property City_CY_RedTape01Quality02 Auto
globalvariable Property City_CY_RedTape01Quality03 Auto

Function OnTerminalMenuEnter(TerminalMenu akTerminalBase, objectreference akTerminalRef) Native
