Scriptname AbLegendaryScript Extends ActiveMagicEffect

Bool Property PoweredUp Auto
sound Property PowerUpSound Auto Const
message Property LegendaryPowerUpMsg Auto Const
Float Property HealthThreshhold Auto Const
actorvalue Property Health Auto Const
spell Property LegendaryPowerUp Auto Const

Event OnEffectFinish(actor akTarget, actor akCaster)
EndEvent

Event OnEffectStart(actor akTarget, actor akCaster)
EndEvent

Event OnHit(objectreference akTarget, objectreference akAggressor, form akSource, projectile akProjectile, Bool abPowerAttack, Bool abSneakAttack, Bool abBashAttack, Bool abHitBlocked, String apMaterial)
EndEvent
