Scriptname CZCrowdOnBeginTIF Extends TopicInfo

action Property ActionCustomCheering Auto
Bool Property laugh Auto
action Property ActionCustomLaughing Auto
action Property ActionCustomBooing Auto
Bool Property cheer Auto

Event OnBegin(objectreference akSpeakerRef, Bool abHasBeenSaid)
EndEvent
