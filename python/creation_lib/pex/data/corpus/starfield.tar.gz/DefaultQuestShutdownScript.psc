Scriptname DefaultQuestShutdownScript Extends Quest

Int Property StartTimerStage Auto
Float Property ShutdownTimerDuration Auto

Event OnStageSet(Int auiStageID, Int auiItemID)
EndEvent

Event OnTimerGameTime(Int aiTimerID)
EndEvent
