Scriptname DefaultAddItemOnActivate Extends ObjectReference

form Property ItemToGive Auto Const
Bool Property bDisableWhenDone Auto Const
Int Property iNumberToGiveMax Auto Const
Int Property iNumberToGiveMin Auto Const

Event OnActivate(ObjectReference akActionRef)
EndEvent
