Scriptname ChainedDoor Extends ObjectReference

keyword Property PlayerActivateDoorChained Auto
message Property UnchainMeMSG Auto
sound Property OpenSound Auto
message Property ChainedMSG Auto
sound Property ChainedFX Auto
Bool Property abChained Auto
Bool Property abBusy Auto
keyword Property PlayerActivateDoorChainedSameSide Auto

Event OnActivate(ObjectReference akActionRef)
EndEvent

Event OnCellLoad()
EndEvent
