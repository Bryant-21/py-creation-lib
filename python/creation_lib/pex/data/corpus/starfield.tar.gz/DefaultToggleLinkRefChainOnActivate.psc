Scriptname DefaultToggleLinkRefChainOnActivate Extends ObjectReference

Bool Property DoOnce Auto
Bool Property ShowTraces Auto
keyword Property LinkedRefKeyword Auto
Bool Property CloseOrOpenRef Auto

Function CloseOrOpen(Int count, ObjectReference akActionRef, keyword LinkedRefKeyword) Native
Function OnActivate(ObjectReference akActionRef) Native
Function ToggleLinkedRefChain(ObjectReference akActionRef, keyword LinkedRefKeyword) Native
