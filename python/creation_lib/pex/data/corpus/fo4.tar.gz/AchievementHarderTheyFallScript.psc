Scriptname AchievementHarderTheyFallScript Extends Actor

quest Property pAchievements Auto

Event OnDeath(Actor akKiller)
EndEvent
