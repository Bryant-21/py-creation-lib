Scriptname AnimalTrainerSystemScript Extends Quest

Quest Property pDialogueFollower Auto
globalvariable Property AnimalGold Auto
miscobject Property Gold Auto

Function BuyAnimal(Actor AnimalTrainer) Native
String Function GetState() Native
Function GotoState(String newState) Native
