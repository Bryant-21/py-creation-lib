Scriptname BYOH_TIF__01007A84 Extends TopicInfo

Function Fragment_0(ObjectReference akSpeakerRef) Native
String Function GetState() Native
Function GotoState(String newState) Native
