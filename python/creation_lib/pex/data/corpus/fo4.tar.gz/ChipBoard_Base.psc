Scriptname ChipBoard_Base Extends ObjectReference

miscobject Property Chip Auto
keyword Property LinkCustom01 Auto
message Property MissingChipMessage Auto

Event OnActivate(ObjectReference akActionRef)
EndEvent
