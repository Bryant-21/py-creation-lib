Scriptname CryoCorpseScript Extends Actor

effectshader Property CryoCorpseFXS Auto Const

Event OnLoad()
EndEvent
