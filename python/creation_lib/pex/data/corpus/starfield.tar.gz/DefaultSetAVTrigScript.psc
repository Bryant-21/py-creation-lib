Scriptname DefaultSetAVTrigScript Extends ObjectReference

actorvalue Property AV02 Auto
Float Property AV01_Value Auto
Float Property AV04_Value Auto
actorvalue Property AV04 Auto
Bool Property ShowTraces Auto
Int Property maxLinks Auto
keyword Property linkKeyword Auto
Bool Property onlyOnce Auto
Bool Property onlyPlayer Auto
Float Property AV05_Value Auto
actorvalue Property AV05 Auto
Float Property AV02_Value Auto
actorvalue Property AV03 Auto
Float Property AV03_Value Auto
actorvalue Property AV01 Auto

Event OnTriggerEnter(ObjectReference akActionRef)
EndEvent

Function SetActorValues(actor akActor) Native
