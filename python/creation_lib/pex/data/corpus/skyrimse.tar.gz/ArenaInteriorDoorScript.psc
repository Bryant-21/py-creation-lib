Scriptname ArenaInteriorDoorScript Extends ReferenceAlias

objectreference Property OutsideMarker Auto

String Function GetState() Native
Function GotoState(String newState) Native
Function OnActivate(objectreference akActivator) Native
Function Setup() Native
