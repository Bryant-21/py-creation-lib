Scriptname CreationClub:VRWorkshops:VRWorkshopSummonVRSettlersScript Extends Quest

actorvalue Property WorkshopBellDistance Auto Const
referencealias Property Alias_SummonMarker Auto Const
refcollectionalias Property Alias_WorkshopNPCs Auto Const
Int Property StartupStage Auto Const
workshopparentscript Property WorkshopParent Auto Const
referencealias Property Alias_Workshop Auto Const
Bool Property IsAlarm Auto Const

Event OnStageSet(Int auiStageID, Int auiItemID)
EndEvent

Event OnTimerGameTime(Int aiTimerID)
EndEvent

Function StartUp() Native
