Scriptname DefaultRefOnUnload Extends DefaultRefParent

Event OnUnload()
EndEvent
