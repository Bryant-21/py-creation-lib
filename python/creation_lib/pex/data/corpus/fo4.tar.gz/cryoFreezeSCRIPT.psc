Scriptname cryoFreezeSCRIPT Extends ActiveMagicEffect

actorvalue Property pFreeze Auto
keyword Property pfrozenState02 Auto
effectshader Property MagicEffectShaderShatter Auto
actorvalue Property pHealth Auto
keyword Property pfrozenState01 Auto
Int Property frzMod Auto
Bool Property RANK3 Auto
actorvalue Property pAnimationMult Auto
Float Property ShaderDuration Auto
spell Property pCryoFreezeSpell Auto
Bool Property RANK2 Auto
Bool Property CRYOEFFECTREMOVER Auto

Event OnDying(actor Killer)
EndEvent

Event OnEffectFinish(actor akTarget, actor akCaster)
EndEvent

Event OnEffectStart(actor akTarget, actor akCaster)
EndEvent
