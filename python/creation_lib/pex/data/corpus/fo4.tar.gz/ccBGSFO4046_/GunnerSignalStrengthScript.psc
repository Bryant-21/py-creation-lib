Scriptname ccBGSFO4046_:GunnerSignalStrengthScript Extends Quest

Int Property RadioTime Auto Const
message Property SignalStrengthMessage Auto Const
worldspace Property Commonwealth Auto Const
Quest Property BestOfThreeQuest Auto Const
objectreference Property Transmitter Auto Const

Function OnQuestInit() Native
Function OnTimer(Int aiTimerID) Native
