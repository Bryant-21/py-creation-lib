Scriptname ArtilleryFakeProjectileScript Extends ObjectReference

weapon Property WorkShopArtilleryWeapon Auto
sound Property FXExplosionArtilleryMinutemen Auto

Event onLoad()
EndEvent
