Scriptname DefaultOnEnterMultiActor Extends ObjectReference

actorbase[] Property TriggerActors Auto
Bool Property bAllTargetsInTrigger Auto
Bool Property ShowTraces Auto
referencealias[] Property TriggerAliases Auto

Bool Function CheckTriggerRef(ObjectReference triggerRef) Native
Function modTargetCount(Int modValue) Native
Event OnInit()
EndEvent

Event onTriggerEnter(ObjectReference triggerRef)
EndEvent

Event OnTriggerLeave(ObjectReference triggerRef)
EndEvent

Function TriggerMe() Native
