Scriptname DefaultAliasOnTriggerLeave Extends DefaultAlias

referencealias[] Property TriggeredByAliases Auto
faction[] Property TriggeredByFactions Auto
Bool Property PlayerTriggerOnly Auto
objectreference[] Property TriggeredByReferences Auto

Event OnTriggerLeave(objectreference akActionRef)
EndEvent
