Scriptname CA_DB_Event12 Extends ca_dialoguebump_basescript

Function InitializeEventID() Native
