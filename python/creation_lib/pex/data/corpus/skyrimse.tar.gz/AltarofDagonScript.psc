Scriptname AltarofDagonScript Extends ObjectReference

ObjectReference Property ShrineofDagon Auto

String Function GetState() Native
Function GotoState(String newState) Native
Function OnActivate(ObjectReference akActionRef) Native
