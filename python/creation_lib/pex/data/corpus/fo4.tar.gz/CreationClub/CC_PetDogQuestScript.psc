Scriptname CreationClub:CC_PetDogQuestScript Extends Quest

perk Property CC_PetDogs_PetPerk Auto
idle Property PairedDogmeatHumanGreetPetKneel Auto
referencealias[] Property DogNames Auto
message Property RenameConfirmMsg Auto
idle Property PairedDogmeatHumanGreetHand Auto
perk Property CC_PetDogs_RenamePerk Auto

Function GivePlayerRenamePerk() Native
Function NameDog(objectreference dogToName) Native
Function NameDogWithConfirmation(objectreference dogToName) Native
Function PetDog(objectreference dogToPet) Native
