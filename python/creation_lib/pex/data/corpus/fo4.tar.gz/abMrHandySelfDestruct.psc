Scriptname abMrHandySelfDestruct Extends RobotSelfDestructScript

explosion Property selfDestructExplosionFX Auto Const
keyword Property bot_HasHandLeft Auto Const
keyword Property bot_HasHandMiddle Auto Const
keyword Property bot_HasHandRight Auto Const

Event OnActivate(objectreference akActionRef)
EndEvent

Event OnBeginState(String asOldState)
EndEvent

Event OnCombatStateChanged(actor akTarget, Int aeCombatState)
EndEvent

Event OnCripple(actorvalue akActorValue, Bool abCrippled)
EndEvent

Function ResetSelfDestruct() Native
