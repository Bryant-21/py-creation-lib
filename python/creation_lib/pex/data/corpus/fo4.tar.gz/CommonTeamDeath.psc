Scriptname CommonTeamDeath Extends Actor

objectreference Property TeamOwner Auto

Event onDeath(Actor killer)
EndEvent
