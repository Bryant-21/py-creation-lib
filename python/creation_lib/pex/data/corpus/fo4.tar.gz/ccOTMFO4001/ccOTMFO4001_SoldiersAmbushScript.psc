Scriptname ccOTMFO4001:ccOTMFO4001_SoldiersAmbushScript Extends Quest

Struct SoldiersStruct
    referencealias LocalAlias
    referencealias ExternalAlias
EndStruct

referencealias Property ClosestSettlementCenterMarker Auto
referencealias Property External_AmbushSoldierOrders Auto
referencealias Property Alias_Orders Auto
soldiersstruct[] Property AmbushSoldiers Auto
Float Property ClosestSettlementMinimumDistance Auto
Float Property AmbushDistance Auto

Function AddAliases() Native
Function DisableSoldiers() Native
Function MoveSquadIntoAmbushPositionAndEnable() Native
Function TryToPrepareAmbush() Native
