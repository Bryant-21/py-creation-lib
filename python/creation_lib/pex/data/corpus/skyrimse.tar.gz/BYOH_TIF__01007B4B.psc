Scriptname BYOH_TIF__01007B4B Extends TopicInfo

message Property FavorJobsBeggarMessage Auto
spell Property FavorJobsBeggarsAbility Auto

Function Fragment_0(ObjectReference akSpeakerRef) Native
String Function GetState() Native
Function GotoState(String newState) Native
