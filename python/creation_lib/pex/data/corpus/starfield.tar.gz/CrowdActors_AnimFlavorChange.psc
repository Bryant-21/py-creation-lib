Scriptname CrowdActors_AnimFlavorChange Extends Actor

keyword[] Property AnimFlavors Auto
globalvariable Property CrowdAnimFlavorChance Auto

Function OnLoad() Native
