Scriptname CZKillAliasScript Extends ReferenceAlias

Int Property StageToSetOnDeath Auto Const
Bool Property Decapitate Auto Const
Int Property StageToDie Auto Const
Float Property MaxAliveTime Auto Const
ReferenceAlias Property Killer Auto Const
Bool Property KillAfterNextOnHit Auto Const

Event OnAliasInit()
EndEvent

Event OnDeath(actor akKiller)
EndEvent

Event OnHit(objectreference akTarget, objectreference akAggressor, form akSource, projectile akProjectile, Bool abPowerAttack, Bool abSneakAttack, Bool abBashAttack, Bool abHitBlocked, String asMaterialName)
EndEvent

Event OnTimer(Int aiTimerID)
EndEvent
