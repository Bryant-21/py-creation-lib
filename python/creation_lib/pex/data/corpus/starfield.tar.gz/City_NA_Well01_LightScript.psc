Scriptname City_NA_Well01_LightScript Extends ReferenceAlias

objectreference Property Myself Auto
globalvariable Property MyGlobal Auto
quest Property City_NA_Well01 Auto

Function SwapState() Native
