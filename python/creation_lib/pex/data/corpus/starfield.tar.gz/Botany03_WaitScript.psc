Scriptname Botany03_WaitScript Extends Quest

Int Property StageToSet Auto

Function OnTimerGameTime(Int aiTimerID) Native
Function Wait24() Native
