Scriptname DefaultAliasOnTriggerEnter Extends DefaultAlias

Bool Property PlayerTriggerOnly Auto Const
referencealias[] Property TriggeredByAliases Auto Const
objectreference[] Property TriggeredByReferences Auto Const
faction[] Property TriggeredByFactions Auto Const

Event OnTriggerEnter(objectreference akActionRef)
EndEvent
