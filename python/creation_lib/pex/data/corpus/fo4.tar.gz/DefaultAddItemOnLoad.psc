Scriptname DefaultAddItemOnLoad Extends ObjectReference

Int Property Count Auto Const
form Property ItemToAdd Auto Const

Event OnLoad()
EndEvent
