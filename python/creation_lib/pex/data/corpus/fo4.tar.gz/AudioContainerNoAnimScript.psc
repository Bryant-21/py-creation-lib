Scriptname AudioContainerNoAnimScript Extends ObjectReference

sound Property OpenSound Auto
sound Property CloseSound Auto

Event OnLoad()
EndEvent

Event OnMenuOpenCloseEvent(String asMenuName, Bool abOpening)
EndEvent

Event OnUnload()
EndEvent
