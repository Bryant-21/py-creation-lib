Scriptname BoSDPQuestScript Extends Quest

globalvariable Property BoSX111Threshold Auto
Int Property CoolantPayout Auto
miscobject Property BoSTechnicalDocument Auto
objectreference Property BoS301IngramWorkingMarker Auto
referencealias Property BoSQuinlan Auto
globalvariable Property BoSEndgateQuinlan Auto
globalvariable Property BoSCoolantPay Auto
referencealias Property BoSMaxon Auto
objectreference Property BoSMaxsonCommandDeckMarker Auto
globalvariable Property BoSEndgateLi Auto
Int Property DocumentCurrentCount Auto
Int Property BloodPayout Auto
Int Property DocPayout Auto
globalvariable Property BoSEndgateNeriah Auto
globalvariable Property BoSEndgateHaylen Auto
globalvariable Property BoSDocPay Auto
miscobject Property BoSBloodSample Auto
miscobject Property Caps001 Auto
miscobject Property BoSReactorCoolant Auto
globalvariable Property BoSEndgateRhys Auto
globalvariable Property BoSEndgateCade Auto
referencealias Property BoSIngram Auto
globalvariable Property BoSEndgateTeagan Auto
globalvariable Property BoSEndgateIngram Auto
Int Property BloodCurrentCount Auto
globalvariable Property BoSNeriahRadDone Auto
Quest Property MQ206BoS Auto
globalvariable Property BoSBloodPay Auto
referencealias Property BoSNeriah Auto
Int Property CoolantCurrentCount Auto

Function BoSEndgates() Native
Function BoSTeleMove() Native
Function CashBlood() Native
Function CashCoolant() Native
Function CashDocs() Native
