Scriptname abProtectronRaceScript Extends ActiveMagicEffect

scene Property ProtectronVIPescortScene Auto Const
referencealias Property protectronAlias Auto Const
actorvalue Property ProtectronPodStatus Auto Const
Bool Property startInPod Auto
scene Property ProtectronPowerUpReceived Auto Const
scene Property ProtectronShutDownCompleted Auto Const
scene Property ProtectronShutDownReceived Auto Const
keyword Property linkProtectronPod Auto Const

Event OnActivate(objectreference akActionRef)
EndEvent

Event OnDistanceLessThan(objectreference akObj1, objectreference akObj2, Float afDistance)
EndEvent

Event OnEffectStart(actor akTarget, actor akCaster)
EndEvent

Event OnTimer(Int aiTimerID)
EndEvent

Bool Function shutDownAllScenes() Native
