Scriptname DebugActorHitTrackerScript Extends actor

Event OnDeath(actor akKiller)
EndEvent

Event OnHit(objectreference akTarget, objectreference akAggressor, form akSource, projectile akProjectile, Bool abPowerAttack, Bool abSneakAttack, Bool abBashAttack, Bool abHitBlocked, String asMaterialName)
EndEvent

Event OnLoad()
EndEvent

Event onUnload()
EndEvent

Function SetTrackingVars(objectreference akAggressor) Native
Function TraceAndMessage(String Text) Native
