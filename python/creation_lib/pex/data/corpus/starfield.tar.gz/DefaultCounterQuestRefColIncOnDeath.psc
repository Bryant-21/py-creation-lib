Scriptname DefaultCounterQuestRefColIncOnDeath Extends RefCollectionAlias

Int Property TargetRemainingCount Auto
Bool Property MaintainTargetValue Auto
Bool Property RemoveWhenDead Auto
Bool Property CheckForOnDyingInstead Auto
Int Property RemainingStage Auto

Function Increment(objectreference akSenderRef) Native
Event OnDeath(objectreference akSenderRef, objectreference akKiller)
EndEvent

Event OnDying(objectreference akSenderRef, objectreference akKiller)
EndEvent
