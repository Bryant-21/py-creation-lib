Scriptname CA_DB_Event18 Extends ca_dialoguebump_basescript

Function InitializeEventID() Native
