Scriptname DefaultAliasOnUnload Extends DefaultAliasParent

Event OnUnload()
EndEvent
