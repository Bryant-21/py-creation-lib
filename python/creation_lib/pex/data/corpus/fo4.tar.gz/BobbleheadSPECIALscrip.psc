Scriptname BobbleheadSPECIALscrip Extends ObjectReference

quest Property PerksQuest Auto
Int Property stage Auto

Event OnActivate(ObjectReference akActionRef)
EndEvent
