Scriptname CreationClub:BGSFO4019:ccBGSF04019_ArmorScript Extends ObjectReference

spell Property SpellPA_Stealth Auto

Function OnEquipped(actor akActor) Native
Function OnUnequipped(actor akActor) Native
