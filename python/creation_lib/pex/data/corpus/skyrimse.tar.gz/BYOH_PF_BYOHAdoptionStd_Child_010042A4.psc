Scriptname BYOH_PF_BYOHAdoptionStd_Child_010042A4 Extends Package

globalvariable Property GameHour Auto

Function Fragment_0(Actor akActor) Native
String Function GetState() Native
Function GotoState(String newState) Native
