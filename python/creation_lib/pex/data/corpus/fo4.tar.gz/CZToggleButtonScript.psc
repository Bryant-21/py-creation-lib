Scriptname CZToggleButtonScript Extends ObjectReference

globalvariable Property CZLift2Active Auto Const
Bool Property shouldAutoReset Auto Const
Bool Property IsLiftOne Auto Const
String Property inactiveStateAnimation Auto Const
globalvariable Property CZLift1Active Auto Const
message Property ToggleButtonInactiveMessage Auto
dn134questscript Property DN134 Auto Const
Bool Property playerActivationOnly Auto Const
String Property animationName Auto Const
String Property activeStateAnimation Auto Const

Function CheckIfShouldBeActive() Native
Event OnActivate(ObjectReference akActionRef)
EndEvent

Event OnBeginState(String asOldState)
EndEvent

Event OnLoad()
EndEvent

Event OnUnload()
EndEvent

Function SetBusy(Bool shouldBeBusy, Bool returnToActive = True) Native
