Scriptname DebugSoundScriptingQuest Extends Quest

Float Property InstanceRTPCValue2 Auto
Float Property GlobalRTPCValue2 Auto
wwiseevent Property EventForm3 Auto
message Property TEST_SoundScriptingWarning Auto
referencealias Property ThreeDPost_Switch_On Auto
wwiseevent Property EventForm1 Auto
wwiseevent Property EventForm2 Auto
Float Property GlobalRTPCValue1 Auto
Float Property InstanceRTPCValue1 Auto

Function TriggerButtonBehavior(Int iButtonIndex) Native
