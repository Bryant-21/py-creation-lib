Scriptname DefaultAliasOnHit Extends DefaultAlias

Bool Property SpellHits_HostileOnly Auto

Event OnAliasInit()
EndEvent

Event OnHit(objectreference akTarget, objectreference akAggressor, form akSource, projectile akProjectile, Bool abPowerAttack, Bool abSneakAttack, Bool abBashAttack, Bool abHitBlocked, String apMaterial)
EndEvent

Function OnLoad() Native
Function OnUnload() Native
