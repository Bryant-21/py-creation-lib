Scriptname CompanionActorScript Extends Actor

sq_companionsscript Property SQ_Companions Auto
activator Property COM_PQ_TxtReplace_QuestName Auto
globalvariable Property COM_CompanionID Auto
com_companionquestscript Property COM_CompanionQuest Auto
keyword Property COM_PreventStoryGateScenes Auto
actorvalue Property COM_Affinity Auto

Function AddAffinity(Int AmountToAdd) Native
Function AllowStoryGatesAndRestartTimer() Native
globalvariable Function GetCompanionIDGlobal() Native
Float Function GetCompanionIDValue() Native
Int Function GetCompanionIDValueInt() Native
Bool Function HasGreaterAffinityThanTestedCompanion(CompanionActorScript TestedCompanion) Native
Bool Function IsRomantic() Native
Event OnDeath(objectreference akKiller)
EndEvent

Function RestartStoryGateTimer(Int nextStoryGate) Native
Function SetGlobalToCompanionID(globalvariable GlobalToSet) Native
Bool Function Trace(ScriptObject CallingObject, String asTextToPrint, Int aiSeverity, String MainLogName, String SubLogName, Bool bShowNormalTrace, Bool bShowWarning, Bool bPrefixTraceWithLogNames) Native
Bool Function warning(ScriptObject CallingObject, String asTextToPrint, Int aiSeverity, String MainLogName, String SubLogName, Bool bShowNormalTrace, Bool bShowWarning, Bool bPrefixTraceWithLogNames) Native
