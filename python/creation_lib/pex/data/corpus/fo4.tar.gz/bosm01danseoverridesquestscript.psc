Scriptname bosm01danseoverridesquestscript Extends Quest

referencealias Property BoSPaladinDanse Auto Const
referencealias Property FollowersQuestCompanion Auto Const

Function BeginDanseScene() Native
Function EndDanseScene() Native
Event OnTimer(Int timerID)
EndEvent
