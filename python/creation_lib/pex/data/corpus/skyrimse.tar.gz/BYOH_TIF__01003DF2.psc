Scriptname BYOH_TIF__01003DF2 Extends TopicInfo

faction Property BYOHRelationshipAdoptableFaction Auto

Function Fragment_0(ObjectReference akSpeakerRef) Native
String Function GetState() Native
Function GotoState(String newState) Native
