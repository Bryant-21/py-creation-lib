Scriptname CastleArmoryTriggerScript Extends ObjectReference

weapon Property BoSVertibirdGrenade Auto Const
globalvariable Property MinArtilleryCanBuild Auto Const
globalvariable Property BoSFastTravelPilot Auto Const
quest Property Min01 Auto Const
weapon Property ArtillerySmokeFlare Auto Const
ammo Property AmmoFlareGun Auto Const

Event OnLoad()
EndEvent

Event OnTriggerEnter(ObjectReference akActionRef)
EndEvent

Function RefreshSmokeFlares() Native
