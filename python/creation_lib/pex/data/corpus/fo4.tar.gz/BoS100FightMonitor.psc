Scriptname BoS100FightMonitor Extends Quest

referencealias Property Ghoul04 Auto Const
objectreference[] Property RespawnMarkersNear Auto Const
Int Property EndSecondWaveStageToSet Auto Const
referencealias Property Ghoul03 Auto Const
referencealias Property Rhys Auto Const
Int Property EndFightStageToSet Auto Const
actorvalue Property Health Auto Const
referencealias Property Danse Auto Const
actorvalue Property Aggression Auto Const
referencealias Property GhoulBoss Auto Const
referencealias Property Ghoul01 Auto Const
keyword Property BoS100FightGhoulKeyword Auto Const
actor[] Property AllGhouls Auto
refcollectionalias Property CollegeSquareExteriorGhouls Auto
Int Property EndSecondWaveDeathCount Auto Const
Int Property minRespawnDistance Auto
Float Property respawnTimeMin Auto
referencealias Property Ghoul02 Auto Const
Float Property respawnTimeMax Auto
objectreference Property RespawnMarkerFailsafe Auto Const
Int Property BossSpawnStageToSet Auto Const
Int Property BossSpawnDeathCount Auto Const
referencealias Property Haylen Auto Const
objectreference[] Property RespawnMarkersFar Auto Const

Function AddToAllGhouls(actor ghoul) Native
Function CleanupGhouls() Native
Function FinishRespawning(referencealias aliasToRespawn) Native
Function ForceKillGhouls() Native
Int Function GetCountOfLivingGhouls() Native
objectreference Function GetRespawnMarker(objectreference[] markers) Native
Function GhoulOnDeath(actor akSender, actor akKiller) Native
Event OnInit()
EndEvent

Event OnTimer(Int timer)
EndEvent

Function ReduceRespawnRadius() Native
Function RegisterGhoul(actor ghoul) Native
Function Respawn(referencealias aliasToRespawn) Native
Function SpawnBoss() Native
Function StartFightMonitor() Native
Function TryToRespawn(referencealias aliasToRespawn) Native
