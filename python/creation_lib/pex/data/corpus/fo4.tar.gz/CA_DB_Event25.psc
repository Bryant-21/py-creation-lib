Scriptname CA_DB_Event25 Extends ca_dialoguebump_basescript

Function InitializeEventID() Native
