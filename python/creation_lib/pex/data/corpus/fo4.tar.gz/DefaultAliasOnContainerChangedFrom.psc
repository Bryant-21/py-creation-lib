Scriptname DefaultAliasOnContainerChangedFrom Extends DefaultAlias

referencealias[] Property ItemChangedFromAliases Auto
objectreference[] Property ItemChangedFromReferences Auto
faction[] Property ItemChangedFromFactions Auto

Event OnContainerChanged(objectreference akNewContainer, objectreference akOldContainer)
EndEvent
