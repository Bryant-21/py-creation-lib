Scriptname DefaultAliasOnLockStateChanged Extends DefaultAlias

Bool Property CheckForUnlock Auto

Event OnLockStateChanged()
EndEvent
