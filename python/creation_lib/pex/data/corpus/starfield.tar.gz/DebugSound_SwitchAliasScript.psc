Scriptname DebugSound_SwitchAliasScript Extends ReferenceAlias

Int Property ButtonIndex Auto

Function OnActivate(objectreference akActionRef) Native
