Scriptname ccOTMFO4001:ccOTMFO4001_BloodMarkerObjTrigScript Extends ObjectReference

Int Property ShutDownStage Auto Const
ccotmfo4001:ccotmfo4001_questscript Property ccOTMFO4001_Quest Auto Const
Int Property BloodMarkerNumber Auto Const
Int Property ActiveStage Auto Const

Function OnTriggerEnter(ObjectReference TriggerRef) Native
