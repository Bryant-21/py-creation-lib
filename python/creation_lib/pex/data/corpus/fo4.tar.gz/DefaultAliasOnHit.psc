Scriptname DefaultAliasOnHit Extends DefaultAlias

Bool Property PlayerHitOnly Auto
referencealias[] Property HitByAliases Auto
faction[] Property HitByFactions Auto
objectreference[] Property HitByReferences Auto

Event OnAliasInit()
EndEvent

Event OnHit(objectreference akTarget, objectreference akAggressor, form akSource, projectile akProjectile, Bool abPowerAttack, Bool abSneakAttack, Bool abBashAttack, Bool abHitBlocked, String asMaterialName)
EndEvent
