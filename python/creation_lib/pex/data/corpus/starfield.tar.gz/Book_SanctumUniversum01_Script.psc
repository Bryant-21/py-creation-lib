Scriptname Book_SanctumUniversum01_Script Extends ObjectReference

quest Property City_NA_Aquilus01 Auto
globalvariable Property City_NA_Aquilus01_BookRead Auto

Function OnActivate(ObjectReference ActionRef) Native
Function OnRead() Native
