Scriptname AddFactionToLinkedRefOnTrigger Extends ObjectReference

faction Property FactionToAdd Auto
keyword Property LinkKeyword Auto

Function OnTriggerEnter(ObjectReference akActionRef) Native
