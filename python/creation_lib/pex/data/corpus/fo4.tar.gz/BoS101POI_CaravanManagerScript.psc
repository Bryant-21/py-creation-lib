Scriptname BoS101POI_CaravanManagerScript Extends ObjectReference

quest Property BoS101POI Auto Const

Event OnLoad()
EndEvent

Event OnTimer(Int timerID)
EndEvent
