Scriptname DefaultActivateLinkOnUnlock Extends ObjectReference

keyword Property MyLink Auto Const

Event OnLockStateChanged()
EndEvent
