Scriptname CA_QuestScript Extends Quest

Struct EventDatum
    Int Stage
    Bool Optional_CheckCompanionProximity
    objectreference Optional_Target
    keyword EventKeyword
    globalvariable Optional_Size
    Float ResponseDelay
EndStruct

Int Property Stage Auto Const
Bool Property Optional_CheckCompanionProximity Auto Const
objectreference Property Optional_Target Auto Const
keyword Property EventKeyword Auto Const
eventdatum[] Property EventData Auto Const
globalvariable Property Optional_Size Auto Const
Float Property ResponseDelay Auto Const

Event OnStageSet(Int auiStageID, Int auiItemID)
EndEvent
