Scriptname CZRuleBreakerScript Extends Actor

Event OnLoad()
EndEvent
