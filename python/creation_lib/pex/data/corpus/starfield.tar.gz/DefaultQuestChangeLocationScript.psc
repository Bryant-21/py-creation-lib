Scriptname DefaultQuestChangeLocationScript Extends Quest

Struct ChangeLocationStage
    Bool RequireExactLocation
    Bool CheckPlayerShip
    Int TurnOffStage
    Int PrereqStage
    Bool SetStageOnEnterLocation
    Int StageToSet
    locationalias TargetLocationAlias
    location TargetLocation
EndStruct

changelocationstage[] Property ChangeLocationStages Auto
Int Property OverridePrereqStage Auto
sq_playershipscript Property SQ_PlayerShip Auto

Function CheckLocation(location TargetLocation, changelocationstage changeLocData, location akOldLoc, location akNewLoc, Bool isPlayerShip) Native
Function CheckLocationStages(location akOldLoc, location akNewLoc, Bool isPlayerShip) Native
Event OnQuestInit()
EndEvent
