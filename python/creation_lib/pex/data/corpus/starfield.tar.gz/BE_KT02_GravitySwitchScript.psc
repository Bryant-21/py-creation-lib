Scriptname BE_KT02_GravitySwitchScript Extends ObjectReference

refcollectionalias Property Alias_AllCrew Auto
bescript Property BE_KT02 Auto
referencealias Property Alias_Minibot Auto
referencealias Property Alias_EnableMarker Auto
wwiseevent Property PowerOFF Auto
wwiseevent Property PowerON Auto

Function GravitySwitch() Native
Function OnActivate(ObjectReference akActionRef) Native
