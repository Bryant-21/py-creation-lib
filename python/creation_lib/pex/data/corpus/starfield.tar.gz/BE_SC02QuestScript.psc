Scriptname BE_SC02QuestScript Extends Quest

voicetype[] Property MutineersWhoKillCaptain Auto
referencealias Property Mutineer Auto
referencealias Property Captain Auto
actorvalue Property Health Auto
reparentscript Property RE_Parent Auto

Function SetupCaptain() Native
