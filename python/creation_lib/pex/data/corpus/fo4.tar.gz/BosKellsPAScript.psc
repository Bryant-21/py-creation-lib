Scriptname BosKellsPAScript Extends Quest

globalvariable Property KellsPABlocked Auto Const
globalvariable Property KellsPACooldown Auto Const
scene Property BoS_KellsPA_Scene Auto Const

Function CancelKellsPATimer() Native
Function FireScene() Native
Event OnTimerGameTime(Int aiTimerID)
EndEvent

Function StartKellsPATimer() Native
