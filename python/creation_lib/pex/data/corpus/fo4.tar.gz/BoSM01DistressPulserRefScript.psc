Scriptname BoSM01DistressPulserRefScript Extends ObjectReference

quest Property BoSM01DistressSignals Auto
quest Property BoSM01 Auto

Event OnLoad()
EndEvent
