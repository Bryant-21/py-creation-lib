Scriptname CA_DB_Event22 Extends ca_dialoguebump_basescript

Function InitializeEventID() Native
