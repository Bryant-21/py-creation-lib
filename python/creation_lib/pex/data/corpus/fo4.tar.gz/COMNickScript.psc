Scriptname COMNickScript Extends Quest

Int Property iInfatuationResponse Auto
keyword Property COMNickMysteriousStrangerTopic Auto
referencealias Property NickValentine Auto
Int Property iPlayerApologized Auto
Bool Property bPlayerKnowsNicksPast Auto
globalvariable Property COMNickStrangerThresholdMax Auto
Int Property CompanionDistance Auto

Event OnInit()
EndEvent

Event OnTrackedStatsEvent(String asStat, Int aiStatValue)
EndEvent
