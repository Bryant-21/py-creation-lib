Scriptname DefaultRefOnLockStateChanged Extends DefaultRefParent

Bool Property CheckForUnlock Auto

Event OnLockStateChanged()
EndEvent
