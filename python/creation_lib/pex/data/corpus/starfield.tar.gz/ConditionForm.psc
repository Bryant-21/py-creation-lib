Scriptname ConditionForm Extends Form

Bool Function IsTrue(objectreference akRefObject, objectreference akTargetObject) Native
