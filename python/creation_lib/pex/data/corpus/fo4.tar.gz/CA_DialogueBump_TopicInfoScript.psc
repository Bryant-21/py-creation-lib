Scriptname CA_DialogueBump_TopicInfoScript Extends TopicInfo

String Property Description Auto Const
keyword[] Property CA_CustomEvents Auto Const
