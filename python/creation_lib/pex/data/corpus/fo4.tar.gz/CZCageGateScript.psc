Scriptname CZCageGateScript Extends ReferenceAlias

Int Property EndStage Auto Const
quest Property CZ Auto Const
Int Property PreReqStage Auto Const
scene Property CZ_TommyInCage_Scene Auto Const

Event OnActivate(objectreference akActionRef)
EndEvent

Event OnInit()
EndEvent
