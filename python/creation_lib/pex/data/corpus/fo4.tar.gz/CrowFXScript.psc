Scriptname CrowFXScript Extends ObjectReference

Function FlapSpeedBump(Float akBumpTime) Native
Function NewTranslationPoint(Int akDistance, Int akHeight, Float akXrot) Native
Event OnBeginState(String asOldState)
EndEvent

Event OnHit(ObjectReference akTarget, ObjectReference akAggressor, form akSource, projectile akProjectile, Bool abPowerAttack, Bool abSneakAttack, Bool abBashAttack, Bool abHitBlocked, String asMaterialName)
EndEvent

Event OnLoad()
EndEvent

Event OnTranslationAlmostComplete()
EndEvent

Event OnTriggerEnter(ObjectReference akActionRef)
EndEvent

Event onUnload()
EndEvent
