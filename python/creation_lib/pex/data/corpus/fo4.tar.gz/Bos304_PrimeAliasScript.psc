Scriptname Bos304_PrimeAliasScript Extends ReferenceAlias

quest Property DNPrime_BoS304 Auto
Int Property myStage Auto
Int Property myStageEnd Auto

Event OnAnimationEvent(objectreference akSource, String asEventName)
EndEvent

Event OnLoad()
EndEvent
