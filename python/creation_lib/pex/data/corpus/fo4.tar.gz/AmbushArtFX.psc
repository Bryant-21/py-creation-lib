Scriptname AmbushArtFX Extends Actor

explosion Property FurnitureMirelurkSiltExplosion Auto Const
objectreference Property myWaterLevelMarker Auto Const
Float Property WaitToSplash Auto Const
effectshader Property myEffectShaderParticles Auto
keyword Property MirelurkAmbushWaterKeyword Auto
explosion Property myExplosion Auto Const
armor Property PSkinMirelurkDirtGravel Auto Const
effectshader Property mySplashShaderParticles Auto
explosion Property myWaterExplosion Auto Const

Event OnAnimationEvent(objectreference source, String eventName)
EndEvent

Event OnDying(Actor akKiller)
EndEvent

Event OnLoad()
EndEvent
