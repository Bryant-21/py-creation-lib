Scriptname City_Neon_Drug01_QuestScript Extends Quest

referencealias Property Drug01_NesharAlias Auto
referencealias Property Drug01_NeonJailDoor Auto

Function OnQuestInit() Native
Function UnregisterForExteriorDoorEvents() Native
