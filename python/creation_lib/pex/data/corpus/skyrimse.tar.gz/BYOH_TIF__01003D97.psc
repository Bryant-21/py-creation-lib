Scriptname BYOH_TIF__01003D97 Extends TopicInfo

miscobject Property Gold Auto
objectreference Property DecorateMarker Auto
globalvariable Property HDWindhelmArmory Auto
Int Property GoldAmount Auto

Function Fragment_0(objectreference akSpeakerRef) Native
String Function GetState() Native
Function GotoState(String newState) Native
