Scriptname DefaultAliasOnEquipped Extends DefaultAlias

Event OnEquipped(actor akActor)
EndEvent
