Scriptname CZStageControllerScript Extends ObjectReference

Struct SequenceAction
    Float Main1LightTarget
    Float Main3LightTarget
    Int upLightState
    Float UpSpeed
    Int UpAction
    Bool Main3hasLightSequence
    Float DownLightTarget
    Float SequenceTimer
    Int Main2Action
    Int Main1LightState
    Float Main2LightRamp
    Float upLightTarget
    Float upLightRamp
    Bool OverrideOrders
    Bool Main1hasLightSequence
    Int DownLightState
    Int Main3LightState
    Int Main1Action
    Bool Definition
    Float DownSpeed
    Bool Main2hasLightSequence
    Float DownLightRamp
    Int DownAction
    Bool UphasLightSequence
    Int Main3Action
    Float Main2LightTarget
    Float MainSpeed
    Bool iiiiiiiiiiiiiiUPiiiiiiiiiiiiii
    Float Main3LightRamp
    Float Main1LightRamp
    Bool iiiiiiiiiiiiiiMAINiiiiiiiiiiiiii
    Bool iiiiiiiiiiiiiiDOWNiiiiiiiiiiiiii
    Bool DownhasLightSequence
    Int Main2LightState
EndStruct

sequenceaction[] Property Sequence13 Auto Const
sequenceaction[] Property Sequence2 Auto Const
sequenceaction[] Property Sequence8 Auto Const
sequenceaction[] Property Sequence14 Auto Const
quest Property CZ_Arena Auto Const
czspotlightscript Property Spotlight2 Auto Const
czspotlightscript[] Property StageLights Auto Const
referencealias Property Tommy Auto Const
czspotlightscript[] Property UpperLights Auto Const
referencealias Property CaitsCombatant Auto Const
Int[] Property ValidAmbientSequences Auto
sequenceaction[] Property Sequence19 Auto Const
sequenceaction[] Property Sequence12 Auto Const
sequenceaction[] Property Sequence16 Auto Const
Int[] Property ValidFightSequences Auto
sequenceaction[] Property Sequence18 Auto Const
sequenceaction[] Property Sequence11 Auto Const
referencealias Property Combatant1 Auto Const
sequenceaction[] Property Sequence3 Auto Const
sequenceaction[] Property Sequence5 Auto Const
referencealias Property Ringmaster Auto Const
czspotlightscript Property Spotlight3 Auto Const
globalvariable Property CZ_CaitIntroDone Auto Const
sequenceaction[] Property Sequence10 Auto Const
sequenceaction[] Property Sequence20 Auto Const
sequenceaction[] Property Sequence1 Auto Const
referencealias Property Combatant2 Auto Const
sequenceaction[] Property Sequence15 Auto Const
referencealias Property Cait Auto Const
czspotlightscript Property Spotlight1 Auto Const
sequenceaction[] Property Sequence7 Auto Const
sequenceaction[] Property Sequence4 Auto Const
sequenceaction[] Property Sequence9 Auto Const
sequenceaction[] Property Sequence6 Auto Const
sequenceaction[] Property Sequence17 Auto Const
czspotlightscript Property Spotlight4 Auto Const

Function AddSequenceToQueue(Int SequenceNumber) Native
Function AllLightsOff() Native
Int[] Function CheckSequences(Int[] PotentiallyValidSequences) Native
Function ClearSequenceQueue() Native
Function CountSequenceDone() Native
Function EndCaitIntro() Native
czspotlightscript[] Function FillLightArray(objectreference[] LightArray) Native
sequenceaction[] Function GetSequence(Int SequenceNumber) Native
Bool Function IncrementSequenceQueue() Native
Function Init() Native
Event OnCellAttach()
EndEvent

Event OnCellDetach()
EndEvent

Event OnTimer(Int aiTimerID)
EndEvent

Int Function RandomElement(Int[] iArray) Native
Function RunNextSequenceAction() Native
Function RunSequenceAction(sequenceaction[] mySeq) Native
Function SpotlightCombatant1(Bool ShouldSpotlight = true) Native
Function SpotlightCombatant2(Bool ShouldSpotlight = true) Native
Function SpotlightOther(ObjectReference refToLight, Bool ShouldSpotlight = true) Native
Function SpotlightRingmaster(Bool ShouldSpotlight = true) Native
Function StartAmbientLights() Native
Function StartCaitIntro() Native
Function StartFight() Native
Function StartSequenceQueue() Native
Function StopAmbientLights() Native
Function StopFight() Native
Function TestSeq(Int SequenceNumber) Native
