Scriptname BHExtBOSEnable Extends ObjectReference

keyword Property LinkCustom01 Auto
keyword Property LinkCustom02 Auto
Int Property stage Auto
quest Property Inst302Combat Auto

Event OnTriggerEnter(ObjectReference akActionRef)
EndEvent
