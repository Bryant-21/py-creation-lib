Scriptname DefaultTutorialQuestScript Extends Quest

Struct TutorialMessageDatum
    Float DelayTime
    String asEventNext
    message TutorialMessage
    Int aiPriority
    String asContext
    Int aiMaxTimes
    Int AfInterval
    Int AfDuration
    message TutorialMessageMouseAndKeyboardSpecific
    String asUserEventToEnd
    String asEvent
    Bool AlwaysShow
    Bool DelayFinished
    Bool TutorialSeen
EndStruct

tutorialmessagedatum[] Property TutorialMessageData Auto
globalvariable Property TutorialAllowedGlobal Auto

Function DoShowMessage(Int iFound) Native
Function OnTimer(Int aiTimerID) Native
Function ResetAll() Native
Function ResetTutorial(String EventName) Native
Function ShowHelpMessage(String EventName) Native
Function UnshowHelpMessage(String EventName) Native
