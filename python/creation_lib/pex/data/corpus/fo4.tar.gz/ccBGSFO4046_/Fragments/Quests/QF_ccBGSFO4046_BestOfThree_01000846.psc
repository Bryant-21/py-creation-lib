Scriptname ccBGSFO4046_:Fragments:Quests:QF_ccBGSFO4046_BestOfThree_01000846 Extends Quest

actorbase[] Property CreaturesToPlace Auto
perk Property GunnerPerk Auto
leveleditem Property TesCanLeveledItem Auto
formlist Property ModListScrap Auto
Quest Property VaultTecTransmitter Auto
Int Property IntLevel Auto
projectile[] Property TesCanProjectile Auto
form Property TesCanWeapon Auto
actor Property GunnerThreeRef Auto
referencealias Property TeslaCannonAlias Auto
formlist Property TrapExplOnHit Auto
Quest Property GunnerSignal Auto
leveleditem[] Property npclists Auto
formlist Property TrapExplGasWeapon Auto
objectreference Property GunnerCaroniREF Auto

Function Fragment_Stage_0002_Item_00() Native
Function Fragment_Stage_0005_Item_00() Native
Function Fragment_Stage_0006_Item_00() Native
Function Fragment_Stage_0007_Item_00() Native
Function Fragment_Stage_0010_Item_00() Native
Function Fragment_Stage_0015_Item_00() Native
Function Fragment_Stage_0018_Item_00() Native
Function Fragment_Stage_0020_Item_00() Native
Function Fragment_Stage_0022_Item_00() Native
Function Fragment_Stage_0025_Item_00() Native
Function Fragment_Stage_0030_Item_00() Native
