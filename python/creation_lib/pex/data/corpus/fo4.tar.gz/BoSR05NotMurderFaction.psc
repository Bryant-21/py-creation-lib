Scriptname BoSR05NotMurderFaction Extends Quest

refcollectionalias Property NotMurderFactionBosses Auto Const
locationalias Property Settlement Auto Const
referencealias Property Workshop Auto Const
workshopparentscript Property WorkshopParent Auto Const

Event OnQuestInit()
EndEvent
