Scriptname damageAVonLoad Extends ObjectReference

actorvalue Property LeftMobilityCondition Auto Const
actorvalue Property RightMobilityCondition Auto Const

Event OnLoad()
EndEvent
