Scriptname Actor Extends ObjectReference

Int Property CritStage_DisintegrateStart Auto
Int Property CritStage_None Auto
Int Property CritStage_DisintegrateEnd Auto
Int Property CritStage_GooEnd Auto
Int Property CritStage_GooStart Auto

Function AddPerk(Perk akPerk) Native
Bool Function AddShout(Shout akShout) Native
Bool Function AddSpell(Spell akSpell, Bool abVerbose = true) Native
Function AddToFaction(Faction akFaction) Native
Function AllowBleedoutDialogue(Bool abCanTalk) Native
Function AllowPCDialogue(Bool abTalk) Native
Function AttachAshPile(Form akAshPileBase = None) Native
Bool Function CanFlyHere() Native
Function ClearArrested() Native
Function ClearExpressionOverride() Native
Function ClearExtraArrows() Native
Function ClearForcedLandingMarker() Native
Function ClearForcedMovement() Native
Function ClearKeepOffsetFromActor() Native
Function ClearLookAt() Native
Function DamageActorValue(String asValueName, Float afDamage) Native
Function DamageAV(String asValueName, Float afDamage) Native
Bool Function Dismount() Native
Function DispelAllSpells() Native
Bool Function DispelSpell(Spell akSpell) Native
Function DoCombatSpellApply(Spell akSpell, ObjectReference akTarget) Native
Function DrawWeapon() Native
Function EnableAI(Bool abEnable = true) Native
Function EndDeferredKill() Native
Function EquipItem(Form akItem, Bool abPreventRemoval = false, Bool abSilent = false) Native
Function EquipShout(Shout akShout) Native
Function EquipSpell(Spell akSpell, Int aiSource) Native
Function EvaluatePackage() Native
Function ForceActorValue(String asValueName, Float afNewValue) Native
Function ForceAV(String asValueName, Float afNewValue) Native
Function ForceMovementDirection(Float afXAngle = 0.0, Float afYAngle = 0.0, Float afZAngle = 0.0) Native
Function ForceMovementDirectionRamp(Float afXAngle = 0.0, Float afYAngle = 0.0, Float afZAngle = 0.0, Float afRampTime = 0.1) Native
Function ForceMovementRotationSpeed(Float afXMult = 0.0, Float afYMult = 0.0, Float afZMult = 0.0) Native
Function ForceMovementRotationSpeedRamp(Float afXMult = 0.0, Float afYMult = 0.0, Float afZMult = 0.0, Float afRampTime = 0.1) Native
Function ForceMovementSpeed(Float afSpeedMult) Native
Function ForceMovementSpeedRamp(Float afSpeedMult, Float afRampTime = 0.1) Native
Function ForceTargetAngle(Float afXAngle = 0.0, Float afYAngle = 0.0, Float afZAngle = 0.0) Native
Function ForceTargetDirection(Float afXAngle = 0.0, Float afYAngle = 0.0, Float afZAngle = 0.0) Native
Function ForceTargetSpeed(Float afSpeed) Native
actorbase Function GetActorBase() Native
Float Function GetActorValue(String asValueName) Native
Float Function GetActorValueMax(String asValueName) Native
Float Function GetActorValuePercentage(String asValueName) Native
Float Function GetAV(String asValueName) Native
Float Function GetAVMax(String asValueName) Native
Float Function GetAVPercentage(String asValueName) Native
Float Function GetBaseActorValue(String asValueName) Native
Float Function GetBaseAV(String asValueName) Native
Int Function GetBribeAmount() Native
Int Function GetCombatState() Native
Actor Function GetCombatTarget() Native
Faction Function GetCrimeFaction() Native
Package Function GetCurrentPackage() Native
Actor Function GetDialogueTarget() Native
Armor Function GetEquippedArmorInSlot(Int aiSlot) Native
Int Function GetEquippedItemType(Int aiHand) Native
Armor Function GetEquippedShield() Native
Shout Function GetEquippedShout() Native
Spell Function GetEquippedSpell(Int aiSource) Native
Weapon Function GetEquippedWeapon(Bool abLeftHand = 0) Native
Int Function GetFactionRank(Faction akFaction) Native
Int Function GetFactionReaction(Actor akOther) Native
Int Function GetFlyingState() Native
ObjectReference Function GetForcedLandingMarker() Native
Int Function GetGoldAmount() Native
Int Function GetHighestRelationshipRank() Native
Actor Function GetKiller() Native
Int Function GetLevel() Native
actorbase Function GetLeveledActorBase() Native
Float Function GetLightLevel() Native
Int Function GetLowestRelationshipRank() Native
Bool Function GetNoBleedoutRecovery() Native
Bool Function GetPlayerControls() Native
Race Function GetRace() Native
Int Function GetRelationshipRank(Actor akOther) Native
Int Function GetSitState() Native
Int Function GetSleepState() Native
String Function GetState() Native
Float Function GetVoiceRecoveryTime() Native
Float Function GetWarmthRating() Native
Function GotoState(String newState) Native
Bool Function HasAssociation(AssociationType akAssociation, Actor akOther = None) Native
Bool Function HasFamilyRelationship(Actor akOther = None) Native
Bool Function HasLOS(ObjectReference akOther) Native
Bool Function HasMagicEffect(MagicEffect akEffect) Native
Bool Function HasMagicEffectWithKeyword(Keyword akKeyword) Native
Bool Function HasParentRelationship(Actor akOther) Native
Bool Function HasPerk(Perk akPerk) Native
Bool Function HasSpell(Form akForm) Native
Bool Function IsAlarmed() Native
Bool Function IsAlerted() Native
Bool Function IsAllowedToFly() Native
Bool Function IsArrested() Native
Bool Function IsArrestingTarget() Native
Bool Function IsBeingRidden() Native
Bool Function IsBleedingOut() Native
Bool Function IsBribed() Native
Bool Function IsChild() Native
Bool Function IsCommandedActor() Native
Bool Function IsDead() Native
Bool Function IsDetectedBy(Actor akOther) Native
Bool Function IsDoingFavor() Native
Bool Function IsEquipped(Form akItem) Native
Bool Function IsEssential() Native
Bool Function IsFlying() Native
Bool Function IsGhost() Native
Bool Function IsGuard() Native
Bool Function IsHostileToActor(Actor akActor) Native
Bool Function IsInCombat() Native
Bool Function IsInFaction(Faction akFaction) Native
Bool Function IsInKillMove() Native
Bool Function IsIntimidated() Native
Bool Function IsOnMount() Native
Bool Function IsOverEncumbered() Native
Bool Function IsPlayersLastRiddenHorse() Native
Bool Function IsPlayerTeammate() Native
Bool Function IsRunning() Native
Bool Function IsSneaking() Native
Bool Function IsSprinting() Native
Bool Function IsTrespassing() Native
Bool Function IsUnconscious() Native
Bool Function IsWeaponDrawn() Native
Function KeepOffsetFromActor(Actor arTarget, Float afOffsetX, Float afOffsetY, Float afOffsetZ, Float afOffsetAngleX, Float afOffsetAngleY, Float afOffsetAngleZ, Float afCatchUpRadius, Float afFollowRadius) Native
Function Kill(Actor akKiller = None) Native
Function KillEssential(Actor akKiller = None) Native
Function KillSilent(Actor akKiller = None) Native
Function MakePlayerFriend() Native
Function ModActorValue(String asValueName, Float afAmount) Native
Function ModAV(String asValueName, Float afAmount) Native
Function ModFactionRank(Faction akFaction, Int aiMod) Native
Function ModFavorPoints(Int iFavorPoints = 1) Native
Function ModFavorPointsWithGlobal(GlobalVariable FavorPointsGlobal) Native
Function MoveToPackageLocation() Native
Event OnCombatStateChanged(Actor akTarget, Int aeCombatState)
EndEvent

Event OnDeath(Actor akKiller)
EndEvent

Event OnDying(Actor akKiller)
EndEvent

Event OnEnterBleedout()
EndEvent

Event OnGetUp(ObjectReference akFurniture)
EndEvent

Event OnLocationChange(Location akOldLoc, Location akNewLoc)
EndEvent

Function OnLycanthropyStateChanged(Bool abIsWerewolf) Native
Function OnObjectEquipped(Form akBaseObject, ObjectReference akReference) Native
Function OnObjectUnequipped(Form akBaseObject, ObjectReference akReference) Native
Event OnPackageChange(Package akOldPackage)
EndEvent

Event OnPackageEnd(Package akOldPackage)
EndEvent

Event OnPackageStart(Package akNewPackage)
EndEvent

Function OnPlayerBowShot(Weapon akWeapon, Ammo akAmmo, Float afPower, Bool abSunGazing) Native
Function OnPlayerFastTravelEnd(Float afTravelGameTimeHours) Native
Event OnPlayerLoadGame()
EndEvent

Event OnRaceSwitchComplete()
EndEvent

Event OnSit(ObjectReference akFurniture)
EndEvent

Function OnVampireFeed(Actor akTarget) Native
Function OnVampirismStateChanged(Bool abIsVampire) Native
Function OpenInventory(Bool abForceOpen = false) Native
Bool Function PathToReference(ObjectReference aTarget, Float afWalkRunPercent) Native
Bool Function PlayIdle(Idle akIdle) Native
Bool Function PlayIdleWithTarget(Idle akIdle, ObjectReference akTarget) Native
Function PlaySubGraphAnimation(String asEventName) Native
Function RemoveFromAllFactions() Native
Function RemoveFromFaction(Faction akFaction) Native
Function RemovePerk(Perk akPerk) Native
Bool Function RemoveShout(Shout akShout) Native
Bool Function RemoveSpell(Spell akSpell) Native
Function ResetHealthAndLimbs() Native
Function RestoreActorValue(String asValueName, Float afAmount) Native
Function RestoreAV(String asValueName, Float afAmount) Native
Function Resurrect() Native
Function SendAssaultAlarm() Native
Function SendLycanthropyStateChanged(Bool abIsWerewolf) Native
Function SendTrespassAlarm(Actor akCriminal) Native
Function SendVampirismStateChanged(Bool abIsVampire) Native
Function SetActorValue(String asValueName, Float afValue) Native
Function SetAlert(Bool abAlerted = true) Native
Function SetAllowFlying(Bool abAllowed = true) Native
Function SetAllowFlyingEx(Bool abAllowed, Bool abAllowCrash, Bool abAllowSearch) Native
Function SetAlpha(Float afTargetAlpha, Bool abFade = false) Native
Function SetAttackActorOnSight(Bool abAttackOnSight = true) Native
Function SetAV(String asValueName, Float afValue) Native
Function SetBribed(Bool abBribe = true) Native
Function SetCrimeFaction(Faction akFaction) Native
Function SetCriticalStage(Int aiStage) Native
Function SetDoingFavor(Bool abDoingFavor = true) Native
Function SetDontMove(Bool abDontMove) Native
Function SetExpressionOverride(Int aiMood, Int aiStrength) Native
Function SetEyeTexture(TextureSet akNewTexture) Native
Function SetFactionRank(Faction akFaction, Int aiRank) Native
Function SetForcedLandingMarker(ObjectReference aMarker) Native
Function SetGhost(Bool abIsGhost = true) Native
Function SetHeadTracking(Bool abEnable = true) Native
Function SetIntimidated(Bool abIntimidate = true) Native
Function SetLookAt(ObjectReference akTarget, Bool abPathingLookAt = false) Native
Function SetNoBleedoutRecovery(Bool abAllowed) Native
Function SetNotShowOnStealthMeter(Bool abNotShow) Native
Function SetOutfit(Outfit akOutfit, Bool abSleepOutfit = false) Native
Function SetPlayerControls(Bool abControls) Native
Function SetPlayerResistingArrest() Native
Function SetPlayerTeammate(Bool abTeammate = true, Bool abCanDoFavor = true) Native
Function SetRace(Race akRace = None) Native
Function SetRelationshipRank(Actor akOther, Int aiRank) Native
Function SetRestrained(Bool abRestrained = true) Native
Function SetSubGraphFloatVariable(String asVariableName, Float afValue) Native
Function SetUnconscious(Bool abUnconscious = true) Native
Function SetVehicle(ObjectReference akVehicle) Native
Function SetVoiceRecoveryTime(Float afTime) Native
Function ShowBarterMenu() Native
Int Function ShowGiftMenu(Bool abGivingGift, FormList apFilterList, Bool abShowStolenItems, Bool abUseFavorPoints) Native
Function StartCannibal(Actor akTarget) Native
Function StartCombat(Actor akTarget) Native
Function StartDeferredKill() Native
Function StartSneaking() Native
Function StartVampireFeed(Actor akTarget) Native
Function StopCombat() Native
Function StopCombatAlarm() Native
Bool Function TrapSoul(Actor akTarget) Native
Function UnequipAll() Native
Function UnequipItem(Form akItem, Bool abPreventEquip = false, Bool abSilent = false) Native
Function UnequipItemSlot(Int aiSlot) Native
Function UnequipShout(Shout akShout) Native
Function UnequipSpell(Spell akSpell, Int aiSource) Native
Function UnLockOwnedDoorsInCell() Native
Bool Function WillIntimidateSucceed() Native
Bool Function WornHasKeyword(Keyword akKeyword) Native
