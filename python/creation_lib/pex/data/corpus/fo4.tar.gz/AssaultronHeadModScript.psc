Scriptname AssaultronHeadModScript Extends ActiveMagicEffect

actorvalue Property LeftMobilityCondition Auto
visualeffect Property pAssaultronHeadChargeV Auto
actorvalue Property RightAttackCondition Auto
actorvalue Property RightMobilityCondition Auto
sound Property LaserFireSound Auto
sound Property laserReadySound Auto
spell Property PcrThermalCoreCloak Auto
weapon Property pAssaultronLaser Auto
sound Property LaserTailSound Auto
Int Property laserState Auto
actorvalue Property LeftAttackCondition Auto
ammo Property AmmoAssaultron Auto
imagespacemodifier Property laserImod Auto
actorvalue Property headlaserAV Auto
sound Property laserChargeSound Auto

Function beginChargingLaser(actor selfRef) Native
Function endLaser(actor selfRef) Native
Function fireLaser(actor selfRef) Native
Function laserCrippled(actor selfRef) Native
Function limbCrippledReduceLaserCoolTime() Native
Event OnAnimationEvent(objectreference akSource, String asEventName)
EndEvent

Event OnCombatStateChanged(actor akTarget, Int aeCombatState)
EndEvent

Event OnCripple(actorvalue akActorValue, Bool abCrippled)
EndEvent

Event OnDying(actor akKiller)
EndEvent

Event OnEffectFinish(actor akTarget, actor akCaster)
EndEvent

Event OnEffectStart(actor akTarget, actor akCaster)
EndEvent

Event OnTimer(Int aiTimerID)
EndEvent

Function readyLaser(actor selfRef) Native
