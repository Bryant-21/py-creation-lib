Scriptname ArenaCrowdQuestScript Extends Quest

referencealias Property Spot08 Auto
referencealias Property Spectator09 Auto
referencealias Property Spot10 Auto
referencealias Property Spectator10 Auto
referencealias Property Spot06 Auto
referencealias Property Spectator07 Auto
referencealias Property Spot05 Auto
referencealias Property Spectator06 Auto
referencealias Property Spectator03 Auto
referencealias Property Spot03 Auto
referencealias Property Spectator05 Auto
referencealias Property Spot07 Auto
referencealias Property Spectator08 Auto
referencealias Property Spot01 Auto
referencealias Property Spot02 Auto
referencealias Property Spectator02 Auto
referencealias Property Spot09 Auto
referencealias Property Spectator04 Auto
referencealias Property Spot04 Auto
referencealias Property Spectator01 Auto

String Function GetState() Native
Function GotoState(String newState) Native
Function MoveEveryoneIntoPlace() Native
