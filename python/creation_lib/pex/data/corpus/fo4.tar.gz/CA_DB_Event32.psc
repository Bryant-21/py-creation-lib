Scriptname CA_DB_Event32 Extends ca_dialoguebump_basescript

Function InitializeEventID() Native
