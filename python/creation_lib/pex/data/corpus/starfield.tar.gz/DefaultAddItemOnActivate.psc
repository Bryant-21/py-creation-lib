Scriptname DefaultAddItemOnActivate Extends ObjectReference

Bool Property DisableWhenDone Auto
form Property ItemToGive Auto
Int Property NumberToGiveMax Auto
Int Property NumberToGiveMin Auto

Event OnActivate(ObjectReference akActionRef)
EndEvent
