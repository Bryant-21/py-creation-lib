Scriptname DefaultCollectionAlias Extends DefaultCollectionAliasParent

Bool Property LocationMatchIfChild Auto
locationalias[] Property LocationAliasesToCheckAgainst Auto
Bool Property PlayerOnly Auto
location[] Property LocationsToCheckAgainst Auto
faction[] Property FactionsToCheckAgainst Auto
referencealias[] Property AliasesToCheckAgainst Auto
objectreference[] Property ReferencesToCheckAgainst Auto

referencealias[] Function GetAliasesToCheckAgainst() Native
faction[] Function GetFactionsToCheckAgainst() Native
locationalias[] Function GetLocationAliasesToCheckAgainst() Native
Bool Function GetLocationMatchIfChild() Native
location[] Function GetLocationsToCheckAgainst() Native
Bool Function GetPlayerOnly() Native
objectreference[] Function GetReferencesToCheckAgainst() Native
