Scriptname BoS201QuestScript Extends Quest

Quest Property BoS000 Auto
referencealias Property BoS201Danse Auto
Quest Property BoS200 Auto
inputenablelayer Property EnableLayer Auto
keyword Property pAttachSlot1 Auto
referencealias Property BoS201Kells Auto
referencealias Property BoS201Vertibird Auto
keyword Property pAttachSlot2 Auto
Quest Property BoS201 Auto
referencealias Property BoS201VertibirdPilot Auto
Quest Property BoS101 Auto

Function DanseKeyOff() Native
Function DanseKeyOn() Native
Function FlyoverStuff() Native
Function SilenceCombat() Native
