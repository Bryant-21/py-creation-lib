Scriptname CommonTeamDeath Extends Actor

objectreference Property TeamOwner Auto

CustomEvent master

Event onDeath(Actor killer)
EndEvent
