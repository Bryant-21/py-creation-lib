Scriptname AttractionObjectActorScript Extends Actor

aoscript Property AO Auto
attractionobjectscript Property AttractionObject Auto
Int Property PingDelay Auto
Float Property PingRadius Auto

Function CheckForAttractionObjectAndSendStimEvent() Native
Bool Function CheckKeywords() Native
Bool Function CheckLOS() Native
attractionobjectscript Function FindAttractionObject() Native
Event OnInit()
EndEvent

Event OnLoad()
EndEvent

Event OnTimer(Int aiTimerID)
EndEvent
