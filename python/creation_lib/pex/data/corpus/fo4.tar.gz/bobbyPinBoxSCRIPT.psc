Scriptname bobbyPinBoxSCRIPT Extends ObjectReference

leveleditem Property LL_BobbyPinBox Auto

Event OnActivate(ObjectReference akActionRef)
EndEvent

Event OnLoad()
EndEvent
