Scriptname CreationClub:VRWorkshops:VRWorkshopSirenScript Extends ObjectReference

quest Property VRWorkshopShared_SummonedByAlarmQuest Auto
referencealias Property Alias_SirenREF Auto

Event onClose(ObjectReference akActionRef)
EndEvent

Event onOpen(ObjectReference akActionRef)
EndEvent

Event OnTimer(Int aiTimerID)
EndEvent
