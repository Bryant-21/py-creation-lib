Scriptname AudioContainerNoAnimScript Extends ObjectReference

sound Property OpenSound Auto Const
sound Property CloseSound Auto Const

Event OnLoad()
EndEvent

Event OnMenuOpenCloseEvent(String asMenuName, Bool abOpening)
EndEvent

Event OnUnload()
EndEvent
