Scriptname BoSR03PlayerScript Extends ReferenceAlias

alias Property BoSR03Squire Auto Const
quest Property BoSR03 Auto Const
location Property PrydwenLocation Auto Const

Event OnLocationChange(location akOldLoc, location akNewLoc)
EndEvent
