Scriptname DefaultCollAliasSendEventOnActivate Extends RefCollectionAlias

keyword Property KeywordToSend Auto
Bool Property ShowTraces Auto
keyword Property BlockingKeyword Auto

Function OnActivate(objectreference akActionRef, objectreference akActivatorRef) Native
