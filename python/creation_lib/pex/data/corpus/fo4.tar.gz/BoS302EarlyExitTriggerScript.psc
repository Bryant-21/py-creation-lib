Scriptname BoS302EarlyExitTriggerScript Extends ObjectReference

quest Property BoS302 Auto

Event OnTriggerEnter(ObjectReference akActionRef)
EndEvent
