Scriptname CZScript Extends Quest

idle Property IdleFightWinner Auto
referencealias Property ArenaAnnounceMarker Auto
Bool Property bPlayerInCage Auto
referencealias Property ArenaPlayerEntranceTrigger Auto
referencealias Property StageController Auto
actorvalue Property Aggression Auto
referencealias Property ArenaCorner2Marker Auto
referencealias Property CageDoor Auto
referencealias Property ArenaSpawnMarker Auto
refcollectionalias Property Attackers Auto
referencealias Property AnnouncerHeadtrackMarker3 Auto
referencealias Property AnnouncerHeadtrackMarker2 Auto
referencealias Property Tommy Auto
referencealias Property AnnouncerHeadtrackMarker1 Auto
arenascript Property Arena Auto
referencealias Property ArenaCorner1Marker Auto

Function PlayTriumphantIdle(referencealias AliasToTryToPlay) Native
Function SetCageLockState(Bool Lock = false) Native
Function SetRaiderAggression(Int iAggressionNum) Native
Function SetupMatch(actor Combatant1Ref = none, actor Combatant2Ref = none, Int Rank = 0) Native
Function SpotlightPlayer(Bool turnOnLight) Native
Function TurnOffCaitIntroSpotlight() Native
