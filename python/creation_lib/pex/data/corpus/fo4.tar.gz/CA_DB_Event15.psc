Scriptname CA_DB_Event15 Extends ca_dialoguebump_basescript

Function InitializeEventID() Native
