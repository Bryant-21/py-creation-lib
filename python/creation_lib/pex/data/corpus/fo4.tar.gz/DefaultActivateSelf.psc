Scriptname DefaultActivateSelf Extends ObjectReference

objectreference[] Property TriggeredByReferences Auto Const
Bool Property PlayerOnly Auto Const
faction[] Property TriggeredByFactions Auto Const
Int Property PlayerMinLevel Auto Const
referencealias[] Property TriggeredByAliases Auto Const

Event onTriggerEnter(ObjectReference triggerRef)
EndEvent
