Scriptname ActorBase Extends Form

Function DeriveGeneticParentAppearance(ActorBase akChildSourceToDeriveFrom) Native
class Function GetClass() Native
Int Function GetDeadCount() Native
formlist Function GetGiftFilter() Native
Int Function GetLevel() Native
Int Function GetLevelExact() Native
Int Function GetPronoun() Native
race Function GetRace() Native
Int Function GetSex() Native
actor Function GetUniqueActor() Native
Bool Function IsEssential() Native
Bool Function IsProtected() Native
Bool Function IsUnique() Native
Function SetEssential(Bool abEssential = true) Native
Function SetOutfit(outfit akOutfit, Bool abSleepOutfit = false) Native
Function SetProtected(Bool abProtected = true) Native
