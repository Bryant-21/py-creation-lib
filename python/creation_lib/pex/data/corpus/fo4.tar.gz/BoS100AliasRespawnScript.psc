Scriptname BoS100AliasRespawnScript Extends ReferenceAlias

Bool Property bRespawningOn Auto

Event OnDeath(actor akKiller)
EndEvent

Function RespawnIfDead() Native
