Scriptname abProtectronRaceScript Extends ActiveMagicEffect

scene Property ProtectronVIPescortScene Auto
referencealias Property protectronAlias Auto
actorvalue Property ProtectronPodStatus Auto
Bool Property startInPod Auto
scene Property ProtectronPowerUpReceived Auto
scene Property ProtectronShutDownCompleted Auto
scene Property ProtectronShutDownReceived Auto
keyword Property linkProtectronPod Auto

Event OnActivate(objectreference akActionRef)
EndEvent

Event OnDistanceLessThan(objectreference akObj1, objectreference akObj2, Float afDistance)
EndEvent

Event OnEffectStart(actor akTarget, actor akCaster)
EndEvent

Event OnTimer(Int aiTimerID)
EndEvent

Bool Function shutDownAllScenes() Native
