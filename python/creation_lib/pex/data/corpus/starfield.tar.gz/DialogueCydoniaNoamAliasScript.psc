Scriptname DialogueCydoniaNoamAliasScript Extends ReferenceAlias

actorvalue Property Health Auto

Function OnAliasInit() Native
