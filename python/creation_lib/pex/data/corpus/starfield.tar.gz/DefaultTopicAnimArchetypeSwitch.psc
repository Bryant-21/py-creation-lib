Scriptname DefaultTopicAnimArchetypeSwitch Extends TopicInfo

keyword Property OnBeginArchetype Auto
keyword Property OnEndArchetype Auto

Event OnBegin(objectreference akSpeakerRef, Bool abHasBeenSaid)
EndEvent

Event OnEnd(objectreference akSpeakerRef, Bool abHasBeenSaid)
EndEvent
