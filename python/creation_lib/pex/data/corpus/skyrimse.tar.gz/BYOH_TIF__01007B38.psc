Scriptname BYOH_TIF__01007B38 Extends TopicInfo

referencealias Property Child Auto
quest Property RelationshipAdoption Auto

Function Fragment_0(ObjectReference akSpeakerRef) Native
String Function GetState() Native
Function GotoState(String newState) Native
