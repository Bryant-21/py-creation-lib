Scriptname BYOH_TIF__01002DA2 Extends TopicInfo

spell Property FavorJobsBeggarsAbility Auto
quest Property RelationshipAdoption Auto
message Property FavorJobsBeggarMessage Auto
miscobject Property Gold001 Auto

Function Fragment_0(ObjectReference akSpeakerRef) Native
String Function GetState() Native
Function GotoState(String newState) Native
