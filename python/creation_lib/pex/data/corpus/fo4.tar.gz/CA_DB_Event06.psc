Scriptname CA_DB_Event06 Extends ca_dialoguebump_basescript

Function InitializeEventID() Native
