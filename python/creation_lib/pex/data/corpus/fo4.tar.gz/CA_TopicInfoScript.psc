Scriptname CA_TopicInfoScript Extends TopicInfo

objectreference Property EventTarget Auto Const
globalvariable Property Size Auto Const
keyword Property EventKeyword Auto Const
Bool Property CheckCompanionProximity Auto Const
Bool Property OnEnd Auto Const
Bool Property OnBegin Auto Const

Event OnBegin(objectreference akSpeakerRef, Bool abHasBeenSaid)
EndEvent

Event OnEnd(objectreference akSpeakerRef, Bool abHasBeenSaid)
EndEvent

Function sendEvent(Bool shouldSendEvent) Native
