Scriptname BYOH_TIF__0100BE03 Extends TopicInfo

Function Fragment_1(ObjectReference akSpeakerRef) Native
String Function GetState() Native
Function GotoState(String newState) Native
