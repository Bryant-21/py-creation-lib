Scriptname DefaultAliasDeadDropActivate Extends DefaultAlias

Bool Property BlockWhilePlayerIsInCombat Auto Const
objectreference[] Property ActivatedByReferences Auto Const
Bool Property PlayerActivateOnly Auto Const
message Property DeadDropMessage Auto Const
referencealias[] Property ActivatedByAliases Auto Const
faction[] Property ActivatedByFactions Auto Const

Event OnActivate(objectreference akActionRef)
EndEvent
