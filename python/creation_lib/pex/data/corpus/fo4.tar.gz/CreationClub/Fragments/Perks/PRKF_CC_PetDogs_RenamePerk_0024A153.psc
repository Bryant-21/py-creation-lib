Scriptname CreationClub:Fragments:Perks:PRKF_CC_PetDogs_RenamePerk_0024A153 Extends Perk

creationclub:cc_petdogquestscript Property CC_PetDogQuest Auto Const

Function Fragment_Entry_00(objectreference akTargetRef, actor akActor) Native
