Scriptname BoSMarshalQuestScript Extends Quest

referencealias[] Property BoSMarshalAliases Auto

Function BeginRevertingActors() Native
Event OnTimer(Int timerID)
EndEvent

Function RevertActor(actor a) Native
Function RevertActors() Native
