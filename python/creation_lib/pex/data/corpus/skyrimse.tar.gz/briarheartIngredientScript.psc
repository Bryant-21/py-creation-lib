Scriptname briarheartIngredientScript Extends ObjectReference

spell Property dunReanimateSelf Auto
armor Property ArmorBriarHeartEmpty Auto
armor Property ArmorBriarHeart Auto

String Function GetState() Native
Function GotoState(String newState) Native
Function OnContainerChanged(ObjectReference akNewContainer, ObjectReference akOldContainer) Native
