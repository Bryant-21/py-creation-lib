Scriptname COM_CoraHandlerQuestScript Extends Quest

referencealias Property Cora Auto
referencealias Property SamCoe Auto
conditionform Property COM_CND_Cora_AtLodge Auto
actorvalue Property FollowerState Auto
conditionform Property COM_Cora_HandlerTeleportingAllowed Auto
locationalias Property PlayerShipLocation Auto
locationalias Property LodgeLocation Auto
referencealias Property PlayerShipCrewMarker Auto
referencealias Property LodgeSandboxMarker Auto
conditionform Property COM_CND_Cora_OnPlayerShip Auto

Function OnActorValueChanged(objectreference akObjRef, actorvalue akActorValue) Native
Function OnQuestInit() Native
Function TestLodgeCondition() Native
Bool Function Trace(ScriptObject CallingObject, String asTextToPrint, Int aiSeverity, String MainLogName, String SubLogName, Bool bShowNormalTrace, Bool bShowWarning, Bool bPrefixTraceWithLogNames) Native
Bool Function warning(ScriptObject CallingObject, String asTextToPrint, Int aiSeverity, String MainLogName, String SubLogName, Bool bShowNormalTrace, Bool bShowWarning, Bool bPrefixTraceWithLogNames) Native
