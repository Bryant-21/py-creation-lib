Scriptname DefaultCollectionAliasAddPerkOnLoad Extends RefCollectionAlias

perk Property PerkToAdd Auto

Event OnLoad(objectreference akSenderRef)
EndEvent
