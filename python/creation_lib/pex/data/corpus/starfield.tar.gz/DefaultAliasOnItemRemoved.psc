Scriptname DefaultAliasOnItemRemoved Extends DefaultAlias

form Property ItemFilter Auto

Function OnAliasInit() Native
Function OnItemRemoved(form akBaseItem, Int aiItemCount, objectreference akItemReference, objectreference akDestContainer, Int aiTransferReason) Native
