Scriptname AnnihilatorModEffect Extends ActiveMagicEffect

spell Property AnnihilatorSpawnHazardSelf Auto

Function OnDeath(objectreference akKiller) Native
