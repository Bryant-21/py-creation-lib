Scriptname DefaultAliasMapMarkerScript Extends ReferenceAlias

Bool Property EnableOnInit Auto
Bool Property AllowGravJump Auto
message Property UnexploredName Auto
Int Property MapMarkerCategory Auto
Int Property MapMarkerType Auto
Int Property UndiscoveredVisibility Auto
Bool Property Discovered Auto
Bool Property VisibleOnStarMap Auto

Function OnAliasChanged(objectreference akObject, Bool abRemove) Native
Function OnAliasInit() Native
Function UpdateMapMarkerFlags() Native
