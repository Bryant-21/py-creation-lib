Scriptname DefaultFollowerToggleQuestScript Extends Quest

Bool Property StopFollowConditions_RequiredOutput Auto
locationalias[] Property Triggering_LocationAliases Auto
Bool Property ShowTraces Auto
Bool Property SetUnavailableWhenStopFollow Auto
Float Property TeleportDistance Auto
Bool Property TeleportToPlayerOnStartFollow Auto
Bool Property Trigger_AnyLocation Auto
Int[] Property Triggering_Stages Auto
referencealias[] Property Triggering_EnterLeaveRefAliases Auto
referencealias[] Property Triggering_ActivationRefAliases Auto
referencealias Property PotentialFollower Auto
conditionform Property FollowConditions Auto
Bool Property FollowConditions_RequiredOutput Auto
sq_followersscript Property SQ_Followers Auto
conditionform Property StopFollowConditions Auto
Bool Property Triggering_OnQuestInit Auto

Function CheckConditions(objectreference TargetRef) Native
Function CheckConditionsIfPlayer(referencealias akSender, objectreference akActionRef) Native
Function OnQuestStarted() Native
Function OnStageSet(Int auiStageID, Int auiItemID) Native
