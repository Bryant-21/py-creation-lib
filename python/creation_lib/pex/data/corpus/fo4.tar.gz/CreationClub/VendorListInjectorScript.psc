Scriptname CreationClub:VendorListInjectorScript Extends Quest

leveleditem Property LLC_WorkshopVendorArmor02 Auto
leveleditem Property LL_Vendor_Weapon_GunBoS Auto
leveleditem Property LLC_WorkshopVendorArmor03 Auto
leveleditem Property VL_Vendor_General_Drumlin Auto
leveleditem Property LL_Vendor_Weapon_GunSpecialty Auto
leveleditem Property VL_Vendor_Clothing Auto
leveleditem Property VL_Vendor_General Auto
leveleditem Property LLC_DCShopArmor Auto
leveleditem Property VL_Vendor_Armor Auto
leveleditem Property LLC_WorkshopVendorArmor01 Auto
leveleditem Property VL_Vendor_Weapon Auto
leveleditem Property LLI_Armor_BoSCombatArmor_Vendor_Outfit Auto

Function AddToVendorArmorLists(leveleditem itemToAdd, Int Level = 1, Int Quantity = 1, Bool AddToBoS = True) Native
Function AddToVendorWeaponLists(leveleditem itemToAdd, Int Level = 1, Int Quantity = 1, Bool AddToBoS = True) Native
