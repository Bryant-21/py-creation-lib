Scriptname City_Neon_Drug03_Script Extends Quest

Quest Property City_Neon_Drug_Game Auto
Int Property maxRefills Auto

Function ReplayGame() Native
