Scriptname DefaultMoveToEditorLocationOnLoad Extends ObjectReference

Event OnLoad()
EndEvent
