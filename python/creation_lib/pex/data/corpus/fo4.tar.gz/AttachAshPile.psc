Scriptname AttachAshPile Extends ActiveMagicEffect

Bool Property onEffectStartOveride Auto Const
Bool Property bSetAlphaZero Auto Const
activator Property AshPileObject Auto Const
Float Property ShaderDuration Auto Const
Float Property fDelayEnd Auto Const
Bool Property bSetAlphaToZeroEarly Auto Const
effectshader Property MagicEffectShader Auto Const
Float Property fDelay Auto Const

Event OnDying(actor Killer)
EndEvent

Event OnEffectStart(actor Target, actor Caster)
EndEvent

Event OnInit()
EndEvent

Event OnTimer(Int aiTimerID)
EndEvent
