Scriptname DefaultActor Extends Actor

Bool Property ShowTraces Auto
Int Property StageToSet Auto
Int Property TurnOffStage Auto
quest Property MyQuest Auto
Int Property PrereqStage Auto

Function TryToSetStage(Bool PlayerCheckOverride = FALSE, objectreference RefToCheck = NONE, form FormToCheck = NONE, objectreference[] ReferenceArray = NONE, referencealias[] AliasArray = NONE, faction[] FactionArray = NONE, form[] FormArray = NONE, location[] LocationArray = NONE, locationalias[] LocationAliasArray = NONE) Native
