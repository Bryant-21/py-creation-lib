Scriptname Action Extends Form

String Function GetState() Native
Function GotoState(String newState) Native
