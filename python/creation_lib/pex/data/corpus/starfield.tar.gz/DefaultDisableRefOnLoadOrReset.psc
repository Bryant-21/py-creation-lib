Scriptname DefaultDisableRefOnLoadOrReset Extends ObjectReference

Bool Property DisableOnLoad Auto
Bool Property ShouldFadeOut Auto
Bool Property DisableOnReset Auto

Event OnLoad()
EndEvent

Event OnReset()
EndEvent
