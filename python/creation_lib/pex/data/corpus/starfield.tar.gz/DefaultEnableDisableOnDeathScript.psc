Scriptname DefaultEnableDisableOnDeathScript Extends DefaultActorParent

Bool Property UseOnDyingInstead Auto
location[] Property LocationsToCheckAgainst Auto
Bool Property PlayerOnly Auto
Bool Property LocationMatchIfChild Auto
locationalias[] Property LocationAliasesToCheckAgainst Auto
keyword Property LinkedRefKeyword Auto
Bool Property EnableLinkedRef Auto
objectreference[] Property ReferencesToCheckAgainst Auto
referencealias[] Property AliasesToCheckAgainst Auto
faction[] Property FactionsToCheckAgainst Auto

Function DeathComplete(objectreference akKiller) Native
Function DoSpecificThing(defaultscriptfunctions:parentscriptfunctionparams ParentScriptFunctionParams, objectreference RefToDoThingWith, Bool LastRefToDoThingWith) Native
referencealias[] Function GetAliasesToCheckAgainst() Native
faction[] Function GetFactionsToCheckAgainst() Native
locationalias[] Function GetLocationAliasesToCheckAgainst() Native
Bool Function GetLocationMatchIfChild() Native
location[] Function GetLocationsToCheckAgainst() Native
Bool Function GetPlayerOnly() Native
objectreference[] Function GetReferencesToCheckAgainst() Native
Event OnDeath(objectreference akKiller)
EndEvent

Function OnDying(objectreference akKiller) Native
