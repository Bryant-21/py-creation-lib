Scriptname ArenaTIScript Extends TopicInfo

Bool Property PlaceWager Auto
Int Property Combatant Auto
Bool Property CollectPrize Auto
Bool Property CollectEarnings Auto

Function CollectEarnings() Native
Event OnEnd(objectreference akSpeakerRef, Bool abHasBeenSaid)
EndEvent

Function PlaceWager() Native
