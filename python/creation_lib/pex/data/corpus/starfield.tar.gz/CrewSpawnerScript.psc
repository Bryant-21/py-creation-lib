Scriptname CrewSpawnerScript Extends ObjectReference

Int Property MaxNumberToSpawn Auto
keyword Property LinkGenericCrewSpawnMarker Auto
faction Property CrewCrimeFaction Auto
Int Property RespawnIntervalLocalDays Auto

Function AddToSpawnedCrewArray(actor crewMember) Native
Function ClearSpawnedCrewArray() Native
Bool Function GetCanSpawnCrew() Native
Function OnBeginState(String asOldState) Native
Function OnTimerGameTime(Int aiTimerID) Native
Function OnUnload() Native
Function PrepareForRespawn() Native
Function RemoveFromSpawnedCrewArray(actor crewMember) Native
Function StartRespawnTimer() Native
