Scriptname DefaultAliasOnTriggerLeave Extends DefaultAlias

referencealias[] Property TriggeredByAliases Auto Const
faction[] Property TriggeredByFactions Auto Const
Bool Property PlayerTriggerOnly Auto Const
objectreference[] Property TriggeredByReferences Auto Const

Event OnTriggerLeave(objectreference akActionRef)
EndEvent
