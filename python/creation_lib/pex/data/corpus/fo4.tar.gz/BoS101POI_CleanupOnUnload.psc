Scriptname BoS101POI_CleanupOnUnload Extends RefCollectionAlias

quest Property BoS101POI Auto

Event OnUnload(objectreference source)
EndEvent
