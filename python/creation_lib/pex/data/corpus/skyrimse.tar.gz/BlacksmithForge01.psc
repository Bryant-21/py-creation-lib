Scriptname BlacksmithForge01 Extends ObjectReference

spell Property FlameDamage Auto

String Function GetState() Native
Function GotoState(String newState) Native
Function onActivate(ObjectReference triggerRef) Native
Function OnTriggerEnter(ObjectReference triggerRef) Native
