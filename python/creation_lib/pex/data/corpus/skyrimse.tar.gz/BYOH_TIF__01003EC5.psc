Scriptname BYOH_TIF__01003EC5 Extends TopicInfo

referencealias Property PaleHouse Auto

Function Fragment_0(ObjectReference akSpeakerRef) Native
String Function GetState() Native
Function GotoState(String newState) Native
