Scriptname BanneredMareSceneTriggerScript Extends ObjectReference

scene Property pMikaelScene Auto

String Function GetState() Native
Function GotoState(String newState) Native
Function OnTriggerEnter(ObjectReference AkActivator) Native
