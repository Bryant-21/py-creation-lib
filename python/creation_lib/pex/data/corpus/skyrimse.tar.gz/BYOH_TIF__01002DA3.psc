Scriptname BYOH_TIF__01002DA3 Extends TopicInfo

quest Property RelationshipAdoption Auto

Function Fragment_0(ObjectReference akSpeakerRef) Native
String Function GetState() Native
Function GotoState(String newState) Native
