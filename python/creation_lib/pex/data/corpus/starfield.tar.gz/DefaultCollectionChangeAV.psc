Scriptname DefaultCollectionChangeAV Extends RefCollectionAlias

Struct ActorValueDatum
    Int TypeOfChange
    Float NewValue
    actorvalue ActorValueToChange
EndStruct

actorvaluedatum[] Property ActorValueData Auto

Function OnAliasChanged(objectreference akObject, Bool abRemove) Native
