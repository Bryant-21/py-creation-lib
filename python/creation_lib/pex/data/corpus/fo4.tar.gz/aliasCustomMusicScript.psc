Scriptname aliasCustomMusicScript Extends ReferenceAlias

musictype Property mySpecialMusic Auto
Bool Property bStartedMyMusic Auto

Event OnCombatStateChanged(actor akTarget, Int aeCombatState)
EndEvent

Event OnDeath(actor akKiller)
EndEvent

Event OnUnload()
EndEvent
