Scriptname BoSM02DanseOverrides_PlayerAliasScript Extends ReferenceAlias

location Property BostonAirportRuinsLocation Auto Const
quest Property BoSM02DanseOverrides Auto Const

Event OnLocationChange(location akOldLoc, location akNewLoc)
EndEvent
