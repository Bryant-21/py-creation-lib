Scriptname AttractionObjectScript Extends ObjectReference

Bool Property Busy Auto
Int Property DidMyThing Auto
Bool Property ShouldNonPlayerActorActivationDoMyThing Auto
Bool Property ShouldBlockActivationOnLoad Auto
Bool Property FaceMarker Auto
Bool Property ShouldNonActorActivationDoMyThing Auto
Bool Property ShouldPlayerActivationClearBusy Auto
Bool Property UnlockMe Auto
Bool Property DeleteAfterCleared Auto
Bool Property ShouldFadeOutOnDisable Auto
Bool Property ActivateMe Auto
String Property StringEventSend Auto
Bool Property ShouldFadeInOnEnable Auto
String Property StringEventRecieve Auto
Bool Property LockMe Auto
keyword Property CustomTopicKeyword Auto
keyword Property LinkLock Auto
Bool Property DisableMe Auto
keyword Property LinkSendRecieveEvent Auto
Bool Property EnableMeOnLoad Auto
Bool Property EnableMe Auto
keyword Property LinkEnable Auto
keyword Property LinkDisable Auto
Bool Property ShouldPlayerActivationDoMyThing Auto
Bool Property ShouldWaitToRecieveEvent Auto
keyword Property LinkUnlock Auto
Bool Property DeleteMe Auto
Bool Property FinishWalking Auto
Bool Property SayImmediately Auto
Bool Property ShouldOnlyDoMyThingOnce Auto
Bool Property ISendRecieveEvent Auto
keyword Property LinkActivate Auto

Int Function DoMyThing(actor myActor = None) Native
Event OnActivate(ObjectReference akActionRef)
EndEvent

Event OnLoad()
EndEvent

Function RegisterForDeletionEvent(defaultremoveablelight myOwner) Native
Int Function SayMyThing(actor myActor = None) Native
Function SetBusy(Bool IsBusy = true) Native
