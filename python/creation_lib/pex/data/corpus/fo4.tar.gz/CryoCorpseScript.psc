Scriptname CryoCorpseScript Extends Actor

effectshader Property CryoCorpseFXS Auto

Event OnLoad()
EndEvent
