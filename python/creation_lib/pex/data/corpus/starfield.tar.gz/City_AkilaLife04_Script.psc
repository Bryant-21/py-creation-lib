Scriptname City_AkilaLife04_Script Extends Quest

Int Property StageToSet Auto
referencealias Property KateFoley Auto

Function OnTimerGameTime(Int aiTimerID) Native
Function Wait24() Native
