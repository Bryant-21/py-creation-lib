Scriptname BoS302TagScript Extends ReferenceAlias

quest Property BOS302 Auto

Event OnContainerChanged(objectreference akNewContainer, objectreference akOldContainer)
EndEvent
