Scriptname BYOH_TIF__01003D8D Extends TopicInfo

message Property FavorJobsBeggarMessage Auto
quest Property RelationshipAdoption Auto
spell Property FavorJobsBeggarsAbility Auto
miscobject Property Gold001 Auto

Function Fragment_0(ObjectReference akSpeakerRef) Native
String Function GetState() Native
Function GotoState(String newState) Native
