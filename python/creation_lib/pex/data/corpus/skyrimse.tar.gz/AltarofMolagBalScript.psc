Scriptname AltarofMolagBalScript Extends ReferenceAlias

ReferenceAlias Property TalkingMace Auto
quest Property DA10 Auto
ReferenceAlias Property MaceofMolagBal Auto
ReferenceAlias Property RustyMaceIntRef Auto
Int Property DisableOnce Auto
ReferenceAlias Property TalkingMaceTriggerREF Auto

String Function GetState() Native
Function GotoState(String newState) Native
Function OnActivate(ObjectReference akActionRef) Native
Function OnAnimationEvent(ObjectReference akSource, String asEventName) Native
