Scriptname CRWCrewScript Extends Quest

sq_crewscript Property SQ_Crew Auto
referencealias Property CrewmanAlias Auto

Function HireCrew(Float fhiredcost) Native
