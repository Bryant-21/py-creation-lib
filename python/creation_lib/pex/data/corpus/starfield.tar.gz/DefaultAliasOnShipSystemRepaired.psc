Scriptname DefaultAliasOnShipSystemRepaired Extends ReferenceAlias

Struct SystemRepairStage
    Int StageToSet
    Int TurnOffStage
    Int PrereqStage
    Bool SetStageOnlyFromNormalDamage
    actorvalue TargetSystem
EndStruct

systemrepairstage[] Property SystemRepairStages Auto
Bool Property ShowTraces Auto
Int Property TurnOffStageDone Auto
Int Property TurnOffStage Auto
Int Property PrereqStage Auto

Function OnShipSystemRepaired(actorvalue akSystem, Int aBlocksGained, Bool aElectromagneticDamage) Native
