Scriptname COM_CoraBookGuard Extends Quest

referencealias Property Cora Auto
scene Property CREW_EliteCrew_CoraCoe_GiveBooks Auto
Int Property XPperbook Auto
globalvariable Property CoraBookGlobal Auto
formlist Property BookFormList Auto
keyword Property BookKeyword Auto

Function CalculateReward() Native
Function CheckCountAndOpenMenu() Native
