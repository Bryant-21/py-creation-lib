Scriptname ccFSVFO4007:KeypadScript Extends ObjectReference

Struct SafeDigit
    message Question
    Int Answer
EndStruct

ObjectReference Property myDoor Auto
Int Property StageToDisplay Auto
message Property LockedMessage Auto
quest Property myQuest Auto
Int Property StageToCheck Auto
safedigit[] Property Digits Auto
message Property WrongCode Auto
Int Property StageToSet Auto

Function onActivate(ObjectReference akActionRef) Native
