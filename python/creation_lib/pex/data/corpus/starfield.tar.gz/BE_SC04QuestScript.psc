Scriptname BE_SC04QuestScript Extends Quest

static Property XMarker Auto
referencealias Property TargetShipJumpTravelMarker Auto
referencealias Property TargetShip Auto
referencealias Property Captain Auto
referencealias Property CaptainEssentialAlias Auto

Function OnQuestStarted() Native
Function SpawnJumpTravelMarker() Native
