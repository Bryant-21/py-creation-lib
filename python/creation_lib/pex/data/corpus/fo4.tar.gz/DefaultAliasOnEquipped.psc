Scriptname DefaultAliasOnEquipped Extends DefaultAlias

Bool Property PlayerEquippedOnly Auto
objectreference[] Property EquippedByReferences Auto
referencealias[] Property EquippedByAliases Auto
faction[] Property EquippedByFactions Auto

Event OnEquipped(actor akActor)
EndEvent
