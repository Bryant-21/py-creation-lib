Scriptname CityLife_LVC_AliasScript Extends ReferenceAlias

Int Property SceneCompleteStage Auto
Bool Property DisablePostScene Auto
Float Property MaxEVPWait Auto
Float Property MinEVPWait Auto
actorvalue Property UC_NA_CL_SceneComplete Auto

Function OnAliasInit() Native
Function OnUnload() Native
Bool Function Trace(ScriptObject CallingObject, String asTextToPrint, Int aiSeverity, String MainLogName, String SubLogName, Bool bShowNormalTrace, Bool bShowWarning, Bool bPrefixTraceWithLogNames) Native
Function UpdateCLNPC() Native
