Scriptname ArenaWagerDoorExteriorScript Extends ReferenceAlias

objectreference Property InsideMarker Auto
message Property ArenaWagerDoorMessage Auto

String Function GetState() Native
Function GotoState(String newState) Native
Function OnActivate(objectreference akActivator) Native
Function Setup() Native
