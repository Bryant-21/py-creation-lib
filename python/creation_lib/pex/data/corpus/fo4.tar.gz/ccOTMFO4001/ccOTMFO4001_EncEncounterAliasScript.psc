Scriptname ccOTMFO4001:ccOTMFO4001_EncEncounterAliasScript Extends ReferenceAlias

Function OnCombatStateChanged(actor akTarget, Int aeCombatState) Native
Function OnLoad() Native
Function OnUnload() Native
