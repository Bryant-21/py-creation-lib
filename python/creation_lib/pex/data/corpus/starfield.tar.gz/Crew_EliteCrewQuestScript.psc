Scriptname Crew_EliteCrewQuestScript Extends Crew_RecruitQuestScript

Function DismissSceneEnded() Native
Function FollowSceneEnded() Native
Function GiveItemSceneEnded() Native
Function OnQuestInit() Native
Function PickupSceneEnded() Native
Function StartBackstoryTimer() Native
Function WaitSceneEnded() Native
