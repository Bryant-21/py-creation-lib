Scriptname COM_Quest_Andreja_Q01_TomisarScript Extends ReferenceAlias

ReferenceAlias Property Alias_Andreja Auto
quest Property COM_Quest_Andreja_Q01 Auto

Function OnDeath(objectreference AkKiller) Native
Function OnHit(objectreference akTarget, objectreference akAggressor, form akSource, projectile akProjectile, Bool abPowerAttack, Bool abSneakAttack, Bool abBashAttack, Bool abHitBlocked, String apMaterial) Native
Function OnLoad() Native
