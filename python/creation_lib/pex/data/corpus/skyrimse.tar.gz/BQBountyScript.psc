Scriptname BQBountyScript Extends ReferenceAlias

String Function GetState() Native
Function GotoState(String newState) Native
Function OnDeath(Actor akKiller) Native
