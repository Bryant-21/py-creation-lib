Scriptname damageAVonLoad Extends ObjectReference

actorvalue Property LeftMobilityCondition Auto
actorvalue Property RightMobilityCondition Auto

Event OnLoad()
EndEvent
