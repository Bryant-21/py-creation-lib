Scriptname DBPOI01PipeScript Extends ObjectReference

keyword Property LinkCustom01 Auto Const
message Property DBPOI01PipeMessage Auto Const

Event OnActivate(ObjectReference akActionRef)
EndEvent

Event OnLoad()
EndEvent
