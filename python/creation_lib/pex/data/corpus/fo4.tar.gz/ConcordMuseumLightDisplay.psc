Scriptname ConcordMuseumLightDisplay Extends ObjectReference

form Property XMarker Auto
sound Property FXBulletImpactGlass Auto
Float Property MaxTimeBetweenLights Auto
sound Property OBJRadioKnobOn Auto
Float Property MinTimeBetweenLights Auto
form Property ConcordMuseumSparksActivator Auto

Event OnTriggerEnter(ObjectReference akActionRef)
EndEvent

Function TurnOnLights() Native
