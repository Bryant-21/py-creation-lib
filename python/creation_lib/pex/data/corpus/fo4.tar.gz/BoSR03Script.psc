Scriptname BoSR03Script Extends Quest

Int Property StageToSet Auto Const
alias Property BoSR03Squire Auto Const
location Property PrydwenLocation Auto Const
locationalias Property Dungeon Auto Const
