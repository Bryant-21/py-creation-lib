Scriptname DefaultRefOnOpen Extends DefaultRef

Event OnOpen(objectreference akActionRef)
EndEvent
