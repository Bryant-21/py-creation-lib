Scriptname BECityCYRedTape02QuestScript Extends Quest

referencealias Property EnemyShip Auto
topic Property BE_City_CY_RedTape02_Ship_JumpTopic Auto
actorvalue Property ShipSystemEngineHealth Auto
Float Property UndockTimerLength Auto
Float Property CountdownTimerLength Auto
Int Property TimesUpStage Auto
Int Property GaveFuelStage Auto
Int Property SabotagedFuelStage Auto
potion Property ShipRepairKit Auto
referencealias Property PlayerShip Auto

Function OnTimer(Int aiTimerID) Native
Function RemoveShipParts() Native
Function ShipGoodbye() Native
Function ShipUndock() Native
Function StartCountdown() Native
Function StopCountdown() Native
