Scriptname BYOH_TIF__01002DA0 Extends TopicInfo

quest Property RelationshipAdoption Auto
spell Property FavorJobsBeggarsAbility Auto
message Property FavorJobsBeggarMessage Auto
miscobject Property Gold001 Auto

Function Fragment_0(ObjectReference akSpeakerRef) Native
String Function GetState() Native
Function GotoState(String newState) Native
