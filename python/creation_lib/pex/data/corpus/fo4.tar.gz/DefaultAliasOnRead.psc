Scriptname DefaultAliasOnRead Extends DefaultAlias

Event OnRead()
EndEvent
