Scriptname CA_PickLockScript Extends Quest

Event OnStoryPickLock(objectreference akActor, objectreference akLock)
EndEvent
