Scriptname abForswornBriarheartScript Extends ActiveMagicEffect

ingredient Property BriarHeart Auto
armor Property ArmorBriarHeart Auto
armor Property ArmorBriarHeartEmpty Auto
actor Property mySelf Auto

String Function GetState() Native
Function GotoState(String newState) Native
Function OnEffectStart(actor Target, actor Caster) Native
Function OnItemRemoved(form objectTaken, Int aiItemCount, ObjectReference refTaken, ObjectReference akDestContainer) Native
