Scriptname CA_DB_Event16 Extends ca_dialoguebump_basescript

Function InitializeEventID() Native
