Scriptname CreationClub:BGSFO4018:B018_QuestScript Extends Quest

leveleditem Property LL_Quest_Reward_Weapon_Any Auto Const
leveleditem Property LLC_DCShopWeapons Auto Const
leveleditem Property LLI_RRAgent_Weapons Auto Const
leveleditem Property ccBGSFO4018_LL_GaussRifle Auto Const
leveleditem Property LL_DN123_SkylanesGuns_Any Auto Const
leveleditem Property LLC_Vendor_Weapon_Heavy Auto Const

Function OnInit() Native
