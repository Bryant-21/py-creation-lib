Scriptname BoSM02CleanupQuestActorsOnUnload Extends Actor

quest Property BoSM02 Auto Const

Event OnUnload()
EndEvent
