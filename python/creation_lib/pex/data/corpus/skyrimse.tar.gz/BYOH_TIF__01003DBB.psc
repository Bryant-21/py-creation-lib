Scriptname BYOH_TIF__01003DBB Extends TopicInfo

Int Property GoldAmount Auto
objectreference Property DecorateMarker Auto
miscobject Property Gold Auto
globalvariable Property HDMarkarthAlchemy Auto

Function Fragment_0(objectreference akSpeakerRef) Native
String Function GetState() Native
Function GotoState(String newState) Native
