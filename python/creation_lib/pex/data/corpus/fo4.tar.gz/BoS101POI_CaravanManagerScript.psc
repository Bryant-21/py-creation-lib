Scriptname BoS101POI_CaravanManagerScript Extends ObjectReference

quest Property BoS101POI Auto

Event OnLoad()
EndEvent

Event OnTimer(Int timerID)
EndEvent
