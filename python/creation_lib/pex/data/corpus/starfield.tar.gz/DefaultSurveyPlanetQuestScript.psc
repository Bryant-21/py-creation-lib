Scriptname DefaultSurveyPlanetQuestScript Extends Quest

Int Property SurveyCompleteStage Auto
keyword Property LocTypeMajorOrbital Auto
referencealias Property PlayerShip Auto
locationalias Property TargetPlanetLocation Auto
locationalias Property TargetSystemLocation Auto

Function OnQuestInit() Native
