Scriptname BoS302_DisableFastTravelTrigger Extends ObjectReference

Event OnTriggerEnter(ObjectReference akActivator)
EndEvent

Event OnTriggerLeave(ObjectReference akActivator)
EndEvent

Event OnUnload()
EndEvent

Function RemoveInputLayer() Native
