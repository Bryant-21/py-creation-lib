Scriptname BQ01_BarrettScript Extends Quest

keyword Property BQ01_Keyword_TempleLocation Auto
locationalias Property Location_Temple Auto

Function OnQuestStarted() Native
