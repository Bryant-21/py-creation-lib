Scriptname CreationClub:VRWorkshops:VRWorkshopParentScript Extends Quest

Struct VRDestinationData
    referencealias VRDestinationMarkerRef
    message VRDestinationName
EndStruct

Struct StructBlacklistObject
    Int FormID
    String PluginFilename
    String Description
EndStruct

keyword Property VRWorkshopShared_Keyword_WorkshopTypeVR Auto
spell Property VRWorkshopShared_AbWaterBreathingSpell Auto
effectshader Property TeleportOutFXS Auto
sound Property VRWorkshop_TravelSoundFX Auto
message Property VRWorkshop_Message_MaxSettlers Auto
structblacklistobject[] Property ArrayStructBlacklistObjects Auto
sound Property VRWorkshop_ArriveSoundFX Auto
workshopparentscript Property WorkshopParent Auto
musictype Property VRWorkshopShared_MUS_NONE Auto
perk Property ImmuneToAcid Auto
perk Property VRWorkshopShared_BlockXP Auto
spell Property VRWorkshopShared_abVRDamageResistSpell Auto
imagespacemodifier Property VRWorkshop_MemoryLoungerExitImod Auto
creationclub:vrworkshops:vrworkshopattacksquestscript Property VRAttackQuest Auto
keyword Property WorkshopLinkSpawn Auto
perk Property VRWorkshopShared_ImmuneToDamagePerk Auto
perk Property ImmuneToPoison Auto
perk Property crNoFallDamage Auto
Bool Property bDisableTerminalFunctions Auto
perk Property ImmuneToRadiation Auto
imagespacemodifier Property VRWorkshop_MemoryLoungerEnterImod Auto
keyword Property VRWorkshopShared_Keyword_LinkedRefMapMarker Auto
sound Property TeleportSound Auto
formlist Property VRWorkshopShared_DisallowedObjectsList Auto
referencealias Property CompanionReturnMarkerREF Auto
Int Property MaxVRSettlers Auto
referencealias Property CurrentReturnPodREF Auto
referencealias Property CurrentTravelMarkerREF Auto
vrdestinationdata[] Property ArrayVRDestinations Auto
message Property VRWorkshopShared_Message_AlreadyInCurrentWorkshop Auto

Function AddPlayerBuffs() Native
Function AddVRSettler() Native
Function BuildDLCObjectBlacklist() Native
Function ChangeVRLocation(Int VRLocationEnum) Native
Function ClearImageSpace() Native
Function ClearMusic() Native
Function ExitVRSettlement() Native
Function HandleCompanionMove() Native
Function HandlePlayerChangeVRLocation() Native
Function HandlePlayerExit() Native
Event OnInit()
EndEvent

Event OnMenuOpenCloseEvent(String asMenuName, Bool abOpening)
EndEvent

Function OverrideMusic(musictype MusicToPlay) Native
Function RemovePlayerBuffs() Native
Function SetImageSpace(imagespacemodifier imageSpaceModifierToSet) Native
Function SetVRPodDestination(Int VRLocationEnum, objectreference TerminalRef, keyword LinkTerminalKeyword) Native
