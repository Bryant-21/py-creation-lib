Scriptname AbCourserSpeedScript Extends ActiveMagicEffect

spell Property CourserPowerUp Auto
Bool Property PoweredUp Auto
Float Property HealthThreshhold Auto
actorvalue Property Health Auto

Event OnEffectFinish(actor akTarget, actor akCaster)
EndEvent

Event OnEffectStart(actor akTarget, actor akCaster)
EndEvent

Event OnHit(objectreference akTarget, objectreference akAggressor, form akSource, projectile akProjectile, Bool abPowerAttack, Bool abSneakAttack, Bool abBashAttack, Bool abHitBlocked, String apMaterial)
EndEvent
