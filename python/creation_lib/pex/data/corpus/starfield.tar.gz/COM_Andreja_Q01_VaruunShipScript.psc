Scriptname COM_Andreja_Q01_VaruunShipScript Extends ReferenceAlias

actorvalue Property pDockingPermission Auto

Function OnLoad() Native
