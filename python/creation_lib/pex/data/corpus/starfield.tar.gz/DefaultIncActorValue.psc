Scriptname DefaultIncActorValue Extends ActiveMagicEffect

actorvalue Property ValueToInc Auto
Float Property AmountToInc Auto

Function OnEffectFinish(objectreference akTarget, actor akCaster, magiceffect akBaseEffect, Float afMagnitude, Float afDuration) Native
Function OnEffectStart(objectreference akTarget, actor akCaster, magiceffect akBaseEffect, Float afMagnitude, Float afDuration) Native
