Scriptname CreationClub:VRWorkshops:PRKF_VRWorkshopShared_PerkOp_0100003F Extends Perk

keyword Property LinkKeyword Auto

Function Fragment_Entry_00(objectreference akTargetRef, actor akActor) Native
