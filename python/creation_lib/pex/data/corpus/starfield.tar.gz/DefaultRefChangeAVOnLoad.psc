Scriptname DefaultRefChangeAVOnLoad Extends ObjectReference

Struct ActorValueDatum
    actorvalue ActorValueToChange
    Int TypeOfChange
    Float NewValue
EndStruct

actorvaluedatum[] Property ActorValueData Auto

Function OnLoad() Native
