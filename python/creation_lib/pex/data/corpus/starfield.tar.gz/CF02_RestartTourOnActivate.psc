Scriptname CF02_RestartTourOnActivate Extends ReferenceAlias

Struct TourScene
    scene sceneToStart
    Int turnOffStage
    Int requiredStage
EndStruct

tourscene[] Property TourScenes Auto
Int Property DoneStage Auto

Function OnActivate(objectreference akActionRef) Native
