Scriptname BoS301PlayerAliasScript Extends ReferenceAlias

form Property ItemToCheck Auto

Event OnAliasInit()
EndEvent

Event OnItemAdded(form akBaseItem, Int aiItemCount, objectreference akItemReference, objectreference akSourceContainer)
EndEvent
