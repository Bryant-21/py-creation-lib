Scriptname DefaultCounterQuestIncOnceOnActivate Extends ReferenceAlias

Function Increment() Native
Event OnActivate(objectreference akActionRef)
EndEvent
