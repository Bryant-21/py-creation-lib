Scriptname BYOH_TIF__01004CF8 Extends TopicInfo

miscobject Property Gold Auto
globalvariable Property HDWhiterunChildRoom Auto

Function Fragment_1(ObjectReference akSpeakerRef) Native
String Function GetState() Native
Function GotoState(String newState) Native
