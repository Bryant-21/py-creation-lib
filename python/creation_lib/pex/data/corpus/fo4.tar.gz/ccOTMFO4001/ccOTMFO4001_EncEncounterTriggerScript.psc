Scriptname ccOTMFO4001:ccOTMFO4001_EncEncounterTriggerScript Extends ObjectReference

keyword Property ccOTMFO4001_EncEncounter Auto Const
Float Property ResetDays Auto Const
globalvariable Property NearestEncampmentGlobal Auto Const
Float Property EncounterChance Auto Const

Function EncounterStarted(ccotmfo4001:ccotmfo4001_encencounterquestscript Encounter) Native
Function OnLoad() Native
Function OnUnload() Native
