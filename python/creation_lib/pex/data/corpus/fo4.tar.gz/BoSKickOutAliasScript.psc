Scriptname BoSKickOutAliasScript Extends ReferenceAlias

quest Property BoSKickOut Auto
