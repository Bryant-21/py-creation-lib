Scriptname CreationClub:VRWorkshops:NPCHologramFXScript Extends activemagiceffect

effectshader Property HologramShaunFXS Auto
sound Property TeleportSound Auto
effectshader Property TeleportOutFXS Auto
effectshader Property TeleportInFXS Auto

Event OnEffectStart(actor akTarget, actor akCaster)
EndEvent
