Scriptname BYOH_TIF__01003DA7 Extends TopicInfo

objectreference Property oldmarker Auto
miscobject Property Gold Auto
globalvariable Property HDWhiterunBedroom Auto
objectreference Property DecorateMarker Auto

Function Fragment_0(objectreference akSpeakerRef) Native
String Function GetState() Native
Function GotoState(String newState) Native
