Scriptname AliasAdvanceStage Extends ReferenceAlias

Int Property StageToLookFor Auto
Int Property StageToSet Auto

String Function GetState() Native
Function GotoState(String newState) Native
Function OnActivate(ObjectReference akActionRef) Native
