Scriptname AbRaceRadstagScript Extends ActiveMagicEffect

Float Property fAttackBelowHPpercent Auto Const
actorvalue Property Confidence Auto Const
actorvalue Property Health Auto Const
Int Property defaultConfidence Auto

Event OnCombatStateChanged(actor akTarget, Int aeCombatState)
EndEvent

Event OnEffectStart(actor akTarget, actor akCaster)
EndEvent

Event OnHit(objectreference akTarget, objectreference akAggressor, form akSource, projectile akProjectile, Bool abPowerAttack, Bool abSneakAttack, Bool abBashAttack, Bool abHitBlocked, String apMaterial)
EndEvent
