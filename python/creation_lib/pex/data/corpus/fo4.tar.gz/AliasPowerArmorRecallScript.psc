Scriptname AliasPowerArmorRecallScript Extends ReferenceAlias

ReferenceAlias Property PowerArmorRef Auto
keyword Property FurnitureTypePowerArmor Auto
quest Property PowerArmorRecallQuest Auto
objectreference Property PowerArmorLastUsed Auto

ReferenceAlias Function GetPowerArmorLastUsed() Native
Function HandleOnSit(objectreference akFurniture) Native
Event OnInit()
EndEvent
