Scriptname AttachArtRandomizerScript Extends Actor

visualeffect Property slotA02 Auto
visualeffect Property slotB03 Auto
visualeffect Property slotA01 Auto
visualeffect Property slotB01 Auto
visualeffect Property slotB02 Auto
visualeffect Property slotA03 Auto

Event OnLoad()
EndEvent
