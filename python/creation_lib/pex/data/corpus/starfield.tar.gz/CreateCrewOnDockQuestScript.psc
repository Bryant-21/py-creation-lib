Scriptname CreateCrewOnDockQuestScript Extends Quest

refcollectionalias Property CrewCollection Auto
referencealias Property PilotChair Auto
referencealias Property Ship Auto
actorvalue Property SpaceshipCrew Auto
referencealias[] Property CrewAliases Auto
referencealias[] Property CrewMarkers Auto

Function OnQuestStarted() Native
Function testShip() Native
