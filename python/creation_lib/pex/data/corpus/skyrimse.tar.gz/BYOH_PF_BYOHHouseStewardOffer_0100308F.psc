Scriptname BYOH_PF_BYOHHouseStewardOffer_0100308F Extends Package

Function Fragment_0(Actor akActor) Native
String Function GetState() Native
Function GotoState(String newState) Native
