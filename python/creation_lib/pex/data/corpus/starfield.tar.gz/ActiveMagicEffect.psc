Scriptname ActiveMagicEffect Extends ScriptObject

Function Dispel() Native
magiceffect Function GetBaseObject() Native
actor Function GetCasterActor() Native
Float Function GetDuration() Native
Float Function GetElapsedTime() Native
form Function GetMagicItem() Native
Float Function GetMagnitude() Native
actorvalue Function GetResistanceValue() Native
actor Function GetTargetActor() Native
Event OnActivate(objectreference akActionRef)
EndEvent

Function OnActorActivatedRef(objectreference akActivatedRef) Native
Function OnAffinityEvent(affinityevent akAffinityEvent, actorvalue akActorValue, globalvariable akReactionValue, objectreference akTarget) Native
Function OnBuilderMenuSelect(actorvalue akActorValue) Native
Event OnCellAttach()
EndEvent

Event OnCellDetach()
EndEvent

Event OnCellLoad()
EndEvent

Event OnClose(objectreference akActionRef)
EndEvent

Function OnCombatListAdded(actor akTarget) Native
Function OnCombatListRemoved(actor akTarget) Native
Event OnCombatStateChanged(objectreference akTarget, Int aeCombatState)
EndEvent

Event OnCommandModeCompleteCommand(Int aeCommandType, objectreference akTarget)
EndEvent

Event OnCommandModeEnter()
EndEvent

Event OnCommandModeExit()
EndEvent

Event OnCommandModeGiveCommand(Int aeCommandType, objectreference akTarget)
EndEvent

Event OnCompanionDismiss()
EndEvent

Event OnConsciousnessStateChanged(Bool abUnconscious)
EndEvent

Event OnContainerChanged(objectreference akNewContainer, objectreference akOldContainer)
EndEvent

Function OnCrewAssigned(actor akCrew, objectreference akAssignmentRef, objectreference akPreviousAssignmentRef) Native
Function OnCrewDismissed(actor akCrew, objectreference akPreviousAssignmentRef) Native
Event OnCripple(actorvalue akActorValue, Bool abCrippled)
EndEvent

Event OnDeath(objectreference akKiller)
EndEvent

Event OnDeferredKill(actor akKiller)
EndEvent

Function OnDestroyed(objectreference akDestroyer) Native
Event OnDestructionStageChanged(Int aiOldStage, Int aiCurrentStage)
EndEvent

Event OnDifficultyChanged(Int aOldDifficulty, Int aNewDifficulty)
EndEvent

Event OnDying(objectreference akKiller)
EndEvent

Event OnEffectFinish(objectreference akTarget, actor akCaster, magiceffect akBaseEffect, Float afMagnitude, Float afDuration)
EndEvent

Event OnEffectStart(objectreference akTarget, actor akCaster, magiceffect akBaseEffect, Float afMagnitude, Float afDuration)
EndEvent

Event OnEnterBleedout()
EndEvent

Function OnEnterFurniture(actor akActionRef) Native
Function OnEnterOutpostBeaconMode() Native
Function OnEnterShipInterior(objectreference akShip) Native
Event OnEnterSneaking()
EndEvent

Event OnEquipped(actor akActor)
EndEvent

Event OnEscortWaitStart()
EndEvent

Event OnEscortWaitStop()
EndEvent

Event OnExitFurniture(objectreference akActionRef)
EndEvent

Function OnExitShipInterior(objectreference akShip) Native
Event OnGetUp(objectreference akFurniture)
EndEvent

Event OnGrab()
EndEvent

Function OnHomeShipSet(spaceshipreference akShip, spaceshipreference akPrevious) Native
Event OnItemAdded(form akBaseItem, Int aiItemCount, objectreference akItemReference, objectreference akSourceContainer, Int aiTransferReason)
EndEvent

Event OnItemEquipped(form akBaseObject, objectreference akReference)
EndEvent

Event OnItemRemoved(form akBaseItem, Int aiItemCount, objectreference akItemReference, objectreference akDestContainer, Int aiTransferReason)
EndEvent

Event OnItemUnequipped(form akBaseObject, objectreference akReference)
EndEvent

Event OnKill(objectreference akVictim)
EndEvent

Event OnLoad()
EndEvent

Event OnLocationChange(location akOldLoc, location akNewLoc)
EndEvent

Event OnLockStateChanged()
EndEvent

Function OnMapMarkerDiscovered() Native
Function OnObjectDestroyed(objectreference akReference) Native
Function OnObjectRepaired(objectreference akReference) Native
Event OnOpen(objectreference akActionRef)
EndEvent

Function OnOutpostItemPowerOff(objectreference akPoweredItem) Native
Function OnOutpostItemPowerOn(objectreference akPoweredItem, objectreference akPowerGenerator) Native
Function OnOutpostPlaced(objectreference akOutpostBeacon) Native
Event OnPackageChange(package akOldPackage)
EndEvent

Event OnPackageEnd(package akOldPackage)
EndEvent

Event OnPackageStart(package akNewPackage)
EndEvent

Event OnPartialCripple(actorvalue akActorValue, Bool abCrippled)
EndEvent

Function OnPickLock(objectreference akLockedRef, Bool abCrime, Bool abSucceeded, terminalmenu akLockedTerminalMenu, Int aiTerminalMenuItem) Native
Event OnPickpocketFailed()
EndEvent

Event OnPipboyRadioDetection(Bool abDetected)
EndEvent

Function OnPlayerArrested(objectreference akGuard, location akLocation, Int aeCrimeType) Native
Function OnPlayerAssaultActor(objectreference akVictim, location akLocation, Bool aeCrime) Native
Function OnPlayerBuyShip(spaceshipreference akShip) Native
Function OnPlayerCompleteResearch(objectreference akBench, location akLocation, researchproject akProject) Native
Function OnPlayerCraftItem(objectreference akBench, location akLocation, form akCreatedItem) Native
Event OnPlayerCreateRobot(actor akNewRobot)
EndEvent

Function OnPlayerCrimeGold(objectreference akVictim, form akFaction, Int aeCrimeGold, Int aeCrimeType) Native
Event OnPlayerDialogueTarget()
EndEvent

Event OnPlayerEnterVertibird(objectreference akVertibird)
EndEvent

Function OnPlayerFailedPlotRoute(Int aeFailedPlotReason) Native
Event OnPlayerFallLongDistance(Float afDamage)
EndEvent

Event OnPlayerFireWeapon(form akBaseObject)
EndEvent

Function OnPlayerFollowerWarp(objectreference akFollower) Native
Event OnPlayerHealTeammate(actor akTeammate)
EndEvent

Function OnPlayerItemAdded(form akBaseObject, objectreference akOwner, objectreference akSourceContainer, Int aeAcquireType) Native
Function OnPlayerJail(objectreference akGuard, form akFaction, location akLocation, Int aeCrimeGold) Native
Event OnPlayerLoadGame()
EndEvent

Function OnPlayerLoiteringBegin() Native
Function OnPlayerLoiteringEnd() Native
Event OnPlayerModArmorWeapon(form akBaseObject, objectmod akModBaseObject)
EndEvent

Function OnPlayerModifiedShip(spaceshipreference akShip) Native
Event OnPlayerModRobot(actor akRobot, objectmod akModBaseObject)
EndEvent

Function OnPlayerMurderActor(objectreference akVictim, location akLocation, Bool aeCrime) Native
Function OnPlayerPayFine(objectreference akGuard, form akFaction, Int aeCrimeGold) Native
Function OnPlayerPlanetSurveyComplete(planet akPlanet) Native
Function OnPlayerScannedObject(objectreference akScannedRef) Native
Function OnPlayerSellShip(spaceshipreference akShip) Native
Event OnPlayerSwimming()
EndEvent

Function OnPlayerTrespass(objectreference akVictim, location akLocation, Bool aeCrime) Native
Event OnPlayerUseWorkBench(objectreference akWorkBench)
EndEvent

Event OnPowerOff()
EndEvent

Event OnPowerOn(objectreference akPowerGenerator)
EndEvent

Function OnQuickContainerOpened() Native
Event OnRaceSwitchComplete()
EndEvent

Event OnRead()
EndEvent

Function OnRecoverFromBleedout() Native
Event OnRelease()
EndEvent

Event OnReset()
EndEvent

Function OnScanned() Native
Event OnSell(actor akSeller)
EndEvent

Function OnShipBought() Native
Function OnShipDock(Bool abComplete, spaceshipreference akDocking, spaceshipreference akParent) Native
Function OnShipFarTravel(location aDepartureLocation, location aArrivalLocation, Int aState) Native
Function OnShipGravJump(location aDestination, Int aState) Native
Function OnShipLanding(Bool abComplete) Native
Function OnShipRampDown() Native
Function OnShipRefueled(Int aFuelAdded) Native
Function OnShipScan(location aPlanet, objectreference[] aMarkersArray) Native
Function OnShipSold() Native
Function OnShipSystemDamaged(actorvalue akSystem, Int aBlocksLost, Bool aElectromagneticDamage, Bool aFullyDamaged) Native
Function OnShipSystemPowerChange(actorvalue akSystem, Bool abAddPower, Bool abDamageRelated) Native
Function OnShipSystemRepaired(actorvalue akSystem, Int aBlocksGained, Bool aElectromagneticDamage) Native
Function OnShipTakeOff(Bool abComplete) Native
Function OnShipUndock(Bool abComplete, spaceshipreference akUndocking, spaceshipreference akParent) Native
Event OnSit(objectreference akFurniture)
EndEvent

Event OnSpeechChallengeAvailable(objectreference akSpeaker)
EndEvent

Event OnSpellCast(form akSpell)
EndEvent

Function OnTerminalMenuItemRun(Int auiMenuItemID, terminalmenu akTerminalBase, objectreference akTerminalRef) Native
Event OnTranslationAlmostComplete()
EndEvent

Event OnTranslationComplete()
EndEvent

Event OnTranslationFailed()
EndEvent

Event OnTrapHitStart(objectreference akTarget, Float afXVel, Float afYVel, Float afZVel, Float afXPos, Float afYPos, Float afZPos, Int aeMaterial, Bool abInitialHit, Int aeMotionType)
EndEvent

Event OnTrapHitStop(objectreference akTarget)
EndEvent

Event OnTriggerEnter(objectreference akActionRef)
EndEvent

Event OnTriggerLeave(objectreference akActionRef)
EndEvent

Event OnUnequipped(actor akActor)
EndEvent

Event OnUnload()
EndEvent

Function OnWorkshopCargoLinkChanged(objectreference akOldTarget, objectreference akNewTarget) Native
Function OnWorkshopFlyCam(Bool aStart) Native
Event OnWorkshopMode(Bool aStart)
EndEvent

Event OnWorkshopNPCTransfer(location akNewWorkshop, keyword akActionKW)
EndEvent

Event OnWorkshopObjectGrabbed(objectreference akReference)
EndEvent

Event OnWorkshopObjectMoved(objectreference akReference)
EndEvent

Event OnWorkshopObjectPlaced(objectreference akReference)
EndEvent

Function OnWorkshopObjectRemoved(objectreference akReference) Native
Function OnWorkshopOutputLink(objectreference akSource, objectreference akTarget) Native
Function StartObjectProfiling() Native
Function StopObjectProfiling() Native
