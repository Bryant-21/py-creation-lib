Scriptname CompanionDebugScript Extends Actor

Struct QuestStageDatum
    quest QuestToSet
    Int StageToSet
EndStruct

actorvalue Property COM_DEBUG_OnPlayerShip Auto
sq_companions_activecompanionscript Property ActiveCompanion Auto
queststagedatum[] Property QuestStageData Auto

Function DebugAwardSecondChance() Native
Function DebugExpireAngerCoolDownTimer() Native
Function DebugExpireFlirtCooldown() Native
Function DebugExpireTravelAffinityCoolDown() Native
Function DebugIsPlayerLoitering() Native
Function DebugMakeActiveCompanion() Native
Function DebugMakeAvailableCompanion() Native
Function DebugMakeInactiveCompanion() Native
Function DebugMakeRomantic() Native
Function DebugModAffinity(Float Amount) Native
Function DebugSetAffinityLevel(globalvariable AffinityLevel) Native
Function DebugSetAngerLevel(globalvariable AngerLevel, globalvariable AngerReason) Native
Function DebugSetOnPlayerShip() Native
Function DebugSetStoryGateTimerComplete() Native
Function DebugTestConditionForm(conditionform ConditionFormToTest) Native
Function OnInit() Native
Bool Function Trace(ScriptObject CallingObject, String asTextToPrint, Int aiSeverity, String MainLogName, String SubLogName, Bool bShowNormalTrace, Bool bShowWarning, Bool bPrefixTraceWithLogNames) Native
Bool Function warning(ScriptObject CallingObject, String asTextToPrint, Int aiSeverity, String MainLogName, String SubLogName, Bool bShowNormalTrace, Bool bShowWarning, Bool bPrefixTraceWithLogNames) Native
