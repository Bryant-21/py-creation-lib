Scriptname COM_ConvoQuestScript Extends Quest

Quest Property QuestToSet Auto
Int Property StageToSet Auto

Function SceneCompleted() Native
