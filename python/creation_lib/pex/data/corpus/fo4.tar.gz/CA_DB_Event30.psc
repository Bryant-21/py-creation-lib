Scriptname CA_DB_Event30 Extends ca_dialoguebump_basescript

Function InitializeEventID() Native
