Scriptname BQPlayerScript Extends ReferenceAlias

String Function GetState() Native
Function GotoState(String newState) Native
Function OnLocationChange(Location akOldLoc, Location akNewLoc) Native
