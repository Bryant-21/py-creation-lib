Scriptname ccBGSFO4046_:GunnerTerminalScript Extends Terminal

objectreference Property NextGunnerRef Auto
Int Property MenuNumber Auto
Int Property StageToSet Auto
message Property SignalMessage Auto
quest Property RadioQuest Auto
quest Property CCQuest Auto

Function OnMenuItemRun(Int auiMenuItemID, objectreference akTerminalRef) Native
