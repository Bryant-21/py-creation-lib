Scriptname BehemothSlamsFXScript Extends ActiveMagicEffect

explosion Property pBehemothSlamExplosion Auto
explosion Property pBehemothStompExplosion Auto

Event OnAnimationEvent(objectreference akSource, String asEventName)
EndEvent

Event OnEffectFinish(actor akTarget, actor akCaster)
EndEvent

Event OnEffectStart(actor akTarget, actor akCaster)
EndEvent
