Scriptname DefaultAliasOnDeath Extends DefaultAlias

objectreference[] Property KilledByReferences Auto
referencealias[] Property KilledByAliases Auto
Bool Property UseOnDyingInstead Auto
faction[] Property KilledByFactions Auto

Event OnDeath(actor akKiller)
EndEvent

Event OnDying(actor akKiller)
EndEvent
