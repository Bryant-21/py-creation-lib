Scriptname AOPackageKeywordManager Extends Package

keyword Property keywordToAdd Auto Const

Event OnChange(actor akActor)
EndEvent

Event OnStart(actor akActor)
EndEvent
