Scriptname BE_DerelictScript Extends Quest

referencealias Property ModuleCockpit Auto
Bool Property RandomTrack Auto
Int Property TrackNumber Auto
musictype[] Property MusicTrack Auto

Function OnQuestStarted() Native
Function PlayMusic(musictype MusicTrack, Bool abPlay) Native
