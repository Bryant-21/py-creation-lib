Scriptname AOAliasBailOutScript Extends ReferenceAlias

Bool Property Bail_If_AutonomyDisallowed Auto
Float Property Bail_If_Escort_Wait_Duration Auto
scene Property BailOut_Stop_Scene Auto
Bool Property Bail_If_CommandMode Auto
Float Property Bail_If_Distance_From_Player Auto
scene[] Property BailOut_Additional_Scenes_To_Stop Auto

Function BailOut() Native
Event OnAliasInit()
EndEvent

Event OnCommandModeEnter()
EndEvent

Event OnCommandModeGiveCommand(Int aeCommandType, objectreference akTarget)
EndEvent

Event OnEscortWaitStart()
EndEvent

Event OnEscortWaitStop()
EndEvent

Event OnTimer(Int aiTimerID)
EndEvent

Function StartDistancePollingIfNeeded() Native
