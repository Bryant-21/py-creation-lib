Scriptname DefaultAliasReadWhileSittingScript Extends ReferenceAlias

idle Property IdleBookReadStart Auto
package[] Property ReadingPackages Auto

Event OnSit(objectreference akFurniture)
EndEvent
