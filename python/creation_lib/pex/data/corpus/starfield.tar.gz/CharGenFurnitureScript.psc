Scriptname CharGenFurnitureScript Extends ObjectReference

Function OnAnimationEvent(ObjectReference akSource, String asEventName) Native
Function OnExitFurniture(ObjectReference akActionRef) Native
Function OnLoad() Native
