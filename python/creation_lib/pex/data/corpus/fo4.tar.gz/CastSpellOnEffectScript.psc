Scriptname CastSpellOnEffectScript Extends ActiveMagicEffect

spell Property OnEffectSpell Auto

Event OnEffectStart(actor akTarget, actor akCaster)
EndEvent
