Scriptname CIS_ChatWithNPC_HancockScript Extends Quest

Int Property iDialougeSet Auto
