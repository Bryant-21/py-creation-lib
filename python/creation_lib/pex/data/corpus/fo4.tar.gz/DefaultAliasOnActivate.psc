Scriptname DefaultAliasOnActivate Extends DefaultAlias

Bool Property BlockWhilePlayerIsInCombat Auto
faction[] Property ActivatedByFactions Auto
Bool Property PlayerActivateOnly Auto
message Property CombatNoActivate Auto
Bool Property BlockWhilePlayerIsSitting Auto
objectreference[] Property ActivatedByReferences Auto
message Property PowerArmorNoActivate Auto
referencealias[] Property ActivatedByAliases Auto
Bool Property BlockWhilePlayerIsInPowerArmor Auto

Event OnActivate(objectreference akActionRef)
EndEvent
