Scriptname DefaultAliasOnDeath Extends DefaultAliasParent

locationalias[] Property LocationAliasesToCheckAgainst Auto
Bool Property LocationMatchIfChild Auto
Bool Property ClearAliasOnDeath Auto
Bool Property PlayerOnly Auto
objectreference[] Property ReferencesToCheckAgainst Auto
referencealias[] Property AliasesToCheckAgainst Auto
faction[] Property FactionsToCheckAgainst Auto
location[] Property LocationsToCheckAgainst Auto
Bool Property UseOnDyingInstead Auto

Function DeathComplete(objectreference akKiller) Native
referencealias[] Function GetAliasesToCheckAgainst() Native
faction[] Function GetFactionsToCheckAgainst() Native
locationalias[] Function GetLocationAliasesToCheckAgainst() Native
Bool Function GetLocationMatchIfChild() Native
location[] Function GetLocationsToCheckAgainst() Native
Bool Function GetPlayerOnly() Native
objectreference[] Function GetReferencesToCheckAgainst() Native
Event OnDeath(objectreference akKiller)
EndEvent

Event OnDying(objectreference akKiller)
EndEvent
