Scriptname DefaultBlockActivationOnLoad Extends ObjectReference

Bool Property HideActivationText Auto

Event OnActivate(ObjectReference akActionRef)
EndEvent

Event OnLoad()
EndEvent
