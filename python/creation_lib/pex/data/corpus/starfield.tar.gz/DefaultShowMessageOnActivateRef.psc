Scriptname DefaultShowMessageOnActivateRef Extends ObjectReference

Int Property Button3StageToSet Auto
Int Property MessageStage Auto
message Property MessageToShow Auto
Bool Property ShowTraces Auto
quest Property QuestToSet Auto
Int Property Button0StageToSet Auto
Int Property Button1StageToSet Auto
Int Property Button2StageToSet Auto
Bool Property ShowIfStageIsSet Auto

Event OnActivate(ObjectReference akActionRef)
EndEvent
