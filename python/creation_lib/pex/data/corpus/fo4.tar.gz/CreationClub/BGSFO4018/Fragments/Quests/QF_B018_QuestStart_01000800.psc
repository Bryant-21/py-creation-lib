Scriptname CreationClub:BGSFO4018:Fragments:Quests:QF_B018_QuestStart_01000800 Extends Quest

Quest Property B018_Quest Auto

Function Fragment_Stage_0000_Item_00() Native
