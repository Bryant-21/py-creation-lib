Scriptname AffinityEvent Extends Form

Function Reset() Native
Function Send(objectreference akTarget) Native
