Scriptname Bos304_PrimeAliasScript Extends ReferenceAlias

quest Property DNPrime_BoS304 Auto Const
Int Property myStage Auto Const
Int Property myStageEnd Auto Const

Event OnAnimationEvent(objectreference akSource, String asEventName)
EndEvent

Event OnLoad()
EndEvent
