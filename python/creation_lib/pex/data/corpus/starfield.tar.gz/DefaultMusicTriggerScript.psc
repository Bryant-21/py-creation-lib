Scriptname DefaultMusicTriggerScript Extends ObjectReference

musictype[] Property MusicShort Auto
musictype[] Property Music Auto
musictype Property MusicOverride Auto
Int Property MusicTypeToPlay Auto
Bool Property PlayShortVersion Auto

Event OnTriggerEnter(ObjectReference TriggerRef)
EndEvent
