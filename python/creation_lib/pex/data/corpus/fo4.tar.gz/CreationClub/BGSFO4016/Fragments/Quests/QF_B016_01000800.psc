Scriptname CreationClub:BGSFO4016:Fragments:Quests:QF_B016_01000800 Extends Quest

armor Property PccBGSFO4016_Armor_MorganSpaceSuit Auto Const
referencealias Property Alias_Player Auto Const

Function Fragment_Stage_1000_Item_00() Native
