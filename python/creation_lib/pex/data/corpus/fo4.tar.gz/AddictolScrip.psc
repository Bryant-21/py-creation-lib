Scriptname AddictolScrip Extends ActiveMagicEffect

spell Property Addiction Auto

Event OnEffectStart(actor akTarget, actor akCaster)
EndEvent
