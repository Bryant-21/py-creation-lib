Scriptname CZScript Extends Quest

idle Property IdleFightWinner Auto Const
referencealias Property ArenaAnnounceMarker Auto Const
Bool Property bPlayerInCage Auto
referencealias Property ArenaPlayerEntranceTrigger Auto Const
referencealias Property StageController Auto Const
actorvalue Property Aggression Auto Const
referencealias Property ArenaCorner2Marker Auto Const
referencealias Property CageDoor Auto Const
referencealias Property ArenaSpawnMarker Auto Const
refcollectionalias Property Attackers Auto Const
referencealias Property AnnouncerHeadtrackMarker3 Auto Const
referencealias Property AnnouncerHeadtrackMarker2 Auto Const
referencealias Property Tommy Auto Const
referencealias Property AnnouncerHeadtrackMarker1 Auto Const
arenascript Property Arena Auto Const
referencealias Property ArenaCorner1Marker Auto Const

Function PlayTriumphantIdle(referencealias AliasToTryToPlay) Native
Function SetCageLockState(Bool Lock = false) Native
Function SetRaiderAggression(Int iAggressionNum) Native
Function SetupMatch(actor Combatant1Ref = none, actor Combatant2Ref = none, Int Rank = 0) Native
Function SpotlightPlayer(Bool turnOnLight) Native
Function TurnOffCaitIntroSpotlight() Native
