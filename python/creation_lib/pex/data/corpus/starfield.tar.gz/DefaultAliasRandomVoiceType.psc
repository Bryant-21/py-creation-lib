Scriptname DefaultAliasRandomVoiceType Extends ReferenceAlias

formlist Property VoicesList Auto
Bool Property ShowTraces Auto

Function OnAliasInit() Native
