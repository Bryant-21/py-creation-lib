Scriptname ccBGSFO4115_:Fragments:Quests:QF_ccBGSFO4115_EnclaveRadioQ_01000A24 Extends Quest

Quest Property ccBGSFO4115_BlackDevilRadio01 Auto Const
Quest Property ccBGSFO4115_BlackDevilRadio03 Auto Const
Quest Property ccBGSFO4115_DM_Quest Auto Const
Quest Property ccBGSFO4115_BlackDevilRadio02 Auto Const
referencealias Property Alias_Safe Auto Const

Function Fragment_Stage_0010_Item_00() Native
Function Fragment_Stage_0015_Item_00() Native
Function Fragment_Stage_0020_Item_00() Native
Function Fragment_Stage_0030_Item_00() Native
Function Fragment_Stage_0040_Item_00() Native
