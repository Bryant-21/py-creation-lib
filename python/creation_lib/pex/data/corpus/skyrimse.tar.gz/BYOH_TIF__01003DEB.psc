Scriptname BYOH_TIF__01003DEB Extends TopicInfo

quest Property RelationshipAdoption Auto

Function Fragment_0(ObjectReference akSpeakerRef) Native
String Function GetState() Native
Function GotoState(String newState) Native
