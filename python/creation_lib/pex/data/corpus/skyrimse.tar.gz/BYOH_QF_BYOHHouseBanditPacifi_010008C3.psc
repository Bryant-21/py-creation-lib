Scriptname BYOH_QF_BYOHHouseBanditPacifi_010008C3 Extends Quest

referencealias Property Alias_Bandit07 Auto
referencealias Property Alias_Bandit06 Auto
referencealias Property Alias_Bandit09 Auto
referencealias Property Alias_Bandit03 Auto
Int[] Property OriginalAggression Auto
referencealias Property Alias_Player Auto
referencealias Property Alias_Bandit10 Auto
referencealias[] Property BanditAliases Auto
locationalias Property Alias_BanditLocation Auto
referencealias Property Alias_Bandit08 Auto
referencealias Property Alias_Bandit05 Auto
referencealias Property Alias_Bandit02 Auto
referencealias Property Alias_Bandit01 Auto
referencealias Property Alias_Bandit04 Auto

Function Fragment_0() Native
Function Fragment_5() Native
String Function GetState() Native
Function GotoState(String newState) Native
