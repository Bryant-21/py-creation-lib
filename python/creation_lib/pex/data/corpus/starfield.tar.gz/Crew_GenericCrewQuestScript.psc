Scriptname Crew_GenericCrewQuestScript Extends Crew_RecruitQuestScript

keyword Property LinkGenericCrewSpawnMarker Auto

Function OnQuestInit() Native
Function Recruited() Native
