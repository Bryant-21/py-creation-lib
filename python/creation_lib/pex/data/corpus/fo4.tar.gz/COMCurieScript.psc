Scriptname COMCurieScript Extends Quest

cell Property pElevTransVault Auto Const
globalvariable Property pCOMCurieLeftVault Auto Const
location Property pVault81Location Auto Const
Int Property bRejectCompanion Auto

Function RegisterLocationChange() Native
