Scriptname BladeTrapHit Extends TrapHitBase

String Function GetState() Native
Function GotoState(String newState) Native
Function OnAnimationEvent(ObjectReference eventObject, String eventString) Native
Function OnTrapHit(ObjectReference akTarget, Float afXVel, Float afYVel, Float afZVel, Float afXPos, Float afYPos, Float afZPos, Int aeMaterial, Bool abInitialHit, Int aeMotionType) Native
Function OnTrapHitStart(ObjectReference akTarget, Float afXVel, Float afYVel, Float afZVel, Float afXPos, Float afYPos, Float afZPos, Int aeMaterial, Bool abInitialHit, Int aeMotionType) Native
