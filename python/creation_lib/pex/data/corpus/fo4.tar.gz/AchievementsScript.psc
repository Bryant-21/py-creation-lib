Scriptname AchievementsScript Extends Quest

Struct StatAchievement
    String StatName
    Int AchievementNumber
    Int Threshold
EndStruct

String[] Property FutureRetroStats Auto
statachievement[] Property StatAchievements Auto
Int Property nGiantsKilled Auto
Int Property nNumberOfCompanions Auto

Bool Function HandleBasicStat(String statFilter) Native
Bool Function HandleBobbleheadStat(String statFilter, Int statValue) Native
Bool Function HandleCraftedStat(String statFilter, Int statValue) Native
Bool Function HandleRetroStat(String statFilter) Native
Function InitializeQuest() Native
Event OnTrackedStatsEvent(String statFilter, Int statValue)
EndEvent

Function RegisterEvents() Native
Function UnregisterFutureRetroEvents() Native
Function UpdateCraftedAchievement(String statFilter, Int currentValue) Native
