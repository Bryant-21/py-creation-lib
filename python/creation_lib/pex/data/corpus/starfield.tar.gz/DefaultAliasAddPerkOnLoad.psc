Scriptname DefaultAliasAddPerkOnLoad Extends ReferenceAlias

perk Property PerkToAdd Auto
Bool Property doOnce Auto

Event OnLoad()
EndEvent
