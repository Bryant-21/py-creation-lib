Scriptname BFXcontrolScript Extends ObjectReference

imagespacemodifier Property DBFireImod Auto

String Function GetState() Native
Function GotoState(String newState) Native
Function onLoad() Native
Function onUnLoad() Native
