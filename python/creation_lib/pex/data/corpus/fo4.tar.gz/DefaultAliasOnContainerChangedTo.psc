Scriptname DefaultAliasOnContainerChangedTo Extends DefaultAlias

faction[] Property ItemChangedToFactions Auto Const
objectreference[] Property ItemChangedToReferences Auto Const
Bool Property PlayerPickupOnly Auto Const
referencealias[] Property ItemChangedToAliases Auto Const

Event OnContainerChanged(objectreference akNewContainer, objectreference akOldContainer)
EndEvent
