Scriptname AddictionOddsScript Extends ActiveMagicEffect

actorvalue Property TrackingActorValue Auto
Float Property Magnitude Auto

Event OnEffectStart(actor akTarget, actor akCaster)
EndEvent
