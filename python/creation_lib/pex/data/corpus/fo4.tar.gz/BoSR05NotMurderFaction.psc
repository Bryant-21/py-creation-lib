Scriptname BoSR05NotMurderFaction Extends Quest

refcollectionalias Property NotMurderFactionBosses Auto
locationalias Property Settlement Auto
referencealias Property Workshop Auto
workshopparentscript Property WorkshopParent Auto

Event OnQuestInit()
EndEvent
