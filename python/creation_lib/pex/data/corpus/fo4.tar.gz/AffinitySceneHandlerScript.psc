Scriptname AffinitySceneHandlerScript Extends Quest

globalvariable Property CA_T3_Neutral Auto Const
globalvariable Property CA_TCustom2_Friend Auto Const
globalvariable Property CA_TCustom1_Confidant Auto Const
globalvariable Property CA_T1_Infatuation Auto Const
globalvariable Property CA_T5_Hatred Auto Const
referencealias Property CompanionAlias Auto Const
globalvariable Property CA_T2_Admiration Auto Const
globalvariable Property CA_T4_Disdain Auto Const

Function EndSceneAdmiration() Native
Function EndSceneConfidant() Native
Function EndSceneDisdain() Native
Function EndSceneFriend() Native
Function EndSceneHatred() Native
Function EndSceneInfatuation() Native
Function EndSceneNeutral() Native
Function UnlockedInfatuation() Native
