Scriptname COM_Quest_SamCoe_Q01_LocationScript Extends ReferenceAlias

locationalias Property VictorLocation Auto
Int Property DistanceCheck Auto
Int Property DoneStage Auto
Int Property PrereqStage Auto
keyword Property LinkCustom04 Auto
scene Property COM_SamCoeQ01_0750_LillianAlert Auto
ReferenceAlias Property Alias_CoraCoe Auto
ReferenceAlias Property Alias_SamCoe Auto

Function OnLocationChange(location akOldLoc, location akNewLoc) Native
