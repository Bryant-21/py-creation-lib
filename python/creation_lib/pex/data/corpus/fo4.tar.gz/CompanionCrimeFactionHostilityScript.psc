Scriptname CompanionCrimeFactionHostilityScript Extends Actor

faction[] Property IgnoreSharedCrimeForAnyoneInTheseFactions Auto Const

Event OnCombatStateChanged(Actor akTarget, Int aeCombatState)
EndEvent

Event OnTimer(Int aiTimerID)
EndEvent

Function TestForSharedCrimeCombatants() Native
