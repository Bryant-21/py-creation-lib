Scriptname BHIntCombatReal Extends ObjectReference

keyword Property LinkCustom01 Auto Const
keyword Property LinkCustom02 Auto Const
keyword Property LinkCustom03 Auto Const
keyword Property LinkCustom04 Auto Const

Event OnTriggerEnter(ObjectReference akActionRef)
EndEvent
