Scriptname DefaultRefEffectShader Extends ObjectReference

effectshader Property FXS Auto
Bool Property ApplyOnLoad Auto

Event OnLoad()
EndEvent
