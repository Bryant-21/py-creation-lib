Scriptname DefaultAlias Extends ReferenceAlias

Bool Property ShowTraces Auto
Int Property TurnOffStage Auto
Int Property StageToSet Auto
Int Property PrereqStage Auto
Bool Property TurnOffWhenDead Auto

Function TryToSetStage(Bool PlayerCheckOverride = FALSE, objectreference RefToCheck = NONE, form FormToCheck = NONE, objectreference[] ReferenceArray = NONE, referencealias[] AliasArray = NONE, faction[] FactionArray = NONE, form[] FormArray = NONE, location[] LocationArray = NONE, locationalias[] LocationAliasArray = NONE, Bool LocationMatchIfChild = false) Native
