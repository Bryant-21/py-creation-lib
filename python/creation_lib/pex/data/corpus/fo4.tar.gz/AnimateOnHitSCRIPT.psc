Scriptname AnimateOnHitSCRIPT Extends ObjectReference

String Property eventName Auto

Event OnHit(ObjectReference akTarget, ObjectReference akAggressor, form akSource, projectile akProjectile, Bool abPowerAttack, Bool abSneakAttack, Bool abBashAttack, Bool abHitBlocked, String asMaterialName)
EndEvent

Event OnLoad()
EndEvent

Event OnUnload()
EndEvent
