Scriptname CA_DB_Event24 Extends ca_dialoguebump_basescript

Function InitializeEventID() Native
