Scriptname CF05_TerminalActivationScript Extends ReferenceAlias

scene Property BlockingScene Auto
faction Property LC043SY01Faction Auto
Float Property DistanceCheck Auto
ReferenceAlias Property Alias_Guard Auto
Int Property AlarmStage Auto

Function OnActivate(objectreference akActionRef) Native
Function OnAliasInit() Native
