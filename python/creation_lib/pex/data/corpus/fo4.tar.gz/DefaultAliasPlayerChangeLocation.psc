Scriptname DefaultAliasPlayerChangeLocation Extends DefaultAlias

Bool Property EnteringIgnoreIfNewLocIsChild Auto Const
Bool Property LeavingIgnoreIfNewLocIsChild Auto Const
locationalias[] Property LeavingOneOfTheseAliases Auto Const
location[] Property LeavingOneOfTheseLocations Auto Const
Bool Property LeavingIgnoreIfOldLocIsChild Auto Const
Bool Property EnteringIgnoreIfOldLocIsChild Auto Const
locationalias[] Property EnteringOneOfTheseAliases Auto Const
location[] Property EnteringOneOfTheseLocations Auto Const

Event OnLocationChange(location akOldLoc, location akNewLoc)
EndEvent
