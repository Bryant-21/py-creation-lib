Scriptname containerOpenIfEmpty Extends ObjectReference

Event OnClose(ObjectReference akActionRef)
EndEvent

Event OnLoad()
EndEvent
