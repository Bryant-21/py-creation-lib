Scriptname DefaultDisableHavokOnLoad Extends ObjectReference

Bool Property HavokOnHit Auto
Bool Property ShowTraces Auto
Float Property HavokImpulseMagnitude Auto
Bool Property BeenSimmed Auto
keyword Property LinkHavokPartner Auto
Bool Property HavokOnZKey Auto
Bool Property HavokOnActivate Auto

Event onActivate(ObjectReference triggerRef)
EndEvent

Event OnContainerChanged(ObjectReference akNewContainer, ObjectReference akOldContainer)
EndEvent

Event onGrab()
EndEvent

Event onHit(ObjectReference akTarget, ObjectReference var1, form var2, projectile var3, Bool var4, Bool var5, Bool var6, Bool var7, String asMaterialName)
EndEvent

Event onLoad()
EndEvent

Event onUnload()
EndEvent

Function ReleaseToHavok() Native
