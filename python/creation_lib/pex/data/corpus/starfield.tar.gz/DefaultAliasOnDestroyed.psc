Scriptname DefaultAliasOnDestroyed Extends DefaultAliasParent

Bool Property LocationMatchIfChild Auto
locationalias[] Property LocationAliasesToCheckAgainst Auto
location[] Property LocationsToCheckAgainst Auto
Bool Property PlayerOnly Auto
faction[] Property FactionsToCheckAgainst Auto
referencealias[] Property AliasesToCheckAgainst Auto
objectreference[] Property ReferencesToCheckAgainst Auto

referencealias[] Function GetAliasesToCheckAgainst() Native
faction[] Function GetFactionsToCheckAgainst() Native
locationalias[] Function GetLocationAliasesToCheckAgainst() Native
Bool Function GetLocationMatchIfChild() Native
location[] Function GetLocationsToCheckAgainst() Native
Bool Function GetPlayerOnly() Native
objectreference[] Function GetReferencesToCheckAgainst() Native
Function OnDestroyed(objectreference akDestroyer) Native
