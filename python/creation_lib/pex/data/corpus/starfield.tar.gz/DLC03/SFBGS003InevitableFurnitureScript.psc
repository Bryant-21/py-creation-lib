Scriptname DLC03:SFBGS003InevitableFurnitureScript Extends ReferenceAlias

actorbase Property SFBGS003_Inevitable Auto

Function OnAliasInit() Native
