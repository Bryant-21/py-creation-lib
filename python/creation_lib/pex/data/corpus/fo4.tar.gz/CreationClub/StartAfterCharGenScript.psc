Scriptname CreationClub:StartAfterCharGenScript Extends Quest

Int Property MyStageToSet Auto Const
Int Property CharGenStageToWatch Auto Const
Quest Property MQ102 Auto Const

Event OnInit()
EndEvent

Event OnTimer(Int aiTimerID)
EndEvent

Function SetCreationStage() Native
