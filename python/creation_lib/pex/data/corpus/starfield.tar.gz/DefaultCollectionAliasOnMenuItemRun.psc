Scriptname DefaultCollectionAliasOnMenuItemRun Extends RefCollectionAlias

defaultaliasonmenuitemrun:menuitemdatum[] Property MenuItemData Auto
Bool Property ShowTraces Auto

Function OnTerminalMenuItemRun(objectreference akSender, Int auiMenuItemID, terminalmenu akTerminalBase, objectreference akTerminalRef) Native
