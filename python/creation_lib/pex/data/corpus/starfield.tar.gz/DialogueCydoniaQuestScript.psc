Scriptname DialogueCydoniaQuestScript Extends Quest

globalvariable Property DialogueCydonia_HorusAid_CooldownTime Auto
weapon Property Cutter Auto
refcollectionalias Property AllMiners Auto
Float Property CooldownTimerDays Auto
leveleditem Property LL_CY_HorusGift Auto

Function HorusAid() Native
Function SetCooldown() Native
Function SwapCutters() Native
