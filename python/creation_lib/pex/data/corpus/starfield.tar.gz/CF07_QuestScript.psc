Scriptname CF07_QuestScript Extends Quest

Int Property TalkToCompanion Auto
globalvariable Property CF_SysDefShutdown Auto
referencealias Property Companion Auto

Function OnQuestInit() Native
