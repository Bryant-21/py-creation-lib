Scriptname DefaultActivateLinkOnUnlock Extends ObjectReference

keyword Property MyLink Auto

Event OnLockStateChanged()
EndEvent
