Scriptname DefaultSendStoryEventOnLoad Extends DefaultRefParent

Int Property Value2 Auto
Int Property Value1 Auto
keyword Property StoryEventKeyword Auto
Bool Property xxxPlaceHolderForEmptyGroup2xxx Auto

Function DoSpecificThing(defaultscriptfunctions:parentscriptfunctionparams ParentScriptFunctionParams, objectreference RefToDoThingWith, Bool LastRefToDoThingWith) Native
Function OnInit() Native
Function OnLoad() Native
