Scriptname CCT_Enviro_BehaviorScript Extends Quest

referencealias Property BehaviorActor Auto
spell Property BehaviorAbility Auto

Function ApplyBehaviorAbility(Bool bApply) Native
