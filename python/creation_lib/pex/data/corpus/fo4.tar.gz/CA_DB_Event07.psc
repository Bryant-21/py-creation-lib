Scriptname CA_DB_Event07 Extends ca_dialoguebump_basescript

Function InitializeEventID() Native
