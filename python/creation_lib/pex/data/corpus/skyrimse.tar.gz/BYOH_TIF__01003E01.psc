Scriptname BYOH_TIF__01003E01 Extends TopicInfo

referencealias Property RiftenHouse Auto
referencealias Property HjaalmarchHouse Auto
referencealias Property Hjaalmarch Auto
referencealias Property SolitudeHouse Auto
referencealias Property MarkarthHouse Auto
referencealias Property WhiterunHouse Auto
referencealias Property WindhelmHouse Auto

Function Fragment_0(ObjectReference akSpeakerRef) Native
String Function GetState() Native
Function GotoState(String newState) Native
