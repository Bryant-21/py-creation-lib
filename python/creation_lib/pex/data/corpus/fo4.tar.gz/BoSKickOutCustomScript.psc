Scriptname BoSKickOutCustomScript Extends ReferenceAlias

quest Property BoSKickOut Auto

Event OnDying(actor akKiller)
EndEvent
