Scriptname CityCYRedTape01PlayerScript Extends ReferenceAlias

miscobject Property InorgCommonIron Auto

Function OnItemAdded(form akBaseItem, Int aiItemCount, objectreference akItemReference, objectreference akSourceContainer, Int aiTransferReason) Native
Function OnItemRemoved(form akBaseItem, Int aiItemCount, objectreference akItemReference, objectreference akDestContainer, Int aiTransferReason) Native
Function RegisterPlayerForResourceTracking(Bool bRegister) Native
Function RunCheckResources() Native
