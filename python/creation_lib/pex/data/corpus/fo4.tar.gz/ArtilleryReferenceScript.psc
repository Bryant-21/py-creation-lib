Scriptname ArtilleryReferenceScript Extends ObjectReference

weapon Property WorkshopArtilleryWeapon Auto
idle Property ArtilleryStop Auto
idle Property ArtilleryTurnCounterClockwise Auto
activator Property WorkshopArtilleryStrikeProjectileShooterFar Auto
sound Property WPNArtilleryMinutemenFire Auto
activator Property WorkshopArtilleryStrikeProjectileShooterClose Auto
explosion Property WorkshopArtilleryForce Auto
idle Property ArtilleryTurnClockwise Auto
explosion Property MinArtilleryMuzzleFlash Auto
idle Property ArtilleryFire Auto
activator Property WorkshopArtilleryFakeProjectile Auto
sound Property FXProjectileArtilleryMinutemen Auto
form Property XmarkerHeading Auto

Function FireAtTarget(ObjectReference TargetToFireAt, Bool turnToTargetOnly = false) Native
Function FireMortar(Bool fakeFire = false) Native
Bool Function GetTurnDirection(Int P, Int N) Native
Event OnAnimationEvent(ObjectReference akSource, String asEventName)
EndEvent

Function PlaceMortarExplosion() Native
Function PlaceTargetMarker() Native
Function PlayAnimOrIdle(idle myIdle, String myAnim) Native
Function Test(Bool justAim) Native
Function TurnToTarget(ObjectReference TargetToFireAt, Bool doNotFire = false) Native
