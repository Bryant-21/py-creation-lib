Scriptname ccOTMFO4001:ccOTMFO4001_EnclaveHQQuestCounter Extends defaultcounterquest

Int Property InactiveUntilStage Auto

Function Decrement() Native
Function Increment() Native
