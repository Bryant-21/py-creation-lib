Scriptname DefaultAliasDisableHavokOnLoad Extends ReferenceAlias

keyword Property LinkHavokPartner Auto
Bool Property HavokOnHit Auto
Bool Property HavokOnActivate Auto
Bool Property BeenSimmed Auto
Bool Property HavokOnZKey Auto

Event onActivate(objectreference triggerRef)
EndEvent

Event onGrab()
EndEvent

Event onHit(objectreference akTarget, objectreference var1, form var2, projectile var3, Bool var4, Bool var5, Bool var6, Bool var7, String asMaterialName)
EndEvent

Event onLoad()
EndEvent

Event onUnload()
EndEvent

Function ReleaseToHavok() Native
