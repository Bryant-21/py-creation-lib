Scriptname DefaultAliasOnOpen Extends DefaultAlias

Event OnOpen(objectreference akActionRef)
EndEvent
