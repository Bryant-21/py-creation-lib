Scriptname AspirationalAddItemScript02 Extends ObjectReference

objectmod Property pModExtraCost Auto
objectmod Property pModLegendary Auto
objectmod Property pMod03 Auto
objectmod Property pMod05 Auto
objectmod Property pMod01 Auto
objectmod Property pMod04 Auto
objectmod Property pMod02 Auto
objectmod Property pMod06 Auto
leveleditem Property pBaseAspirationalItem Auto
ObjectReference Property pOtherContainer Auto

Event OnLoad()
EndEvent

Function PossiblyAddMod(ObjectReference oItem, objectmod oMod) Native
