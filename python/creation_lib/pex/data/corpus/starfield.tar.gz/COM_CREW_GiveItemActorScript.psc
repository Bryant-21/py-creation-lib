Scriptname COM_CREW_GiveItemActorScript Extends Actor

leveleditem Property GiveItemList Auto
conditionform Property COM_CREW_CND_GiveItemAvailable Auto
keyword Property COM_CREW_GiveItemReminder Auto
actorvalue Property COM_CREW_GiveItemAvailableDay Auto
globalvariable Property COM_CREW_GiveItemAvailableCooldownDays Auto
sq_com_crew_giveitemquestscript Property SQ_Crew Auto
actorvalue Property COM_CREW_GiveItem_HasItems Auto

Function GiveItems() Native
Function OnLocationChange(location akOldLoc, location akNewLoc) Native
Function OnTimerGameTime(Int aiTimerID) Native
Bool Function Trace(ScriptObject CallingObject, String asTextToPrint, Int aiSeverity, String MainLogName, String SubLogName, Bool bShowNormalTrace, Bool bShowWarning, Bool bPrefixTraceWithLogNames) Native
Bool Function warning(ScriptObject CallingObject, String asTextToPrint, Int aiSeverity, String MainLogName, String SubLogName, Bool bShowNormalTrace, Bool bShowWarning, Bool bPrefixTraceWithLogNames) Native
