Scriptname DebugPlayerSummonShipScript Extends Actor

objectreference Property Frontier_ModularREF Auto
sq_playershipscript Property SQ_PlayerShip Auto
furniture Property ShipLandingMarker Auto
keyword Property SpaceshipEnabledLandingLink Auto

Function DebugSummonShip() Native
Function OnHomeShipSet(spaceshipreference akShip, spaceshipreference akPrevious) Native
Function OnPlayerArrested(objectreference akGuard, location akLocation, Int aeCrimeType) Native
Function OnPlayerAssaultActor(objectreference akVictim, location akLocation, Bool aeCrime) Native
Function OnPlayerCompleteResearch(objectreference akBench, location akLocation, researchproject akProject) Native
Function OnPlayerCrimeGold(objectreference akVictim, form akFaction, Int aeCrimeGold, Int aeCrimeType) Native
Function OnPlayerJail(objectreference akGuard, form akFaction, location akLocation, Int aeCrimeGold) Native
Function OnPlayerPayFine(objectreference akGuard, form akFaction, Int aeCrimeGold) Native
Function OnPlayerPlanetSurveyComplete(planet akPlanet) Native
Function OnPlayerScannedObject(objectreference akScannedRef) Native
Function OnPlayerTrespass(objectreference akVictim, location akLocation, Bool aeCrime) Native
Function testGetDayLength() Native
