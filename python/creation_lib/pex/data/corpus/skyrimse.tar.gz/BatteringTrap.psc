Scriptname BatteringTrap Extends MovingTrap

Float Property initialDelay Auto
Bool Property resetEventRecieved Auto

Function fireTrap() Native
String Function GetState() Native
Function GotoState(String newState) Native
Function OnAnimationEvent(objectreference akSource, String asEventName) Native
Function onLoad() Native
Function resetLimiter() Native
