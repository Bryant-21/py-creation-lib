Scriptname ActorValue Extends Form

resource Function GetResource() Native
