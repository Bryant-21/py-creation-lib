Scriptname CyclicElectricalHazard Extends objectReference

form Property xmarker Auto Const
Float Property TargetDistance Auto Const
Float Property firingTime Auto Const
Float Property firingPauseTime Auto Const
Bool Property StartsOn Auto
Float Property OffsetTimer Auto Const
spell Property TrapElectricArcSpell Auto Const
Float Property BlindFireRange Auto Const

Function FireElectricity() Native
Event OnActivate(objectReference akActionRef)
EndEvent

Event OnCellAttach()
EndEvent

Event OnCellDetach()
EndEvent

Event OnInit()
EndEvent

Event OnLoad()
EndEvent

Event onTimer(Int aiTimerID)
EndEvent

Function TurnOn(Bool ShouldBeOn = true) Native
