Scriptname CreationClub:VRWorkshops:VRWorkshopNPCScript Extends Actor

effectshader Property TeleportInFXS Auto Const
sound Property TeleportSound Auto Const
effectshader Property TeleportOutFXS Auto Const

Event OnDeath(Actor akKiller)
EndEvent

Event OnInit()
EndEvent

Event OnLoad()
EndEvent
