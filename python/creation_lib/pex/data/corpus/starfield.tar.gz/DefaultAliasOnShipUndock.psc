Scriptname DefaultAliasOnShipUndock Extends DefaultAlias

Bool Property SetStageWhenUndockingComplete Auto
Int Property WhichShipToCheck Auto

Function OnShipUndock(Bool abComplete, spaceshipreference akUndocking, spaceshipreference akParent) Native
