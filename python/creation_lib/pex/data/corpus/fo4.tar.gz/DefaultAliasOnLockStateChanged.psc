Scriptname DefaultAliasOnLockStateChanged Extends DefaultAlias

Bool Property CheckForUnlock Auto Const

Event OnLockStateChanged()
EndEvent
