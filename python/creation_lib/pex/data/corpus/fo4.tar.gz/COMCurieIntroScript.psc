Scriptname COMCurieIntroScript Extends ObjectReference

quest Property pMS19 Auto Const
quest Property pCOMCurie Auto Const

Event OnTriggerEnter(ObjectReference akActionRef)
EndEvent
