Scriptname DansePostQuestBoSHostilityScript Extends Actor

message Property DanseBosHostilityMessageOn Auto Const
faction Property CurrentCompanionFaction Auto Const
message Property DanseBosHostilityMessageOff Auto Const
faction Property BrotherhoodofSteelFaction Auto Const

Function MakeBoSHostile() Native
Event OnLoad()
EndEvent

Event OnTimerGameTime(Int aiTimerID)
EndEvent

Function Process(Bool showMessage = false) Native
