Scriptname AtronachForgeSCRIPT Extends objectReference

Bool Property sigilStoneInstalled Auto
formlist Property RecipeList Auto
objectReference Property DropBox Auto
formlist Property SigilResultList Auto
objectReference Property lastSummonedObject Auto
formlist Property SigilRecipeList Auto
objectReference Property createPoint Auto
objectReference Property summonFXpoint Auto
formlist Property ResultList Auto
activator Property summonFX Auto

String Function GetState() Native
Function GotoState(String newState) Native
Function onActivate(objectReference actronaut) Native
Function removeIngredients(formlist recipe) Native
Bool Function ScanForRecipes(formlist Recipes, formlist Results) Native
Bool Function scanSubList(formlist recipe) Native
