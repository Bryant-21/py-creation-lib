Scriptname CF05_LayerScript Extends Quest

inputenablelayer Property CF05_Layer Auto
