Scriptname AbTGTrapsightScript Extends ActiveMagicEffect

globalvariable Property pTSight Auto

String Function GetState() Native
Function GotoState(String newState) Native
Function OnEffectStart(Actor Target, Actor Caster) Native
