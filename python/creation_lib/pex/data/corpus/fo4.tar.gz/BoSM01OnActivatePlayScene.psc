Scriptname BoSM01OnActivatePlayScene Extends ObjectReference

scene Property BoSM01_Player_BattleSitePowerArmorComments Auto

Event OnActivate(ObjectReference akActivator)
EndEvent

Event OnLoad()
EndEvent
