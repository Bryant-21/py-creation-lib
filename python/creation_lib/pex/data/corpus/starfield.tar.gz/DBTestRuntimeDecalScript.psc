Scriptname DBTestRuntimeDecalScript Extends ObjectReference

textureset Property DecalPuddleMd01 Auto

Function OnLoad() Native
Function PlaceTestDecal() Native
