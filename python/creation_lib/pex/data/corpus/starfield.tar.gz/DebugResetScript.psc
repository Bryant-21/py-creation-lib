Scriptname DebugResetScript Extends ObjectReference

Function OnCellLoad() Native
Function OnReset() Native
