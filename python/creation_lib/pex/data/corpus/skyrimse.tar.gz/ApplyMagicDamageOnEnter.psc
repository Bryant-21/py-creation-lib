Scriptname ApplyMagicDamageOnEnter Extends ObjectReference

spell Property DamageToApply Auto

String Function GetState() Native
Function GotoState(String newState) Native
Function onTriggerEnter(ObjectReference actronaut) Native
