Scriptname CA_DB_Event14 Extends ca_dialoguebump_basescript

Function InitializeEventID() Native
