Scriptname ArenaScript Extends Quest

globalvariable Property Arena_FightOver Auto
globalvariable Property Arena_FightOn Auto
referencealias Property AnnouncerHeadtrackMarker4 Auto
keyword Property WeaponTypeMelee1H Auto
referencealias Property StageController Auto
scene Property Arena_Announcement_Pre Auto
Bool Property IsPlayerInRing Auto
referencealias Property AnnouncerHeadtrackMarker2 Auto
scene Property Arena_Announcement_StartFight Auto
referencealias Property AnnouncerHeadtrackMarker5 Auto
referencealias Property CombatantSpawn Auto
referencealias Property PlayerEntranceTrigger Auto
referencealias Property Combatant1 Auto
globalvariable Property CZMaxRank Auto
globalvariable Property CZPlayerFoughtCait Auto
referencealias Property AnnouncerHeadtrackMarker1 Auto
actorvalue Property Health Auto
idle Property IdleFightWinner Auto
referencealias Property AnnounceMarker Auto
referencealias Property AnnouncerHeadtrackMarker3 Auto
referencealias Property Combatant2 Auto
actorbase[] Property Combatants Auto
globalvariable Property Arena_FightWaiting Auto
spell Property Arena_PacifyCombatant Auto
referencealias Property CageDoor Auto
keyword Property WeaponTypeMelee2H Auto
referencealias Property Corner1 Auto
referencealias Property Corner2 Auto
miscobject Property Caps001 Auto
faction Property Arena_Rank_Faction Auto
faction Property Arena_Fight_Faction Auto
referencealias Property WagerContainer Auto
scene Property Arena_Announcement_Post Auto
referencealias Property Ringmaster Auto

Function AnnounceFight() Native
Function CollectEarnings() Native
Function CollectPrize() Native
Function CombatantDown(referencealias DownedAlias) Native
actorbase Function GetCombatantActorBase(Int Rank = 0) Native
Event OnTimer(Int aiTimerID)
EndEvent

Int Function OpenWagerContainerAndGetAmount() Native
Function PlaceWager(Int Combatant) Native
Function PlayerFailedToEnterRing() Native
Function PlayerInEntranceTrigger() Native
Function PlayTriumphantIdle(actor ActorToTryToPlayIdle) Native
Function PrizeWon(actor WinningActor) Native
Function ResetEarningsAndWagerObjectives() Native
Function SetCombatantAliases(Int Rank = 0, actor Combatant1Ref = None, actor Combatant2Ref = None) Native
Function SetPlaceWagerObjective(Bool IsAcceptingWagers) Native
Function SetUpMatch(actor RingmasterActor, objectreference AnnounceMarkerRef, objectreference StageControllerRef, objectreference CageDoorRef, objectreference Corner1Ref, objectreference Corner2Ref, objectreference PlayerEntranceTriggerRef, objectreference SpawnMarker = None, Int Rank = 0, actor Combatant1Ref = None, actor Combatant2Ref = None, objectreference AnnouncerHeadtrackMarker1Ref = none, objectreference AnnouncerHeadtrackMarker2Ref = none, objectreference AnnouncerHeadtrackMarker3Ref = none) Native
Function SpotlightCombatant1(Bool turnOnLight) Native
Function SpotlightCombatant2(Bool turnOnLight) Native
Function StartFight() Native
Function StopFight() Native
Function ToggleRegistrationForRemoteEvents(Bool ShouldWatchForEvents) Native
Function WagerLost() Native
Function WagerWon() Native
