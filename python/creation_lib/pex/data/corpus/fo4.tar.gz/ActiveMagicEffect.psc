Scriptname ActiveMagicEffect Extends ScriptObject

Function Dispel() Native
magiceffect Function GetBaseObject() Native
actor Function GetCasterActor() Native
actor Function GetTargetActor() Native
Event OnActivate(objectreference akActionRef)
EndEvent

Event OnCellAttach()
EndEvent

Event OnCellDetach()
EndEvent

Event OnCellLoad()
EndEvent

Event OnClose(objectreference akActionRef)
EndEvent

Event OnCombatStateChanged(actor akTarget, Int aeCombatState)
EndEvent

Event OnCommandModeCompleteCommand(Int aeCommandType, objectreference akTarget)
EndEvent

Event OnCommandModeEnter()
EndEvent

Event OnCommandModeExit()
EndEvent

Event OnCommandModeGiveCommand(Int aeCommandType, objectreference akTarget)
EndEvent

Event OnCompanionDismiss()
EndEvent

Event OnConsciousnessStateChanged(Bool abUnconscious)
EndEvent

Event OnContainerChanged(objectreference akNewContainer, objectreference akOldContainer)
EndEvent

Event OnCripple(actorvalue akActorValue, Bool abCrippled)
EndEvent

Event OnDeath(actor akKiller)
EndEvent

Event OnDeferredKill(actor akKiller)
EndEvent

Event OnDestructionStageChanged(Int aiOldStage, Int aiCurrentStage)
EndEvent

Event OnDifficultyChanged(Int aOldDifficulty, Int aNewDifficulty)
EndEvent

Event OnDying(actor akKiller)
EndEvent

Event OnEffectFinish(actor akTarget, actor akCaster)
EndEvent

Event OnEffectStart(actor akTarget, actor akCaster)
EndEvent

Event OnEnterBleedout()
EndEvent

Event OnEnterSneaking()
EndEvent

Event OnEquipped(actor akActor)
EndEvent

Event OnEscortWaitStart()
EndEvent

Event OnEscortWaitStop()
EndEvent

Event OnExitFurniture(objectreference akActionRef)
EndEvent

Event OnGetUp(objectreference akFurniture)
EndEvent

Event OnGrab()
EndEvent

Event OnHolotapeChatter(String astrChatter, Float afNumericData)
EndEvent

Event OnHolotapePlay(objectreference aTerminalRef)
EndEvent

Event OnItemAdded(form akBaseItem, Int aiItemCount, objectreference akItemReference, objectreference akSourceContainer)
EndEvent

Event OnItemEquipped(form akBaseObject, objectreference akReference)
EndEvent

Event OnItemRemoved(form akBaseItem, Int aiItemCount, objectreference akItemReference, objectreference akDestContainer)
EndEvent

Event OnItemUnequipped(form akBaseObject, objectreference akReference)
EndEvent

Event OnKill(actor akVictim)
EndEvent

Event OnLoad()
EndEvent

Event OnLocationChange(location akOldLoc, location akNewLoc)
EndEvent

Event OnLockStateChanged()
EndEvent

Event OnOpen(objectreference akActionRef)
EndEvent

Event OnPackageChange(package akOldPackage)
EndEvent

Event OnPackageEnd(package akOldPackage)
EndEvent

Event OnPackageStart(package akNewPackage)
EndEvent

Event OnPartialCripple(actorvalue akActorValue, Bool abCrippled)
EndEvent

Event OnPickpocketFailed()
EndEvent

Event OnPipboyRadioDetection(Bool abDetected)
EndEvent

Event OnPlayerCreateRobot(actor akNewRobot)
EndEvent

Event OnPlayerDialogueTarget()
EndEvent

Event OnPlayerEnterVertibird(objectreference akVertibird)
EndEvent

Event OnPlayerFallLongDistance(Float afDamage)
EndEvent

Event OnPlayerFireWeapon(form akBaseObject)
EndEvent

Event OnPlayerHealTeammate(actor akTeammate)
EndEvent

Event OnPlayerLoadGame()
EndEvent

Event OnPlayerModArmorWeapon(form akBaseObject, objectmod akModBaseObject)
EndEvent

Event OnPlayerModRobot(actor akRobot, objectmod akModBaseObject)
EndEvent

Event OnPlayerSwimming()
EndEvent

Event OnPlayerUseWorkBench(objectreference akWorkBench)
EndEvent

Event OnPowerOff()
EndEvent

Event OnPowerOn(objectreference akPowerGenerator)
EndEvent

Event OnRaceSwitchComplete()
EndEvent

Event OnRead()
EndEvent

Event OnRelease()
EndEvent

Event OnReset()
EndEvent

Event OnSell(actor akSeller)
EndEvent

Event OnSit(objectreference akFurniture)
EndEvent

Event OnSpeechChallengeAvailable(objectreference akSpeaker)
EndEvent

Event OnSpellCast(form akSpell)
EndEvent

Event OnTranslationAlmostComplete()
EndEvent

Event OnTranslationComplete()
EndEvent

Event OnTranslationFailed()
EndEvent

Event OnTrapHitStart(objectreference akTarget, Float afXVel, Float afYVel, Float afZVel, Float afXPos, Float afYPos, Float afZPos, Int aeMaterial, Bool abInitialHit, Int aeMotionType)
EndEvent

Event OnTrapHitStop(objectreference akTarget)
EndEvent

Event OnTriggerEnter(objectreference akActionRef)
EndEvent

Event OnTriggerLeave(objectreference akActionRef)
EndEvent

Event OnUnequipped(actor akActor)
EndEvent

Event OnUnload()
EndEvent

Event OnWorkshopMode(Bool aStart)
EndEvent

Event OnWorkshopNPCTransfer(location akNewWorkshop, keyword akActionKW)
EndEvent

Event OnWorkshopObjectDestroyed(objectreference akReference)
EndEvent

Event OnWorkshopObjectGrabbed(objectreference akReference)
EndEvent

Event OnWorkshopObjectMoved(objectreference akReference)
EndEvent

Event OnWorkshopObjectPlaced(objectreference akReference)
EndEvent

Event OnWorkshopObjectRepaired(objectreference akReference)
EndEvent

Function StartObjectProfiling() Native
Function StopObjectProfiling() Native
