Scriptname DefaultAliasOnClose Extends DefaultAlias

Function OnClose(objectreference akActionRef) Native
