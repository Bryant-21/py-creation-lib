Scriptname DisableLinkedRefOnDestroyed Extends ObjectReference

keyword Property LinkEnable Auto

Function OnDestroyed(ObjectReference akDestroyer) Native
