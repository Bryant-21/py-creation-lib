Scriptname BoS304KickTriggerScript Extends ObjectReference

referencealias Property Alias_PaladinDanse Auto Const
faction Property CurrentCompanionFaction Auto Const

Event OnTriggerEnter(ObjectReference akActionRef)
EndEvent

Event OnTriggerLeave(ObjectReference akActionRef)
EndEvent
