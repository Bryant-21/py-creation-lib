Scriptname AffinitySceneHandlerScript Extends Quest

globalvariable Property CA_T3_Neutral Auto
globalvariable Property CA_TCustom2_Friend Auto
globalvariable Property CA_TCustom1_Confidant Auto
globalvariable Property CA_T1_Infatuation Auto
globalvariable Property CA_T5_Hatred Auto
referencealias Property CompanionAlias Auto
globalvariable Property CA_T2_Admiration Auto
globalvariable Property CA_T4_Disdain Auto

Function EndSceneAdmiration() Native
Function EndSceneConfidant() Native
Function EndSceneDisdain() Native
Function EndSceneFriend() Native
Function EndSceneHatred() Native
Function EndSceneInfatuation() Native
Function EndSceneNeutral() Native
Function UnlockedInfatuation() Native
