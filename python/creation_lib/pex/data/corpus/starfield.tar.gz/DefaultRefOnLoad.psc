Scriptname DefaultRefOnLoad Extends DefaultRefParent

Event OnLoad()
EndEvent
