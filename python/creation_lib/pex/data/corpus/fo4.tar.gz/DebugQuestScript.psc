Scriptname DebugQuestScript Extends Quest

Event OnQuestInit()
EndEvent

Event OnReset()
EndEvent

Event OnStageSet(Int auiStageID, Int auiItemID)
EndEvent
