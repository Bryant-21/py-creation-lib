Scriptname DefaultActor Extends Actor

Bool Property ShowTraces Auto Const
Int Property StageToSet Auto Const
Int Property TurnOffStage Auto Const
quest Property MyQuest Auto Const
Int Property PrereqStage Auto Const

Function TryToSetStage(Bool PlayerCheckOverride = FALSE, objectreference RefToCheck = NONE, form FormToCheck = NONE, objectreference[] ReferenceArray = NONE, referencealias[] AliasArray = NONE, faction[] FactionArray = NONE, form[] FormArray = NONE, location[] LocationArray = NONE, locationalias[] LocationAliasArray = NONE) Native
