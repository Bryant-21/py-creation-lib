Scriptname DialogueFCNeonAdvertScript Extends ReferenceAlias

scene[] Property AdvertScenes Auto
location Property CityNeonLocation Auto

Function OnLocationChange(location akOldLoc, location akNewLoc) Native
Function UpdateScenes(Bool bStart) Native
