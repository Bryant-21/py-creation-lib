Scriptname CF02_LayerScript Extends Quest

inputenablelayer Property CF02_Layer Auto
