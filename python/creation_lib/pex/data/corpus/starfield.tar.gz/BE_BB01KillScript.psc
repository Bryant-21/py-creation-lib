Scriptname BE_BB01KillScript Extends ReferenceAlias

Function OnLoad() Native
