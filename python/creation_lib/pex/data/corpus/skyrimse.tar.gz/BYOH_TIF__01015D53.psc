Scriptname BYOH_TIF__01015D53 Extends TopicInfo

quest Property pDialogueFollower Auto
faction Property DismissedFollowerFaction Auto

Function Fragment_0(ObjectReference akSpeakerRef) Native
String Function GetState() Native
Function GotoState(String newState) Native
