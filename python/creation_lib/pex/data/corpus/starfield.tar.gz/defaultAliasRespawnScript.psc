Scriptname defaultAliasRespawnScript Extends ReferenceAlias

Bool Property RespawningOn Auto

Event OnDeath(objectreference akKiller)
EndEvent

Function RespawnIfDead() Native
