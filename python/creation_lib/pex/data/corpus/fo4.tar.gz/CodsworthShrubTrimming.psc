Scriptname CodsworthShrubTrimming Extends ObjectReference

ObjectReference Property Codsworth1ref Auto
actor Property bushTrimmer Auto

Event OnAnimationEvent(ObjectReference akSource, String asEventName)
EndEvent

Event OnLoad()
EndEvent

Event OnTriggerEnter(ObjectReference akActionRef)
EndEvent

Event OnTriggerLeave(ObjectReference akActionRef)
EndEvent

Event OnUnload()
EndEvent
