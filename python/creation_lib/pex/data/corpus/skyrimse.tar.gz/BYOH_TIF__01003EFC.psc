Scriptname BYOH_TIF__01003EFC Extends TopicInfo

referencealias Property FalkreathHouse Auto

Function Fragment_0(ObjectReference akSpeakerRef) Native
String Function GetState() Native
Function GotoState(String newState) Native
