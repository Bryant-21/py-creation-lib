Scriptname ccBGSFO4115_:RadioEnclaveQuestScript Extends Quest

Int Property CurrentSong Auto
Int Property LastSongPlayed02 Auto
Int Property LastSongPlayed06 Auto
Int Property LastSongPlayed01 Auto
Int Property LastSongPlayed03 Auto
Int Property LastSongPlayed05 Auto
Int Property LastSongPlayed04 Auto
Int Property LastSongPlayed07 Auto
Int Property LastSongPlayed08 Auto

Function UpdateRadio(Int aNewCurrentSong) Native
