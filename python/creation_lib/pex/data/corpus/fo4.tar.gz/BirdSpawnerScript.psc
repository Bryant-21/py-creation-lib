Scriptname BirdSpawnerScript Extends ObjectReference

activator Property BirdBase Auto
Int Property InteriorFleeRadius Auto
Bool Property InteriorFlee Auto

Event OnAnimationEvent(ObjectReference akSource, String asEventName)
EndEvent

Event OnCellLoad()
EndEvent

Event OnDistanceGreaterThan(ObjectReference akObj1, ObjectReference akObj2, Float afDistance)
EndEvent

Event OnDistanceLessThan(ObjectReference akObj1, ObjectReference akObj2, Float afDistance)
EndEvent

Event OnTriggerEnter(ObjectReference akActionRef)
EndEvent

Event OnTriggerLeave(ObjectReference akActionRef)
EndEvent

Event OnUnload()
EndEvent

ObjectReference Function spawnBird(String akPerchName, ObjectReference akMyStartingPerch) Native
