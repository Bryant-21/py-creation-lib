Scriptname COM_CommitmentGiftScript Extends ObjectReference

globalvariable Property CommitmentGiftEnabled Auto
quest Property SQ_Companions Auto

Function OnContainerChanged(ObjectReference akNewContainer, ObjectReference akOldContainer) Native
Bool Function Trace(ScriptObject CallingObject, String asTextToPrint, Int aiSeverity, String MainLogName, String SubLogName, Bool bShowNormalTrace, Bool bShowWarning, Bool bPrefixTraceWithLogNames) Native
Bool Function warning(ScriptObject CallingObject, String asTextToPrint, Int aiSeverity, String MainLogName, String SubLogName, Bool bShowNormalTrace, Bool bShowWarning, Bool bPrefixTraceWithLogNames) Native
