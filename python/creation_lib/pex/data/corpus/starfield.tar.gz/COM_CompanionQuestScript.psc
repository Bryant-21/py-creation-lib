Scriptname COM_CompanionQuestScript Extends Quest

Struct StoryGateDatum
    Int GateNumber
    globalvariable TimerDuration
EndStruct

actorvalue Property COM_IsCommitted Auto
actorvalue Property COM_CurrentStoryGateTimerExpired Auto
Int Property FlirtChoiceMax Auto
actorvalue Property COM_FlirtChoice Auto
actorvalue Property COM_FlirtCooldownExpiry Auto
actorvalue Property COM_FlirtCount Auto
globalvariable Property COM_FlirtCooldownDays Auto
globalvariable[] Property PrioritizedAngerReasons Auto
Int Property WantsToTalkObjective Auto
conditionform Property WantsToTalkConditionForm Auto
scene Property WantsToTalkAnnouncementScene Auto
actorvalue Property COM_CommitmentRefusedPermanently Auto
perk Property CompanionCheckPerk Auto
Quest Property CommitmentQuest Auto
Quest Property PersonalQuest Auto
actorvalue Property COM_StarbornSaveActorValue_MaxStoryGate Auto
storygatedatum[] Property StoryGateData Auto
locationalias Property Alias_PlayerShipInteriorLocation Auto
referencealias Property Alias_PlayerShipCrewMarker Auto
referencealias Property Alias_Companion Auto
affinityevent Property COM_Event_PlayerBecomesRomantic_AndrejaJealous Auto
actorbase Property Companion_Andreja Auto
actorvalue Property COM_CommitmentDesired Auto
actorvalue Property COM_CommitmentPossible Auto
actorvalue Property COM_HasBeenRomantic Auto
actorvalue Property COM_IsRomantic Auto
globalvariable Property COM_AffinityLevel_3_Commitment Auto
actorvalue Property COM_AngerCoolDownTimerExpired Auto
globalvariable Property COM_AffinityLevel_2_Affection Auto
globalvariable Property COM_AffinityLevel_1_Friendship Auto
actorvalue Property COM_AngerSecondChances Auto
actorvalue Property COM_AngerSceneCompleted Auto
sq_companionsscript Property SQ_Companions Auto
actorvalue Property COM_StoryGatesCompleted Auto
sq_followersscript Property SQ_Followers Auto
actorvalue Property COM_PersonalQuest_Started Auto
actorvalue Property COM_PersonalQuest_Finished Auto
actorvalue Property COM_CommitmentQuest_Started Auto

Function _AngerSceneCancelAnger() Native
Function AngerSceneCompleted() Native
Function AngerSpeechChallengeSuccess() Native
Function AwardSecondChance() Native
Function BreakCommitment() Native
Function CheckAndSetWantsToTalk(Bool SayDialogue) Native
Function CheckAngerAndSetNotAngry() Native
Function CommitmentDesired(Bool Desired) Native
Function DebugSetStoryGateTimerComplete() Native
Function DismissedAsCompanion() Native
Function DismissSceneEnded() Native
Function ExpireAngerCoolDownTimer() Native
Function FinishedPersonalQuest() Native
Function FlirtSceneEnded() Native
Function FollowSceneEnded() Native
storygatedatum Function GetStoryGateDatum(Int GateNumber) Native
Function GiveItemSceneEnded() Native
Function MakeCommitted() Native
Function MakeNotAngry() Native
Function MakeNotCommitted(Bool Permanent) Native
Function MakeNotRomantic() Native
Function MakeRomantic() Native
Bool Function OnPlayerShip(actor ActorToCheck, location LocationToCheck) Native
Function OnQuestInit() Native
Function OnTimer(Int aiTimerID) Native
Function OnTimerGameTime(Int aiTimerID) Native
Function PersonalQuestReminder() Native
Function PickedUpAsCompanion() Native
Function PickupSceneEnded() Native
Function PossiblyMakeAndrejaJealous() Native
Function ReedemSecondChance() Native
Function RomanceSceneEndedRomantic() Native
Function SetAffinityLevel(globalvariable AffinityLevel) Native
Function SetAngerLevel(globalvariable AngerLevelToSet, globalvariable AngerReason) Native
Function StartAngerCoolDownTimer() Native
Function StartCommitmentQuest() Native
Function StartPersonalQuest() Native
Function StartStoryGateTimer(Int nextGateNumber) Native
Function StoryGateSceneCompleted(Bool IncrementAV) Native
Function TalkAboutQuestEventSceneEnded(actorvalue AssociatedActorValue) Native
Bool Function Trace(ScriptObject CallingObject, String asTextToPrint, Int aiSeverity, String MainLogName, String SubLogName, Bool bShowNormalTrace, Bool bShowWarning, Bool bPrefixTraceWithLogNames) Native
Function WaitSceneEnded() Native
Bool Function warning(ScriptObject CallingObject, String asTextToPrint, Int aiSeverity, String MainLogName, String SubLogName, Bool bShowNormalTrace, Bool bShowWarning, Bool bPrefixTraceWithLogNames) Native
