Scriptname DLC03:SFBGS003MiscInevitableAliasScript Extends ReferenceAlias

Float Property DistanceToPlayerLessThan Auto
Float Property DistanceToPlayerGreaterThan Auto

Function OnAliasInit() Native
Function OnDistanceGreaterThan(objectreference akObj1, objectreference akObj2, Float afDistance, Int aiEventID) Native
Function OnDistanceLessThan(objectreference akObj1, objectreference akObj2, Float afDistance, Int aiEventID) Native
