Scriptname DefaultTopicInfoSetGlobal Extends TopicInfo

Float Property OnEndValue Auto
globalvariable Property SetGlobalOnBegin Auto
Float Property OnBeginValue Auto
globalvariable Property SetGlobalOnEnd Auto

Event OnBegin(objectreference akSpeakerRef, Bool abHasBeenSaid)
EndEvent

Event OnEnd(objectreference akSpeakerRef, Bool abHasBeenSaid)
EndEvent
