Scriptname BoSKickOutLiCustomScript Extends ReferenceAlias

quest Property BoSKickOut Auto Const
globalvariable Property BoSLiSlain Auto Const
quest Property BoS301 Auto Const

Event OnDying(actor akKiller)
EndEvent
