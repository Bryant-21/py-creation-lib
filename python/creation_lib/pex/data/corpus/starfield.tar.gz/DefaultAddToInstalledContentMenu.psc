Scriptname DefaultAddToInstalledContentMenu Extends Quest

message Property TheMessage Auto
formlist Property HelpManualInstalledContent Auto

Function OnInit() Native
