Scriptname CommonTeam Extends ScriptObject

Function ChangeAggression(objectreference oTeam, Int bAggression = 2) Global Native
Function ChangeFaction(objectreference oTeam, faction facNew, Bool bAdd = TRUE) Global Native
Bool Function IsDead(objectreference oTeam) Global Native
Function Merge(objectreference oChild, objectreference oParent) Global Native
