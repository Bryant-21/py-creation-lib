Scriptname CrewEliteOtherPlayerScript Extends Actor

referencealias Property MQ00_OtherPlayer Auto
voicetype Property NPCXOtherPlayer_2 Auto
voicetype Property NPCXOtherPlayer Auto
message Property PlayerNameMSG Auto
voicetype Property NPCMOtherPlayer Auto
voicetype Property NPCFOtherPlayer Auto

Function OnLoad() Native
Function OnUnload() Native
