Scriptname BYOH_TIF__0100696B Extends TopicInfo

miscobject Property Gold001 Auto
miscobject Property Lumber Auto

Function Fragment_0(ObjectReference akSpeakerRef) Native
String Function GetState() Native
Function GotoState(String newState) Native
