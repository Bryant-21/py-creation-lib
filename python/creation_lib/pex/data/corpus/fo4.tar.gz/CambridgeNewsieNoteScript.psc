Scriptname CambridgeNewsieNoteScript Extends ObjectReference

ObjectReference Property DiamondCityMapMarkerRef Auto

Event onRead()
EndEvent
