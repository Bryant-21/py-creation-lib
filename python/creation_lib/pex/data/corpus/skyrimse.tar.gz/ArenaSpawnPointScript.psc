Scriptname ArenaSpawnPointScript Extends ReferenceAlias

String Function GetState() Native
Function GotoState(String newState) Native
Function OnInit() Native
