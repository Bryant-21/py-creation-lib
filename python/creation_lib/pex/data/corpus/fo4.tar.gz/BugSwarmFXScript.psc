Scriptname BugSwarmFXScript Extends ObjectReference

Float Property mySpeed Auto
Int Property chaseTime Auto
Bool Property goHomeWhenDone Auto
Bool Property CleanMyselfUp Auto

Function goHome() Native
Event OnBeginState(String asOldState)
EndEvent

Event OnInit()
EndEvent

Event OnTimer(Int aiTimerID)
EndEvent

Event OnTriggerEnter(ObjectReference akActionRef)
EndEvent

Event OnUnload()
EndEvent

Function ResetHomeCoords() Native
Function startFollowing() Native
