Scriptname AskedForMoreCaps Extends TopicInfo

Event OnEnd(objectreference akSpeakerRef, Bool abHasBeenSaid)
EndEvent
