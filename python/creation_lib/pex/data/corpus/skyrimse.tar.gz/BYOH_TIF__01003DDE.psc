Scriptname BYOH_TIF__01003DDE Extends TopicInfo

Int Property GoldAmount Auto
miscobject Property Gold Auto
objectreference Property DecorateMarker Auto
globalvariable Property HDSolitudeBedroom Auto

Function Fragment_0(objectreference akSpeakerRef) Native
String Function GetState() Native
Function GotoState(String newState) Native
