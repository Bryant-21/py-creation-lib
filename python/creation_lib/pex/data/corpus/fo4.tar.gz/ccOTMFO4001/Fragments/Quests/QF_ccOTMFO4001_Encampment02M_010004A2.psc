Scriptname ccOTMFO4001:Fragments:Quests:QF_ccOTMFO4001_Encampment02M_010004A2 Extends Quest

globalvariable Property ccOTMFO4001_Encampment02Active Auto Const
referencealias Property Alias_MapMarker Auto Const

Function Fragment_Stage_0000_Item_00() Native
Function Fragment_Stage_0005_Item_00() Native
Function Fragment_Stage_0010_Item_00() Native
Function Fragment_Stage_0015_Item_00() Native
Function Fragment_Stage_0020_Item_00() Native
Function Fragment_Stage_0025_Item_00() Native
Function Fragment_Stage_0030_Item_00() Native
Function Fragment_Stage_0035_Item_00() Native
Function Fragment_Stage_0040_Item_00() Native
Function Fragment_Stage_1000_Item_00() Native
