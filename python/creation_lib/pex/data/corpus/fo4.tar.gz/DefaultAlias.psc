Scriptname DefaultAlias Extends ReferenceAlias

Bool Property ShowTraces Auto Const
Int Property TurnOffStage Auto Const
Int Property StageToSet Auto Const
Int Property PrereqStage Auto Const
Bool Property TurnOffWhenDead Auto Const

Function TryToSetStage(Bool PlayerCheckOverride = FALSE, objectreference RefToCheck = NONE, form FormToCheck = NONE, objectreference[] ReferenceArray = NONE, referencealias[] AliasArray = NONE, faction[] FactionArray = NONE, form[] FormArray = NONE, location[] LocationArray = NONE, locationalias[] LocationAliasArray = NONE, Bool LocationMatchIfChild = false) Native
