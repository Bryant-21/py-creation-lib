Scriptname ccFSVFO4007:Fragments:Quests:QF_ccFSVFO4007_RadioQuest_01000285 Extends Quest

Quest Property ccFSVFO4007_Quest Auto

Function Fragment_Stage_0020_Item_00() Native
Function Fragment_Stage_0100_Item_00() Native
