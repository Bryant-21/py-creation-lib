Scriptname DefaultRefOnEnterBleedout Extends DefaultActorParent

Event OnEnterBleedout()
EndEvent
