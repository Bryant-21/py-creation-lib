Scriptname DefaultMusicActivateScript Extends ObjectReference

musictype[] Property MusicShort Auto
musictype[] Property Music Auto
Int Property MusicTypeToPlay Auto
musictype Property MusicOverride Auto
Bool Property PlayShortVersion Auto

Event OnActivate(ObjectReference akActionRef)
EndEvent
