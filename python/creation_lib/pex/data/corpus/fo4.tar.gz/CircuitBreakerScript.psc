Scriptname CircuitBreakerScript Extends ObjectReference

keyword Property LinkCustom01 Auto Const
Bool Property LockToOnPosition Auto
Bool Property OnPosition Auto
Bool Property DenyOnPosition Auto
keyword Property LinkCustom03 Auto Const
keyword Property LinkCustom02 Auto Const

Event OnActivate(ObjectReference akActionRef)
EndEvent

Event OnLoad()
EndEvent
