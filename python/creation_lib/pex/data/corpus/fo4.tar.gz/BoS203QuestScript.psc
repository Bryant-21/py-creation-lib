Scriptname BoS203QuestScript Extends Quest

mq00script Property MQ00 Auto
Quest Property BoS203 Auto
referencealias Property BoS203LiAlias Auto

Function BoS203FindLi() Native
Function InitializeQuest() Native
Event OnDistanceLessThan(objectreference akObj1, objectreference akObj2, Float afDistance)
EndEvent
