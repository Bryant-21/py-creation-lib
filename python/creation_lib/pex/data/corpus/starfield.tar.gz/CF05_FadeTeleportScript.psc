Scriptname CF05_FadeTeleportScript Extends TopicInfo

Float Property WaitTime Auto
Float Property FadeDuration Auto
Float Property SecondsBeforeFade Auto
referencealias Property Alias_PlayerTeleportGuard Auto

Function OnEnd(objectreference akSpeakerRef, Bool abHasBeenSaid) Native
