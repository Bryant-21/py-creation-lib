Scriptname CompanionPowerArmorKeywordScript Extends Actor

keyword Property pAttachPassenger Auto
keyword Property isPowerArmorFrame Auto
keyword Property pAttachSlot2 Auto

Event OnItemEquipped(form akBaseObject, objectreference akReference)
EndEvent

Event OnItemUnequipped(form akBaseObject, objectreference akReference)
EndEvent
