Scriptname CFSD01_PlayerAliasScript Extends ReferenceAlias

location Property LC082VigilanceLocation Auto
quest Property CFSD01 Auto

Function OnLocationChange(location akOldLoc, location akNewLoc) Native
