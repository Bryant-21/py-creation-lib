Scriptname BFBPuzzle01Pillar Extends ObjectReference

Int Property solveState Auto
Int Property initialState Auto

String Function GetState() Native
Function GotoState(String newState) Native
Function onActivate(ObjectReference triggerRef) Native
Function OnLoad() Native
Function RotatePillarToState(Int stateNumber, Int animEventNumber) Native
