Scriptname BoSR03Script Extends Quest

Int Property StageToSet Auto
alias Property BoSR03Squire Auto
location Property PrydwenLocation Auto
locationalias Property Dungeon Auto
