Scriptname BladeTrap Extends MovingTrap

Float Property initialDelay Auto

Function fireTrap() Native
String Function GetState() Native
Function GotoState(String newState) Native
Function resetLimiter() Native
