Scriptname BYOH_PF_BYOHAdoptionOR_Orders_01003F38 Extends Package

globalvariable Property GameHour Auto

Function Fragment_0(Actor akActor) Native
String Function GetState() Native
Function GotoState(String newState) Native
