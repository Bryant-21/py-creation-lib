Scriptname BladesBlessingEffectScript Extends ActiveMagicEffect

Float Property fTimer Auto
globalvariable Property GameDaysPassed Auto
spell Property BladesBlessingAbility Auto
globalvariable Property BladesBlessingTimer Auto

String Function GetState() Native
Function GotoState(String newState) Native
Function OnEffectStart(actor akTarget, actor akCaster) Native
Function OnUpdateGameTime() Native
