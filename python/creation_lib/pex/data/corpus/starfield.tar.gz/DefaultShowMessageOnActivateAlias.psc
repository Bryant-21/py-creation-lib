Scriptname DefaultShowMessageOnActivateAlias Extends ReferenceAlias

Bool Property ShowTraces Auto
Bool Property ShowIfStageIsSet Auto
Int Property MessageStage Auto
Int Property Button3StageToSet Auto
Int Property Button2StageToSet Auto
Int Property Button1StageToSet Auto
Int Property Button0StageToSet Auto
message Property MessageToShow Auto

Event OnActivate(objectreference akActionRef)
EndEvent
