Scriptname CA_DialogueBump_BaseScript Extends TopicInfo

Int Property eventID Auto

Function InitializeEventID() Native
Event OnEnd(objectreference akSpeakerRef, Bool abHasBeenSaid)
EndEvent
