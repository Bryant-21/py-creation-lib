Scriptname DefaultRefOnDeath Extends DefaultActorParent

Bool Property UseOnDyingInstead Auto
Bool Property LocationMatchIfChild Auto
locationalias[] Property LocationAliasesToCheckAgainst Auto
location[] Property LocationsToCheckAgainst Auto
faction[] Property FactionsToCheckAgainst Auto
referencealias[] Property AliasesToCheckAgainst Auto
objectreference[] Property ReferencesToCheckAgainst Auto
Bool Property PlayerOnly Auto

Function DeathComplete(objectreference akKiller) Native
referencealias[] Function GetAliasesToCheckAgainst() Native
faction[] Function GetFactionsToCheckAgainst() Native
locationalias[] Function GetLocationAliasesToCheckAgainst() Native
Bool Function GetLocationMatchIfChild() Native
location[] Function GetLocationsToCheckAgainst() Native
Bool Function GetPlayerOnly() Native
objectreference[] Function GetReferencesToCheckAgainst() Native
Event OnDeath(objectreference akKiller)
EndEvent

Event OnDying(objectreference akKiller)
EndEvent
