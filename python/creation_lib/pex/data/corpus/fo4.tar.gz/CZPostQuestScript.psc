Scriptname CZPostQuestScript Extends Quest

Quest Property myQuest Auto
location Property CombatZoneLocation Auto

Event OnTimerGameTime(Int aiTimerID)
EndEvent

Function SetPostQuestTimer() Native
