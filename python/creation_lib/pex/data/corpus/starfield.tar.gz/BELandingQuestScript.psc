Scriptname BELandingQuestScript Extends Quest

keyword Property BESurfaceCrewSize_50Percent Auto
keyword Property BEDropship Auto
actorvalue Property SpaceshipCrew Auto
referencealias Property Ship Auto
keyword Property SpaceshipPreventRampOpenOnLanding Auto
keyword Property BESurfaceCrewSize_75Percent Auto
actorvalue Property SpaceshipLandedValue Auto
keyword Property BEEncounterTypeSurface Auto
keyword Property BESurfaceCrewSize_NoCrew Auto
keyword Property BESurfaceCrewSize_25Percent Auto

Function OnQuestStarted() Native
Function OnTimer(Int timerID) Native
Function PATCH_RecheckLanding() Native
Function StartSurfaceEncounter() Native
