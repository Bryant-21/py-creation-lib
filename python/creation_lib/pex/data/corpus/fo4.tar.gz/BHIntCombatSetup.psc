Scriptname BHIntCombatSetup Extends ObjectReference

globalvariable Property BHIntCombatDoonce Auto
keyword Property LinkCustom03 Auto
faction Property PlayerFaction Auto
keyword Property LinkCustom02 Auto
faction Property BunkerHillRRFaction Auto
faction Property BunkerHillBoSFaction Auto
keyword Property LinkCustom01 Auto
faction Property BunkerHillInstituteFaction Auto

Function LoadBattle() Native
Event OnTriggerEnter(ObjectReference akActionRef)
EndEvent
