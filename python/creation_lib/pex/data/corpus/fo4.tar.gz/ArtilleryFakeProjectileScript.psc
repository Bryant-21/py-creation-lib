Scriptname ArtilleryFakeProjectileScript Extends ObjectReference

weapon Property WorkShopArtilleryWeapon Auto Const
sound Property FXExplosionArtilleryMinutemen Auto Const

Event onLoad()
EndEvent
