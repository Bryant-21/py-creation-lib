Scriptname DefaultRefOnCellLoad Extends DefaultRefParent

Event OnCellLoad()
EndEvent
