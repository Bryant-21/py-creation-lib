Scriptname CA_DB_Event21 Extends ca_dialoguebump_basescript

Function InitializeEventID() Native
