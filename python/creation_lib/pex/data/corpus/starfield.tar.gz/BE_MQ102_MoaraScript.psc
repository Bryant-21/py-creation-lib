Scriptname BE_MQ102_MoaraScript Extends ReferenceAlias

Function OnAliasInit() Native
