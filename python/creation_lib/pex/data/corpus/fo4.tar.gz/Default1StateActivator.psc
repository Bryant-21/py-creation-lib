Scriptname Default1StateActivator Extends ObjectReference

String Property Anim Auto

Event OnActivate(ObjectReference akActionRef)
EndEvent
