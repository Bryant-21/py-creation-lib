Scriptname BladeOfWoeScript Extends ReferenceAlias

quest Property DB10 Auto

String Function GetState() Native
Function GotoState(String newState) Native
Function OnContainerChanged(ObjectReference akNewContainer, ObjectReference akOldContainer) Native
