Scriptname AbCourserSpeedScript Extends ActiveMagicEffect

spell Property CourserPowerUp Auto Const
Bool Property PoweredUp Auto
Float Property HealthThreshhold Auto Const
actorvalue Property Health Auto Const

Event OnEffectFinish(actor akTarget, actor akCaster)
EndEvent

Event OnEffectStart(actor akTarget, actor akCaster)
EndEvent

Event OnHit(objectreference akTarget, objectreference akAggressor, form akSource, projectile akProjectile, Bool abPowerAttack, Bool abSneakAttack, Bool abBashAttack, Bool abHitBlocked, String apMaterial)
EndEvent
