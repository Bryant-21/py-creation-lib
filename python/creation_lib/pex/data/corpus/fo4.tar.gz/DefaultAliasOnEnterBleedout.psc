Scriptname DefaultAliasOnEnterBleedout Extends DefaultAlias

Event OnEnterBleedout()
EndEvent
