Scriptname CA_DB_Event01 Extends CA_DialogueBump_BaseScript

Function InitializeEventID() Native
