Scriptname BoSPrimeButtonScript Extends ObjectReference

quest Property BoS304 Auto Const
sound Property mySound Auto Const
quest Property BoS301 Auto Const

Event OnActivate(ObjectReference akActionRef)
EndEvent
