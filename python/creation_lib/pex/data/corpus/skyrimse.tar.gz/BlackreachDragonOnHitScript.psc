Scriptname BlackreachDragonOnHitScript Extends ReferenceAlias

String Function GetState() Native
Function GotoState(String newState) Native
Function OnHit(ObjectReference akAggressor, Form akSource, Projectile akProjectile, Bool abPowerAttack, Bool abSneakAttack, Bool abBashAttack, Bool abHitBlocked) Native
