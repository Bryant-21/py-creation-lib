Scriptname City_Neon_Drug03MiscScript Extends Quest

globalvariable Property Neon_Drug03_CooldownTimestamp Auto
Int Property ShiftObjective Auto

Function ClearShiftTimer() Native
Function OnTimerGameTime(Int aiTimerID) Native
Function StartShiftTimer() Native
