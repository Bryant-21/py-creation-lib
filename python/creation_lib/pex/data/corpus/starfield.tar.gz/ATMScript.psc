Scriptname ATMScript Extends ObjectReference

keyword Property ATMLink_Door Auto
keyword Property ATMLink_Container Auto

Function OnActivate(ObjectReference akActionRef) Native
Function OnBeginState(String asOldState) Native
Function OnInit() Native
Function SetupLockedState() Native
Function StealFromATM() Native
