Scriptname BYOH_TIF__01003E57 Extends TopicInfo

referencealias Property SolitudeHouse Auto
referencealias Property WhiterunHouse Auto

Function Fragment_0(ObjectReference akSpeakerRef) Native
String Function GetState() Native
Function GotoState(String newState) Native
