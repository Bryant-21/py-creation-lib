Scriptname City_GG_Mark_QuestScript Extends Quest

referencealias Property Bonifac Auto
referencealias Property Maldonado Auto

Function StopCombatOnNPCs() Native
