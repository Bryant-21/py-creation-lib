Scriptname DefaultAddItemToLeveledList Extends Quest

Struct LeveledItemDatum
    Int ItemAmount
    Int ItemLevel
    form ItemToAdd
EndStruct

leveleditemdatum[] Property LeveledItemData Auto
leveleditem[] Property LeveledList Auto
Bool Property AddOnQuestStart Auto

Function AddItemsToLeveledList() Native
Function OnQuestInit() Native
