Scriptname CityCYRedTape03QuestScript Extends Quest

Int Property PlayerInJailTriggerStage Auto
referencealias Property JailTrigger Auto
referencealias Property JailDoor Auto
Int Property JailCellDoorClosedStage Auto

Function CloseJailCell() Native
Function OnTimer(Int aiTimerID) Native
