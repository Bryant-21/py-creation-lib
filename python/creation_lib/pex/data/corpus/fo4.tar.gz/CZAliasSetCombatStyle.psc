Scriptname CZAliasSetCombatStyle Extends ReferenceAlias

Int Property QuestStageToSetCombatStyle Auto
Int Property QuestStageToClearCombatStyle Auto
combatstyle Property CombatstyleToSet Auto

Event OnInit()
EndEvent
