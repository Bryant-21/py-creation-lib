Scriptname CF05_LocationChangeScript Extends ReferenceAlias

locationalias Property CF05_Location_PrototypeInterior Auto
quest Property CF05 Auto
Int Property StageToCheck Auto
ReferenceAlias Property CF05_PrototypeShip Auto

Function OnLocationChange(location akOldLoc, location akNewLoc) Native
