Scriptname DefaultCounterIncrementOnDeath Extends Actor

keyword Property LinkedRefKeyword Auto
Bool Property CheckForOnDyingInstead Auto

Event OnDeath(objectreference akKiller)
EndEvent

Event OnDying(objectreference akKiller)
EndEvent
