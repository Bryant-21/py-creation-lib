Scriptname BYOH_TIF__01003F0A Extends TopicInfo

referencealias Property SolitudeHouse Auto
referencealias Property MarkarthHouse Auto
referencealias Property WhiterunHouse Auto
referencealias Property RiftenHouse Auto
referencealias Property PaleHouse Auto
referencealias Property WindhelmHouse Auto

Function Fragment_0(ObjectReference akSpeakerRef) Native
String Function GetState() Native
Function GotoState(String newState) Native
