Scriptname BYOH_TIF__0100088A Extends TopicInfo

favordialoguescript Property DialogueFavorGeneric Auto

Function Fragment_0(ObjectReference akSpeakerRef) Native
String Function GetState() Native
Function GotoState(String newState) Native
