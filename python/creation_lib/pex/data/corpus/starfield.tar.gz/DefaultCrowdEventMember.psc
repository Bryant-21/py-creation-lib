Scriptname DefaultCrowdEventMember Extends Actor

Struct EventDatum
    keyword EventKeyword
    Bool RequireToFaceEitherEventRef
    Float CoolDown
    Float MaxResponseDelay
    Float MinResponseDelay
    Int EventChanceToRespond
    keyword EventTopicSubType
EndStruct

defaultcrowdeventmanager[] Property CrowdEventManagers Auto
Int Property DisableOnStage Auto
quest Property ControllingQuest Auto
eventdatum[] Property EventData Auto

Event OnLoad()
EndEvent
