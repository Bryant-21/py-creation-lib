Scriptname AssaultronShockHandScript Extends ActiveMagicEffect

String Property myPlaceAtNode Auto Const
explosion Property PElectricalExplosionSmall Auto Const
sound Property NPCRobotHandShockLPM Auto Const
actorvalue Property myLimbAV Auto Const
visualeffect Property PRobotShockHandVE Auto Const

Event OnAnimationEvent(objectreference akSource, String asEventName)
EndEvent

Event OnConsciousnessStateChanged(Bool abUnconscious)
EndEvent

Event OnCripple(actorvalue akActorValue, Bool abCrippled)
EndEvent

Event OnDying(actor akKiller)
EndEvent

Event OnEffectFinish(actor akTarget, actor akCaster)
EndEvent

Event OnEffectStart(actor akTarget, actor akCaster)
EndEvent
