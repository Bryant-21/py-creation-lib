Scriptname ccBGSFO4116:SpigotLoadGameScript Extends ReferenceAlias

cell Property SaugusIronworks01 Auto Const
ccbgsfo4116:smeltersoundscript Property ObjectReferenceScript Auto Const

Function OnPlayerLoadGame() Native
