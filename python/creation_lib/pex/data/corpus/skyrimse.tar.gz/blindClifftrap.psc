Scriptname blindClifftrap Extends objectReference

objectReference Property myLink Auto
weapon Property myWeapon Auto

String Function GetState() Native
Function GotoState(String newState) Native
Function OnInit() Native
Function onTrigger(objectReference triggerRef) Native
