Scriptname BoS303WarningScript Extends ReferenceAlias

message Property BoS303WarningMessage Auto Const
globalvariable Property PlayerInstitute_KickedOut Auto Const
globalvariable Property BoS303BoardGo Auto Const
globalvariable Property BoS303IngramGoing Auto Const
quest Property BoS303 Auto Const
ReferenceAlias Property BoS303Ingram Auto Const

Function LaunchVertibird() Native
Event OnActivate(objectreference akActionRef)
EndEvent
