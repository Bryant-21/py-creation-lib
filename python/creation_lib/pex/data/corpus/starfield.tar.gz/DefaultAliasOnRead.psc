Scriptname DefaultAliasOnRead Extends DefaultAliasParent

Event OnRead()
EndEvent
