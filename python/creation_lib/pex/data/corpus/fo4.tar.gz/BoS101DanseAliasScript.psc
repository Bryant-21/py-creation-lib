Scriptname BoS101DanseAliasScript Extends ReferenceAlias

armor Property Armor_Power_T60_Helm Auto Const
leveleditem Property LL_Armor_Power_T60_Set_BOSPaladin_HelmetOnly Auto Const

Event OnAliasInit()
EndEvent

Event OnAnimationEvent(objectreference akSource, String asEventName)
EndEvent
