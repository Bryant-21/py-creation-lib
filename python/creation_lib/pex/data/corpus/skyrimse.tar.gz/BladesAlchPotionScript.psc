Scriptname BladesAlchPotionScript Extends ActiveMagicEffect

perk Property MQBladesDragonResearch Auto

String Function GetState() Native
Function GotoState(String newState) Native
Function OnEffectStart(Actor akTarget, Actor akCaster) Native
