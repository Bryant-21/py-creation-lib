Scriptname CorpseDismemberScript Extends ReferenceAlias

quest Property pQuest Auto Const
Int Property iStageToSet Auto Const
ReferenceAlias Property pCorpse Auto Const

Event OnLoad()
EndEvent
