Scriptname BobbleheadSPECIALscrip Extends ObjectReference

quest Property PerksQuest Auto Const
Int Property stage Auto Const

Event OnActivate(ObjectReference akActionRef)
EndEvent
