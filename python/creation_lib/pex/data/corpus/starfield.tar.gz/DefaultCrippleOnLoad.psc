Scriptname DefaultCrippleOnLoad Extends ObjectReference

Bool Property RightArm Auto
Bool Property LeftArm Auto
Bool Property RightLeg Auto
Bool Property LeftLeg Auto
actorvalue Property RightAttackCondition Auto
actorvalue Property LeftAttackCondition Auto
actorvalue Property LeftMobilityCondition Auto
actorvalue Property RightMobilityCondition Auto

Event OnLoad()
EndEvent
