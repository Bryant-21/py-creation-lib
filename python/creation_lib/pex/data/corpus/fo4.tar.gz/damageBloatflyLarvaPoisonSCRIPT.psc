Scriptname damageBloatflyLarvaPoisonSCRIPT Extends ActiveMagicEffect

objectreference Property bloatfly Auto
explosion Property flyExplosion Auto

Event OnDying(actor akKiller)
EndEvent

Event OnEffectStart(actor akTarget, actor akCaster)
EndEvent
