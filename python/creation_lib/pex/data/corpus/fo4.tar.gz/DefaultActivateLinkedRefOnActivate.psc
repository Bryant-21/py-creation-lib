Scriptname DefaultActivateLinkedRefOnActivate Extends ObjectReference

Bool Property ShowTraces Auto Const
objectreference[] Property ActivatedByReferences Auto Const
faction[] Property ActivatedByFactions Auto Const
referencealias[] Property ActivatedByAliases Auto Const
keyword Property LinkedRefKeyword Auto Const
Bool Property DoOnce Auto Const
Bool Property PlayerActivatedOnly Auto Const

Event OnActivate(ObjectReference akActionRef)
EndEvent
