Scriptname CollapsingWallRefScript Extends ObjectReference

Bool Property HideActivationText Auto

Function OnActivate(ObjectReference akActionRef) Native
Function OnLoad() Native
