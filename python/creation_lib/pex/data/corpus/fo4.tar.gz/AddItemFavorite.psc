Scriptname AddItemFavorite Extends ObjectReference

globalvariable Property ItemHasFavorited Auto
Int Property FavoriteSlot Auto

Event OnContainerChanged(ObjectReference akNewContainer, ObjectReference akOldContainer)
EndEvent

Event OnInit()
EndEvent
