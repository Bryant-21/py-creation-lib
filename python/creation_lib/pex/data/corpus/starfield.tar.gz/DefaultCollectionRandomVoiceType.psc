Scriptname DefaultCollectionRandomVoiceType Extends RefCollectionAlias

formlist Property VoicesList Auto
Bool Property ShowTraces Auto

Function OnAliasInit() Native
