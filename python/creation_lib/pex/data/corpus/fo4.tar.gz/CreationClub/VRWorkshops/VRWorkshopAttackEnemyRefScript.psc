Scriptname CreationClub:VRWorkshops:VRWorkshopAttackEnemyRefScript Extends RefCollectionAlias

RefCollectionAlias Property AttackEnemiesRefCol Auto
Int Property ObjectiveComplete Auto
quest Property VRAttackQuest Auto
Int Property StageHostilesCleared Auto
sound Property TeleportSound Auto
effectshader Property HologramShaunFXS Auto
effectshader Property TeleportInFXS Auto
effectshader Property TeleportOutFXS Auto

Event OnDying(objectreference akSender, actor akKiller)
EndEvent

Event OnLoad(objectreference akSender)
EndEvent

Function RemoveEnemyFromRefCollection(objectreference enemyToRemove) Native
