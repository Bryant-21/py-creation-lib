Scriptname CFCredTankScript Extends ObjectReference

quest Property QuestToSetStageOn Auto
leveleditem Property LL_CFCredtankCredits Auto
key Property CF_GalbankTransferModule Auto
Int Property TurnOffStageDone Auto
Int Property TurnOffStage Auto
Int Property PrereqStage Auto
Int Property StageToSet Auto

Function OnActivate(ObjectReference akActivator) Native
Function OnCellLoad() Native
Function OnDistanceLessThan(ObjectReference akObj1, ObjectReference akObj2, Float afDistance, Int aiEventID) Native
Function OnTimer(Int timerID) Native
Function ResetCredTank() Native
