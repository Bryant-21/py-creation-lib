Scriptname BoSDPQuestScript Extends Quest

globalvariable Property BoSX111Threshold Auto
Int Property CoolantPayout Auto
miscobject Property BoSTechnicalDocument Auto Const
objectreference Property BoS301IngramWorkingMarker Auto Const
referencealias Property BoSQuinlan Auto Const
globalvariable Property BoSEndgateQuinlan Auto
globalvariable Property BoSCoolantPay Auto Const
referencealias Property BoSMaxon Auto Const
objectreference Property BoSMaxsonCommandDeckMarker Auto Const
globalvariable Property BoSEndgateLi Auto
Int Property DocumentCurrentCount Auto
Int Property BloodPayout Auto
Int Property DocPayout Auto
globalvariable Property BoSEndgateNeriah Auto
globalvariable Property BoSEndgateHaylen Auto
globalvariable Property BoSDocPay Auto Const
miscobject Property BoSBloodSample Auto Const
miscobject Property Caps001 Auto Const
miscobject Property BoSReactorCoolant Auto Const
globalvariable Property BoSEndgateRhys Auto
globalvariable Property BoSEndgateCade Auto
referencealias Property BoSIngram Auto Const
globalvariable Property BoSEndgateTeagan Auto
globalvariable Property BoSEndgateIngram Auto
Int Property BloodCurrentCount Auto
globalvariable Property BoSNeriahRadDone Auto
Quest Property MQ206BoS Auto Const
globalvariable Property BoSBloodPay Auto Const
referencealias Property BoSNeriah Auto Const
Int Property CoolantCurrentCount Auto

Function BoSEndgates() Native
Function BoSTeleMove() Native
Function CashBlood() Native
Function CashCoolant() Native
Function CashDocs() Native
