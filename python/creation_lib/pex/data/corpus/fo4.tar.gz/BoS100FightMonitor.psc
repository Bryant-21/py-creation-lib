Scriptname BoS100FightMonitor Extends Quest

referencealias Property Ghoul04 Auto
objectreference[] Property RespawnMarkersNear Auto
Int Property EndSecondWaveStageToSet Auto
referencealias Property Ghoul03 Auto
referencealias Property Rhys Auto
Int Property EndFightStageToSet Auto
actorvalue Property Health Auto
referencealias Property Danse Auto
actorvalue Property Aggression Auto
referencealias Property GhoulBoss Auto
referencealias Property Ghoul01 Auto
keyword Property BoS100FightGhoulKeyword Auto
actor[] Property AllGhouls Auto
refcollectionalias Property CollegeSquareExteriorGhouls Auto
Int Property EndSecondWaveDeathCount Auto
Int Property minRespawnDistance Auto
Float Property respawnTimeMin Auto
referencealias Property Ghoul02 Auto
Float Property respawnTimeMax Auto
objectreference Property RespawnMarkerFailsafe Auto
Int Property BossSpawnStageToSet Auto
Int Property BossSpawnDeathCount Auto
referencealias Property Haylen Auto
objectreference[] Property RespawnMarkersFar Auto

Function AddToAllGhouls(actor ghoul) Native
Function CleanupGhouls() Native
Function FinishRespawning(referencealias aliasToRespawn) Native
Function ForceKillGhouls() Native
Int Function GetCountOfLivingGhouls() Native
objectreference Function GetRespawnMarker(objectreference[] markers) Native
Function GhoulOnDeath(actor akSender, actor akKiller) Native
Event OnInit()
EndEvent

Event OnTimer(Int timer)
EndEvent

Function ReduceRespawnRadius() Native
Function RegisterGhoul(actor ghoul) Native
Function Respawn(referencealias aliasToRespawn) Native
Function SpawnBoss() Native
Function StartFightMonitor() Native
Function TryToRespawn(referencealias aliasToRespawn) Native
