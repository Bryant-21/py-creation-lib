Scriptname ArenaEntranceTriggerScript Extends ReferenceAlias

String Function GetState() Native
Function GotoState(String newState) Native
Function OnTriggerEnter(ObjectReference akActivator) Native
