Scriptname BuriedArtifact Extends ObjectReference

ObjectReference Property FXlights Auto
Bool Property PickupEnabled Auto
inputenablelayer Property ArtifactEnableLayer Auto
musictype Property VisionMusic Auto
visualeffect Property VisionEffects Auto
wwiseevent Property VisionAmbient Auto

Function ArtifactAcquired() Native
Function OnActivate(ObjectReference akActionRef) Native
