Scriptname bwcNightingaleGhostSCRIPT Extends ACTOR

container Property ghostCorpse Auto
effectshader Property pGhostDeathFXShader Auto
effectshader Property ghostEffect Auto
Float Property fDelayEnd Auto
formlist Property pDisintegrationMainImmunityList Auto
Float Property ghostAlpha Auto
Float Property ShaderDuration Auto
Float Property fDelay Auto
Bool Property bSetAlphaZero Auto
activator Property pDefaultAshPileGhost Auto

String Function GetState() Native
Function ghostFlash() Native
Function GotoState(String newState) Native
Function OnAnimationEvent(objectreference akSource, String EventName) Native
Function onDYING(ACTOR killer) Native
Function onHIT(objectreference akAggressor, FORM akSource, Projectile akProjectile, Bool abPowerAttack, Bool abSneakAttack, Bool abBashAttack, Bool abHitBlocked) Native
Function onLOAD() Native
