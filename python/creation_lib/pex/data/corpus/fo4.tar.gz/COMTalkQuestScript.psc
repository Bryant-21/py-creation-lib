Scriptname COMTalkQuestScript Extends Quest

companionactorscript Property CompanionActor Auto Const
globalvariable Property CA_T1_Infatuation Auto Const
globalvariable Property CA_T2_Admiration Auto Const
globalvariable Property CA_T5_Hatred Auto Const
globalvariable Property CA_T4_Disdain Auto Const
globalvariable Property CA_T3_Neutral Auto Const

Function ShowAdmirationMessage() Native
Function ShowDisdainMessage() Native
Function ShowHatredMessage() Native
Function ShowInfatuationMessage() Native
Function ShowNeutralMessage() Native
Function ShowRomanticInfatuationMessage() Native
