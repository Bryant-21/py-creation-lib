Scriptname COMHancockScript Extends Quest

Int Property InfatuationResponse Auto
