Scriptname DefaultActorParent Extends Actor

Int Property TurnOffStage Auto
Bool Property xxxPlaceHolderForEmptyGroup_LocationToCheckxxx Auto
Bool Property xxxPlaceHolderForEmptyGroup_RefToCheckxxx Auto
Bool Property SkipBusyState Auto
Bool Property ShowTraces Auto
conditionform Property ConditionFormToTest Auto
Bool Property FailOnDeadActor Auto
Bool Property DoOnce Auto
Int Property StageToSet Auto
Int Property PrereqStage Auto
Int Property TurnOffStageDone Auto
quest Property QuestToSetOrCheck Auto
Bool Property xxxPlaceHolderForEmptyGroupxxx Auto

Function CheckAndSetStageAndCallDoSpecificThing(defaultscriptfunctions:parentscriptfunctionparams ParentScriptFunctionParams) Native
Function DoSpecificThing(defaultscriptfunctions:parentscriptfunctionparams ParentScriptFunctionParams, objectreference RefToDoThingWith, Bool LastRefToDoThingWith) Native
referencealias[] Function GetAliasesToCheckAgainst() Native
faction[] Function GetFactionsToCheckAgainst() Native
locationalias[] Function GetLocationAliasesToCheckAgainst() Native
Bool Function GetLocationMatchIfChild() Native
location[] Function GetLocationsToCheckAgainst() Native
Bool Function GetPlayerOnly() Native
objectreference[] Function GetReferencesToCheckAgainst() Native
objectreference[] Function GetRefsToDoSpecificThingsWith() Native
Function OnInit() Native
Function RegisterOnHitFilters() Native
