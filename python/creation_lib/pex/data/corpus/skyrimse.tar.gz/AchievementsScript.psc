Scriptname AchievementsScript Extends Quest

Bool Property HardWorkerCookedFood Auto
Bool Property HardWorkerMinedOre Auto
Bool Property HardWorkerDone Auto
Bool Property HardWorkerChoppedWood Auto

String Function GetState() Native
Function GotoState(String newState) Native
Function IncDaedricArtifacts() Native
Function IncDaedricQuests() Native
Function IncHardWorker(Int AkObjectType) Native
Function IncSideQuests() Native
Function OnInit() Native
Event OnTrackedStatsEvent(String statFilter, Int statValue)
EndEvent
