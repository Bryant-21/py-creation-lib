Scriptname DefaultScriptFunctions Extends ScriptObject

Struct ParentScriptFunctionParams
    objectreference RefToCheck
    location LocationToCheckOther
    location LocationToCheck
EndStruct

parentscriptfunctionparams Function BuildParentScriptFunctionParams(objectreference RefToCheck, location LocationToCheck, location LocationToCheckOther) Global Native
Bool Function CheckForAliveActor(ScriptObject CallingObject, Bool ShowNormalTrace, objectreference CheckAliveActorOrShip, Bool FailOnDeadActor) Global Native
Bool Function CheckForConditionForm(ScriptObject CallingObject, Bool ShowNormalTrace, conditionform ConditionFormToTest) Global Native
Bool Function CheckForLocationMatches(ScriptObject CallingObject, Bool ShowNormalTrace, location LocationToCheck, location LocationToCheckOther, location[] LocationsToCheckAgainst, locationalias[] LocationAliasesToCheckAgainst, Bool LocationMatchIfChild) Global Native
Bool Function CheckForReferenceMatches(ScriptObject CallingObject, Bool ShowNormalTrace, objectreference RefToCheck, Bool PlayerOnly, objectreference[] ReferencesToCheckAgainst, referencealias[] AliasesToCheckAgainst, faction[] FactionsToCheckAgainst) Global Native
Bool Function CheckForStages(ScriptObject CallingObject, Bool ShowNormalTrace, quest QuestToSet, Int PrereqStage, Int TurnOffStage, Int TurnOffStageDone) Global Native
Bool Function IsDead(objectreference ActorOrSpaceshipToTest) Global Native
Bool Function IsValidToSetStage(ScriptObject CallingObject, Bool ShowNormalTrace, quest QuestToSet, Int StageToSet, Int PrereqStage, Int TurnOffStage, Int TurnOffStageDone, objectreference RefToCheck, Bool PlayerOnly, objectreference[] ReferencesToCheckAgainst, referencealias[] AliasesToCheckAgainst, faction[] FactionsToCheckAgainst, location LocationToCheck, location LocationToCheckOther, location[] LocationsToCheckAgainst, locationalias[] LocationAliasesToCheckAgainst, Bool LocationMatchIfChild, objectreference CheckAliveActorOrShip, Bool FailOnDeadActor, conditionform ConditionFormToTest) Global Native
Function SafeSetStage(ScriptObject CallingObject, Bool ShowNormalTrace, quest QuestToSet, Int StageToSet) Global Native
Function Trace(ScriptObject CallingObject, String TextToPrint, Bool ShowNormalTrace, String CustomLog) Global Native
Bool Function TryToSetStage(ScriptObject CallingObject, Bool ShowNormalTrace, quest QuestToSet, Int StageToSet, Int PrereqStage = FALSE, Int TurnOffStage = NONE, Int TurnOffStageDone = NONE, objectreference RefToCheck = NONE, Bool PlayerOnly = NONE, objectreference[] ReferencesToCheckAgainst = NONE, referencealias[] AliasesToCheckAgainst = NONE, faction[] FactionsToCheckAgainst = NONE, location LocationToCheck = NONE, location LocationToCheckOther = false, location[] LocationsToCheckAgainst, locationalias[] LocationAliasesToCheckAgainst, Bool LocationMatchIfChild, objectreference CheckAliveActorOrShip, Bool FailOnDeadActor, conditionform ConditionFormToTest) Global Native
Function warning(ScriptObject CallingObject, String TextToPrint, String CustomLog) Global Native
