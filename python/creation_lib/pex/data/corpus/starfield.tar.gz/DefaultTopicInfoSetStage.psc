Scriptname DefaultTopicInfoSetStage Extends DefaultTopicInfo

Bool Property SetStageOnEnd Auto

Event OnBegin(objectreference akSpeakerRef, Bool abHasBeenSaid)
EndEvent

Event OnEnd(objectreference akSpeakerRef, Bool abHasBeenSaid)
EndEvent
