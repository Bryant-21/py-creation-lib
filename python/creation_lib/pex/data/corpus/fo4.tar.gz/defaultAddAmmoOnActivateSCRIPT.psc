Scriptname defaultAddAmmoOnActivateSCRIPT Extends ObjectReference

Int Property ammoCount Auto
ammo Property ammoType Auto

Event OnActivate(ObjectReference akActionRef)
EndEvent
