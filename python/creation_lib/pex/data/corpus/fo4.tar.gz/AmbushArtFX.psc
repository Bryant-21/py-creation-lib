Scriptname AmbushArtFX Extends Actor

explosion Property FurnitureMirelurkSiltExplosion Auto
objectreference Property myWaterLevelMarker Auto
Float Property WaitToSplash Auto
effectshader Property myEffectShaderParticles Auto
keyword Property MirelurkAmbushWaterKeyword Auto
explosion Property myExplosion Auto
armor Property PSkinMirelurkDirtGravel Auto
effectshader Property mySplashShaderParticles Auto
explosion Property myWaterExplosion Auto

Event OnAnimationEvent(objectreference source, String eventName)
EndEvent

Event OnDying(Actor akKiller)
EndEvent

Event OnLoad()
EndEvent
