Scriptname DBPOI01PipeScript Extends ObjectReference

keyword Property LinkCustom01 Auto
message Property DBPOI01PipeMessage Auto

Event OnActivate(ObjectReference akActionRef)
EndEvent

Event OnLoad()
EndEvent
