Scriptname DefaultAliasOnShipLand Extends DefaultAliasParent

Bool Property SetStageWhenLandingComplete Auto
location[] Property LocationsToCheckAgainst Auto
sq_playershipscript Property SQ_PlayerShip Auto
Bool Property LocationMatchIfChild Auto
locationalias[] Property LocationAliasesToCheckAgainst Auto

locationalias[] Function GetLocationAliasesToCheckAgainst() Native
Bool Function GetLocationMatchIfChild() Native
location[] Function GetLocationsToCheckAgainst() Native
Function OnShipLanding(Bool abComplete) Native
