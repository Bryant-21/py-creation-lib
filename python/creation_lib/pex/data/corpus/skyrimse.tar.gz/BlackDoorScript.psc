Scriptname BlackDoorScript Extends ObjectReference

faction Property DarkBrotherhoodFaction Auto

String Function GetState() Native
Function GotoState(String newState) Native
Function OnActivate(ObjectReference AkActivator) Native
