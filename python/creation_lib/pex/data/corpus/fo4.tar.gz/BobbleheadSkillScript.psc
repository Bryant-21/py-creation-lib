Scriptname BobbleheadSkillScript Extends ObjectReference

perk Property PerkToAdd Auto Const

Event OnActivate(ObjectReference akActionRef)
EndEvent
