Scriptname COM_SamCoe_Q01_JaylenAliasScript Extends ReferenceAlias

Int Property FC04BlockingCompletionStage Auto
quest Property FC04 Auto
cell Property CityNeonFreestarRanger Auto
objectreference Property TeleportTarget Auto
Int Property AllowTeleport Auto
Int Property DisallowTeleport Auto

Function OnUnload() Native
