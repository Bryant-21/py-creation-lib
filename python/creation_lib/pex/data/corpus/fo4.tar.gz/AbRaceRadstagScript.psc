Scriptname AbRaceRadstagScript Extends ActiveMagicEffect

Float Property fAttackBelowHPpercent Auto
actorvalue Property Confidence Auto
actorvalue Property Health Auto
Int Property defaultConfidence Auto

Event OnCombatStateChanged(actor akTarget, Int aeCombatState)
EndEvent

Event OnEffectStart(actor akTarget, actor akCaster)
EndEvent

Event OnHit(objectreference akTarget, objectreference akAggressor, form akSource, projectile akProjectile, Bool abPowerAttack, Bool abSneakAttack, Bool abBashAttack, Bool abHitBlocked, String apMaterial)
EndEvent
