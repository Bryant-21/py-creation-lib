Scriptname ArmillaryScript Extends ObjectReference

Struct ArtifactStruct
    miscobject ArtifactMiscObject
    Bool IsArtifactAdded
    String ArtifactAnimation
EndStruct

quest Property MQ101 Auto
Int Property ArmillaryTogetherStage Auto
conditionform Property MQ104AArtifactCollectionActivateCheck Auto
referencealias Property Artifact02QuestObject Auto
referencealias Property Artifact01QuestObject Auto
refcollectionalias Property MQ00_ArtifactsHolder Auto
quest Property MQ305 Auto
artifactstruct[] Property ArtifactArray Auto
quest Property MQ00 Auto
globalvariable Property MQArmillaryCompleteGlobal Auto
location Property CityNewAtlantisLodgeLocation Auto

Function AssembleArmillary() Native
Function BuildArmillary(actor akActorREF, ObjectReference akMountOrScreen) Native
Function BuildCompleteArmillary() Native
Function CheckArmillaryComplete() Native
Function DebugSetArtifactAdded(Int iArtifactNumber) Native
Function MQ101ArmillaryComesTogether() Native
Function OnLoad() Native
Function PackupArmillary(actor akActorREF) Native
