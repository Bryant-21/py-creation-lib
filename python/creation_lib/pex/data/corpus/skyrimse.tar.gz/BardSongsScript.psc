Scriptname BardSongsScript Extends Quest

scene Property BardSongsInstrumentalDrum02 Auto
scene Property BardSongsDrinkingSong02Scene Auto
faction Property CurrentFollowerFaction Auto
location Property RiftHoldLocation Auto
location Property HaafingarHoldLocation Auto
scene Property BardSongsDrinkingSong03Scene Auto
Quest Property MQ306 Auto
location Property FalkreathHoldLocation Auto
scene Property BardSongsDrinkingSong02WithIntroScene Auto
location Property HjaalmarchHoldLocation Auto
package Property MorthalLurbukSleep1x5 Auto
actorbase Property TalsgarTheWanderer Auto
scene Property BardSongsInstrumentalFlute01 Auto
referencealias Property BardSongsInstrumental_Bard Auto
voicetype Property MaleYoungEager Auto
scene Property BardSongsDrinkingSong03WithIntroScene Auto
location Property EastmarchHoldLocation Auto
scene Property BardSongsInstrumentalFlute02 Auto
referencealias Property BardSongsInstrumental_Bard2 Auto
scene Property BardSongsInstrumentalLute02 Auto
voicetype Property FemaleYoungEager Auto
keyword Property LocTypeInn Auto
scene Property BardSongsBallad01WithIntroScene Auto
scene Property BardSongsInstrumentalFluteonly01 Auto
scene Property BardSongsInstrumentalDrum01 Auto
actor Property Sven Auto
location Property PaleHoldLocation Auto
location Property ReachHoldLocation Auto
referencealias Property BardSongs_Bard Auto
musictype Property MUSTavernSILENCE Auto
scene Property BardSongsInstrumentalLute01 Auto
Quest Property MQ106 Auto
location Property WinterholdHoldLocation Auto
location Property WhiterunHoldLocation Auto
scene Property BardSongsInstrumentalWedding01 Auto
scene Property BardSongsInstrumentalBard2Drum01 Auto
scene Property BardSongsDrinkingSong01Scene Auto
scene Property BardSongsBallad01Scene Auto
scene Property BardSongsInstrumentalBard2Drum02 Auto
scene Property BardSongsInstrumentalWedding02 Auto
Quest Property MQ203 Auto
actor Property Lurbuk Auto
keyword Property CWOwner Auto
scene Property BardSongsDrinkingSong01WithIntroScene Auto
referencealias Property BardSongs_Bard2 Auto
scene Property BardSongsInstrumentalFluteonly02 Auto

Function Bard2PlaySong(objectReference Bard, String Instrument, Bool PlayContinuous, Int SongToPlay, Bool ChangeSettings) Native
Int Function GetRandomSong(objectReference PassedBard) Native
String Function GetState() Native
Function GotoState(String newState) Native
Function OnUpdate() Native
Function PlayChosenSong(Int ChosenSong) Native
Function PlaySong(objectReference Bard, String Instrument, Bool PlayContinuous, Int SongToPlay, Bool ChangeSettings) Native
Function PlaySongRequest(objectReference Bard, String Instrument, Bool PlayContinuous, Int SongToPlay, Bool ChangeSettings) Native
Function RegisterLocationOwner(objectReference BardToCheck) Native
Function StopAllSongs() Native
Function StopInnMusic() Native
