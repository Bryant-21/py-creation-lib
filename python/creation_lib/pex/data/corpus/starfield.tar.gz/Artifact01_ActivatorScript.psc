Scriptname Artifact01_ActivatorScript Extends ObjectReference

Function OnHit(ObjectReference akTarget, ObjectReference akAggressor, form akSource, projectile akProjectile, Bool abPowerAttack, Bool abSneakAttack, Bool abBashAttack, Bool abHitBlocked, String apMaterial) Native
Function OnLoad() Native
