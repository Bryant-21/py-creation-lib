Scriptname ccBGSFO4116:TerminalScript Extends Terminal

objectreference Property Smelter02 Auto
objectreference Property Cart01 Auto
objectreference Property Smelter01 Auto
globalvariable Property ccBGSFO4116_SmelterToggle Auto
sound Property SmelterSound Auto
objectreference Property SoundMarker Auto
objectreference Property FireEffects Auto
Float Property Speed Auto
Int Property StagetoSet Auto
objectreference Property Cart02 Auto
quest Property MyQuest Auto
objectreference Property Smelter03 Auto
objectreference Property Cart03 Auto

Function OnMenuItemRun(Int auiMenuItemID, objectreference akTerminalRef) Native
