Scriptname DefaultAliasOnShipRefueled Extends DefaultAliasParent

Bool Property RequireFullyRefueled Auto
actorvalue Property SpaceshipGravJumpFuel Auto
location[] Property LocationsToCheckAgainst Auto
Bool Property LocationMatchIfChild Auto
locationalias[] Property LocationAliasesToCheckAgainst Auto

locationalias[] Function GetLocationAliasesToCheckAgainst() Native
Bool Function GetLocationMatchIfChild() Native
location[] Function GetLocationsToCheckAgainst() Native
Function OnShipRefueled(Int aFuelAdded) Native
Function RefuelSuccessful() Native
