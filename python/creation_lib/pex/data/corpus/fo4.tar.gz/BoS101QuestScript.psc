Scriptname BoS101QuestScript Extends Quest

leveleditem Property LL_Armor_Power_T60_Set_BOSPaladin_HelmetOnly Auto Const
referencealias Property BoS101Danse Auto Const
Quest Property BoS101 Auto Const

Event OnAnimationEvent(objectreference akSource, String asEventName)
EndEvent

Function RegisterMe() Native
