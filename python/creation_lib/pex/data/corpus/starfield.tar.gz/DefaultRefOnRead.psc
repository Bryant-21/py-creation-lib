Scriptname DefaultRefOnRead Extends DefaultRefParent

Event OnRead()
EndEvent
