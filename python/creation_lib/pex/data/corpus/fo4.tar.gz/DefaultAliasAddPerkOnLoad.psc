Scriptname DefaultAliasAddPerkOnLoad Extends ReferenceAlias

perk Property PerkToAdd Auto Const
Bool Property doOnce Auto Const

Event OnLoad()
EndEvent
