Scriptname DefaultAttachModToAlias Extends Quest

objectmod[] Property RewardMods Auto
referencealias Property RewardContainer Auto
referencealias Property RewardAlias Auto

Function AttachMods() Native
Function OnQuestInit() Native
