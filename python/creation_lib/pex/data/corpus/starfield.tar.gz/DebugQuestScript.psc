Scriptname DebugQuestScript Extends Quest

Event OnQuestInit()
EndEvent

Function OnQuestShutdown() Native
Function OnQuestStarted() Native
Event OnReset()
EndEvent

Event OnStageSet(Int auiStageID, Int auiItemID)
EndEvent
