Scriptname BYOH_TIF__0101410E Extends TopicInfo

Function Fragment_1(ObjectReference akSpeakerRef) Native
String Function GetState() Native
Function GotoState(String newState) Native
