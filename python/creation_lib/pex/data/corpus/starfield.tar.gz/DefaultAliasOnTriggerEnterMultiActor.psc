Scriptname DefaultAliasOnTriggerEnterMultiActor Extends DefaultAlias

referencealias[] Property TriggerAliases Auto
Bool Property AllTargetsInTrigger Auto
Bool Property DisableWhenTriggered Auto

Bool Function AreAllTargetsInTrigger() Native
Function CheckForTargetsInTrigger() Native
Function OnTriggerEnter(objectreference triggerRef) Native
Function OnTriggerLeave(objectreference triggerRef) Native
