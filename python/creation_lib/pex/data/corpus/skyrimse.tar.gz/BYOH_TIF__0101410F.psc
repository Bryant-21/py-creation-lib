Scriptname BYOH_TIF__0101410F Extends TopicInfo

Function Fragment_1(ObjectReference akSpeakerRef) Native
String Function GetState() Native
Function GotoState(String newState) Native
