Scriptname ccFSVFO4007:Fragments:Quests:QF_ccFSVFO4007_Quest_01000271 Extends Quest

objectreference Property ccFSVFO4007_GhoulsAttackREF02 Auto Const
objectreference Property ccFSVFO4007_Door01REF004 Auto Const
referencealias Property Alias_GasStuff Auto Const
referencealias Property Alias_Feral07 Auto Const
objectreference Property ccFSVFO4007_BathroomBoardREF Auto Const
explosion Property ExplosionTrapGas Auto Const
objectreference Property DoorClosetREF Auto Const
sound Property OBJPowerGeneratorTurbine01Off Auto Const
referencealias Property Alias_MainDoor Auto Const
globalvariable Property GlobalCrafting Auto Const
referencealias Property Alias_Feral01 Auto Const
referencealias Property Alias_ProtectronEnemy Auto Const
referencealias Property Alias_DoorBlocker Auto Const
sound Property SwitchSound Auto Const
Quest Property ccFSVFO4007_RadioQuest Auto Const
Float Property GhoulActivateTime Auto Const
referencealias Property Alias_GhoulTrigger Auto Const
referencealias Property Alias_SideDoor Auto Const
musictype Property pMUSStingerShort05x Auto Const

Function CheckObjectivesForCompletion() Native
Function Fragment_Stage_0010_Item_00() Native
Function Fragment_Stage_0020_Item_00() Native
Function Fragment_Stage_0030_Item_00() Native
Function Fragment_Stage_0040_Item_00() Native
Function Fragment_Stage_0045_Item_00() Native
Function Fragment_Stage_0050_Item_00() Native
Function Fragment_Stage_0054_Item_00() Native
Function Fragment_Stage_0055_Item_00() Native
Function Fragment_Stage_0060_Item_00() Native
Function Fragment_Stage_0070_Item_00() Native
Function Fragment_Stage_0080_Item_00() Native
Function Fragment_Stage_0090_Item_00() Native
Function Fragment_Stage_0100_Item_00() Native
Function Fragment_Stage_0200_Item_00() Native
