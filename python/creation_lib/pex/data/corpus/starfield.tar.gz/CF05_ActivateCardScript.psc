Scriptname CF05_ActivateCardScript Extends ReferenceAlias

scene Property BlockingScene Auto
Float Property DistanceCheck Auto
faction Property LC043SY01Faction Auto
ReferenceAlias Property Alias_Guard Auto
Int Property AlarmStage Auto
Int Property StageToCheck Auto

Function OnActivate(objectreference akActionRef) Native
Function OnAliasInit() Native
