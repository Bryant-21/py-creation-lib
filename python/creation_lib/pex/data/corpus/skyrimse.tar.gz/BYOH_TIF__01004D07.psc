Scriptname BYOH_TIF__01004D07 Extends TopicInfo

objectreference Property DecorateMarker Auto
miscobject Property Gold Auto
Int Property GoldAmount Auto
globalvariable Property HDRiftenChildRoom Auto

Function Fragment_0(objectreference akSpeakerRef) Native
String Function GetState() Native
Function GotoState(String newState) Native
