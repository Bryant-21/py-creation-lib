Scriptname City_Akila_Ashta02_Script Extends Quest

Int Property StageToSet Auto

Function OnTimerGameTime(Int aiTimerID) Native
Function Wait24() Native
