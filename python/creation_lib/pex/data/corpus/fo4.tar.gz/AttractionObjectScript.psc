Scriptname AttractionObjectScript Extends ObjectReference

Bool Property Busy Auto
Int Property DidMyThing Auto
Bool Property ShouldNonPlayerActorActivationDoMyThing Auto Const
Bool Property ShouldBlockActivationOnLoad Auto Const
Bool Property FaceMarker Auto Const
Bool Property ShouldNonActorActivationDoMyThing Auto Const
Bool Property ShouldPlayerActivationClearBusy Auto Const
Bool Property UnlockMe Auto Const
Bool Property DeleteAfterCleared Auto Const
Bool Property ShouldFadeOutOnDisable Auto Const
Bool Property ActivateMe Auto Const
String Property StringEventSend Auto Const
Bool Property ShouldFadeInOnEnable Auto Const
String Property StringEventRecieve Auto Const
Bool Property LockMe Auto Const
keyword Property CustomTopicKeyword Auto Const
keyword Property LinkLock Auto Const
Bool Property DisableMe Auto Const
keyword Property LinkSendRecieveEvent Auto Const
Bool Property EnableMeOnLoad Auto Const
Bool Property EnableMe Auto Const
keyword Property LinkEnable Auto Const
keyword Property LinkDisable Auto Const
Bool Property ShouldPlayerActivationDoMyThing Auto Const
Bool Property ShouldWaitToRecieveEvent Auto Const
keyword Property LinkUnlock Auto Const
Bool Property DeleteMe Auto Const
Bool Property FinishWalking Auto Const
Bool Property SayImmediately Auto Const
Bool Property ShouldOnlyDoMyThingOnce Auto Const
Bool Property ISendRecieveEvent Auto Const
keyword Property LinkActivate Auto Const

Int Function DoMyThing(actor myActor = None) Native
Event OnActivate(ObjectReference akActionRef)
EndEvent

Event OnLoad()
EndEvent

Function RegisterForDeletionEvent(defaultremoveablelight myOwner) Native
Int Function SayMyThing(actor myActor = None) Native
Function SetBusy(Bool IsBusy = true) Native
