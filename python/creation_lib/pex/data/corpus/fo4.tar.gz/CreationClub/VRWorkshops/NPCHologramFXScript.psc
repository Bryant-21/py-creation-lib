Scriptname CreationClub:VRWorkshops:NPCHologramFXScript Extends activemagiceffect

effectshader Property HologramShaunFXS Auto Const
sound Property TeleportSound Auto Const
effectshader Property TeleportOutFXS Auto Const
effectshader Property TeleportInFXS Auto Const

Event OnEffectStart(actor akTarget, actor akCaster)
EndEvent
