Scriptname ccFSVFO4007:PerkMagReadScript Extends ObjectReference

globalvariable Property ccFSVFO4007_CraftingUnlocked Auto

Function OnRead() Native
