Scriptname CA_DB_Event11 Extends ca_dialoguebump_basescript

Function InitializeEventID() Native
