Scriptname CuttableWallOnOpenScript Extends ReferenceAlias

keyword Property LinkCustom02 Auto
Int Property QuestTurnOffStage Auto
Int Property QuestPrereqStage Auto
Int Property QuestStageToSet Auto

Function OnLoad() Native
