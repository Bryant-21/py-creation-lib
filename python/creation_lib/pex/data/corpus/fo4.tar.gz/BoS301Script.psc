Scriptname BoS301Script Extends WorkshopEventsQuestScript

globalvariable Property BoS301ActuatorsBuilt Auto Const
Bool Property bAllObjectivesComplete Auto
refcollectionalias Property BoS301Actuators Auto Const
globalvariable Property BoS301ActuatorsTotal Auto Const
keyword Property BoS301ActuatorKeyword Auto Const

Function DisableActuators() Native
Function UpdateObjective(Int modValue, workshopobjectscript newObject) Native
