Scriptname ccSBJFO4003:Fragments:Terminals:TERM_ccSBJFO4003_Terminal_01000134 Extends Terminal

Int Property StageToSet Auto Const
quest Property ccSBJFO4003_Quest Auto Const

Function Fragment_Terminal_03(objectreference akTerminalRef) Native
