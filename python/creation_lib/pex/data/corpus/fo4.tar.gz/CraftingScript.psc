Scriptname CraftingScript Extends Quest

actor Property PlayerRef Auto
perk Property cpl_CompLvlTechnical3 Auto
perk Property cpl_CompLvlMetallic3 Auto
perk Property cpl_CompLvlTechnical2 Auto
perk[] Property Metallic Auto
perk Property cpl_CompLvlMetallic2 Auto
perk[] Property Organic Auto
perk[] Property Technical Auto
perk[] Property Chemical Auto
perk Property cpl_CompLvlChemical2 Auto
perk Property cpl_CompLvlOrganic3 Auto
perk Property cpl_CompLvlChemical3 Auto
perk Property cpl_CompLvlOrganic2 Auto

Function ResetComponentLevels() Native
Function UnlockComponentLevel(perk[] akComponent, Int NewLevel) Native
