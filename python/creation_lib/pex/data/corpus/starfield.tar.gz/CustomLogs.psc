Scriptname CustomLogs Extends ScriptObject

Struct LogDatum
    Bool ShowNormalTraces
    String Prefix
    Bool PrefixTracesWithCallingObject
    String MainLogName
    Bool PrefixTracesWithLogNames
    String SubLogName
EndStruct

Function AddCustomLog(logdatum[] ArrayOfLogs, String MainLogName, String SubLogName, Bool PrefixTracesWithLogNames, Bool PrefixTracesWithCallingObject, String Prefix, Bool ShowNormalTraces) Global Native
Function Trace(logdatum[] ArrayOfLogs, ScriptObject CallingObject, String asTextToPrint, Int aiSeverity) Global Native
Function warning(logdatum[] ArrayOfLogs, ScriptObject CallingObject, String asTextToPrint) Global Native
