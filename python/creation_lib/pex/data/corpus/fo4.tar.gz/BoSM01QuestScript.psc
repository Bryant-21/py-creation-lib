Scriptname BoSM01QuestScript Extends Quest

Bool Property isQuestTrackingEnabled Auto
Bool Property hasUnreportedMidquestEvent Auto
Bool Property isVarhamPulserObjectiveDisplayed Auto
Bool Property isFarisPulserObjectiveDisplayed Auto
Float Property AstlinPulserMaxRange Auto
Bool Property isDanseHandoffEnabled Auto
Float Property FarisPulserMaxRange Auto
objectreference[] Property Transmitters Auto
Bool Property isKellsDialogueEnabled Auto
Bool Property isAstlinPulserObjectiveDisplayed Auto
Quest Property BoS200 Auto
Quest Property BoSM01DanseOverrides Auto
Bool Property isDanseInitialQuestgiver Auto
Float Property radioFrequency Auto
Bool Property isDanseDialogueEnabled Auto
Float Property VarhamPulserMaxRange Auto

Function BeginDanseScene() Native
Function CheckMidquestEventReporting() Native
Function ClearMidquestEventReporting() Native
Function DisableBoSM01Act1() Native
Function DisableBoSM01Dialogue() Native
Function DisableDanseHandoff() Native
Function EnableBoSM01Act1() Native
Function EnableBoSM01Act2() Native
Function EndDanseScene() Native
Event OnTimer(Int timerID)
EndEvent

Function UpdateObjectives() Native
Function UpdatePulserObjectives() Native
