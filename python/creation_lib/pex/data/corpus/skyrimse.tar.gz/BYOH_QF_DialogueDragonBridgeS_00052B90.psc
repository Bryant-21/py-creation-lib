Scriptname BYOH_QF_DialogueDragonBridgeS_00052B90 Extends Quest

referencealias Property Alias_Actor02 Auto
referencealias Property Alias_Actor01 Auto
referencealias Property Alias_Horgeir Auto
referencealias Property Alias_Clinton Auto
faction Property BYOHRelationshipAdoptionFaction Auto

Function Fragment_1() Native
String Function GetState() Native
Function GotoState(String newState) Native
