Scriptname DefaultCollectionAliasOnHit Extends DefaultCollectionAlias

Bool Property SpellHits_HostileOnly Auto

Event OnAliasInit()
EndEvent

Event OnHit(objectreference akTarget, objectreference akAggressor, form akSource, projectile akProjectile, Bool abPowerAttack, Bool abSneakAttack, Bool abBashAttack, Bool abHitBlocked, String asMaterialName)
EndEvent

Function OnLoad(objectreference akSenderRef) Native
Function OnUnload(objectreference akSenderRef) Native
