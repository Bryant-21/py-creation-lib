Scriptname BYOH_QF_BYOHRelationshipAdopt_01003F7B Extends Quest

referencealias Property Alias_HomeCitySteward Auto
locationalias Property Alias_HomeCity Auto
Quest Property WICourier Auto
referencealias Property Alias_NoteMarker Auto
referencealias Property Alias_Note Auto
locationalias Property Alias_Home Auto
referencealias Property Alias_Player Auto

Function Fragment_0() Native
String Function GetState() Native
Function GotoState(String newState) Native
