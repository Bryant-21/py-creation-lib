Scriptname BYOH_TIF__01004D01 Extends TopicInfo

Int Property GoldAmount Auto
globalvariable Property HDWhiterunAlchemy Auto
miscobject Property Gold Auto

Function Fragment_0(ObjectReference akSpeakerRef) Native
String Function GetState() Native
Function GotoState(String newState) Native
