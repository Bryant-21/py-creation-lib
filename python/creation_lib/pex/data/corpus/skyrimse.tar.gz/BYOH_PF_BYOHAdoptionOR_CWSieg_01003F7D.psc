Scriptname BYOH_PF_BYOHAdoptionOR_CWSieg_01003F7D Extends Package

Function Fragment_1(Actor akActor) Native
String Function GetState() Native
Function GotoState(String newState) Native
