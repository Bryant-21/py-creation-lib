Scriptname DialogueCydoniaConvoCommunityScript Extends Quest

Float Property MeetingDuration Auto
Int Property StageToCheckGetDone Auto

Function OnQuestInit() Native
Function OnTimerGameTime(Int aiTimerID) Native
