Scriptname DefaultEventCameraScript Extends ObjectReference

globalvariable Property CameraAngle Auto
camerashot Property CameraShotToPlay Auto
globalvariable Property CameraMove Auto

Event OnInit()
EndEvent

Function Play() Native
