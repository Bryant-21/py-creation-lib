Scriptname DefaultAliasOnMenuItemRun Extends ReferenceAlias

Struct MenuItemDatum
    Int TurnOffStageDone
    Int TurnOffStage
    Int PrereqStage
    Int ItemID
    Int StageToSet
    terminalmenu TargetTerminalMenu
EndStruct

menuitemdatum[] Property MenuItemData Auto
Bool Property ShowTraces Auto

Function HandleMenuItem(alias callingAlias, menuitemdatum[] MenuItemData, Int auiMenuItemID, terminalmenu akTerminalMenuBase, objectreference akTerminalRef, Bool ShouldShowTraces) Global Native
Function OnTerminalMenuItemRun(Int auiMenuItemID, terminalmenu akTerminalBase, objectreference akTerminalRef) Native
