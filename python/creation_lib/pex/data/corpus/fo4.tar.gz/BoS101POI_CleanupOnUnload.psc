Scriptname BoS101POI_CleanupOnUnload Extends RefCollectionAlias

quest Property BoS101POI Auto Const

Event OnUnload(objectreference source)
EndEvent
