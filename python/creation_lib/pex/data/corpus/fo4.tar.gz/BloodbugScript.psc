Scriptname BloodbugScript Extends Actor

Int Property sacState Auto
String Property BloodbugSpitEventName Auto
String Property BloodbugFeedEventName Auto
ammo Property AmmoBloodbug Auto
miscobject Property BloodbugSacFilledRed Auto
actorvalue Property AvailableCondition1 Auto
keyword Property ActorTypeIrradiated Auto
explosion Property BloodbugDeathGreenExplosion Auto
miscobject Property BloodbugSacFilledGreen Auto
spell Property DrinkBloodSpell Auto
miscobject Property BloodbugSacEmpty Auto
actorvalue Property AvailableCondition2 Auto
explosion Property BloodbugDeathRedExplosion Auto

Function ConsoleFillButt() Native
Function initializeBloodbug() Native
Event OnAnimationEvent(objectreference source, String eventName)
EndEvent

Event OnCripple(actorvalue akActorValue, Bool abCrippled)
EndEvent

Event OnDying(Actor akKiller)
EndEvent

Event OnHit(objectreference akTarget, objectreference aggressor, form akSource, projectile akProjectile, Bool abPowerAttack, Bool abSneakAttack, Bool abBashAttack, Bool abHitBlocked, String asMaterialName)
EndEvent

Event OnLoad()
EndEvent

Event onUnload()
EndEvent
