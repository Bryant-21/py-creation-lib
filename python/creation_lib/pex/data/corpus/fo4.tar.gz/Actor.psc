Scriptname Actor Extends ObjectReference

Int Property CritStage_FreezeEnd Auto
Int Property CritStage_DisintegrateEnd Auto
Int Property CritStage_None Auto
Int Property CritStage_GooStart Auto
Int Property CritStage_DisintegrateStart Auto
Int Property CritStage_GooEnd Auto
Int Property CritStage_FreezeStart Auto

Function AddPerk(perk akPerk, Bool abNotify = false) Native
Bool Function AddSpell(spell akSpell, Bool abVerbose = true) Native
Function AddToFaction(faction akFaction) Native
Function AllowBleedoutDialogue(Bool abCanTalk) Native
Function AllowCompanion(Bool MakeCompanionIfNoneCurrently = true, Bool ForceCompanion = false) Native
Function AllowPCDialogue(Bool abTalk) Native
Function AttachAshPile(form akAshPileBase = None) Native
Function AttemptAnimationSetSwitch() Native
Bool Function CanFlyHere() Native
Bool Function CanMoveVertical() Native
Bool Function CanStrafe() Native
Bool Function ChangeAnimArchetype(keyword apKeyword = none) Native
Function ChangeAnimFaceArchetype(keyword apKeyword = none) Native
Bool Function ChangeAnimFlavor(keyword apKeyword = none) Native
Function ChangeHeadPart(headpart apHeadPart, Bool abRemovePart = false, Bool abRemoveExtraParts = false) Native
Function ClearArrested() Native
Function ClearExpressionOverride() Native
Function ClearExtraArrows() Native
Function ClearForcedLandingMarker() Native
Function ClearForcedMovement() Native
Function ClearLookAt() Native
Function DisallowCompanion(Bool SuppressDismissMessage = false) Native
Function Dismember(String asBodyPart, Bool abForceExplode = false, Bool abForceDismember = false, Bool abForceBloodyMess = false) Native
Bool Function Dismount() Native
Function DispelAllSpells() Native
Bool Function DispelSpell(spell akSpell) Native
Function DoCombatSpellApply(spell akSpell, ObjectReference akTarget) Native
Function DogDropItems() Native
Function DogPlaceInMouth(form akItem) Native
Function DrawWeapon() Native
Function EnableAI(Bool abEnable = true, Bool abPauseVoice = false) Native
Function EndDeferredKill() Native
Function EquipItem(form akItem, Bool abPreventRemoval = false, Bool abSilent = false) Native
Function EquipSpell(spell akSpell, Int aiSource) Native
Function EvaluatePackage(Bool abResetAI = false) Native
Function FollowerFollow() Native
Function FollowerSetDistanceFar() Native
Function FollowerSetDistanceMedium() Native
Function FollowerSetDistanceNear() Native
Function FollowerWait() Native
Function ForceMovementDirection(Float afXAngle = 0.0, Float afYAngle = 0.0, Float afZAngle = 0.0) Native
Function ForceMovementDirectionRamp(Float afXAngle = 0.0, Float afYAngle = 0.0, Float afZAngle = 0.0, Float afRampTime = 0.1) Native
Function ForceMovementRotationSpeed(Float afXMult = 0.0, Float afYMult = 0.0, Float afZMult = 0.0) Native
Function ForceMovementRotationSpeedRamp(Float afXMult = 0.0, Float afYMult = 0.0, Float afZMult = 0.0, Float afRampTime = 0.1) Native
Function ForceMovementSpeed(Float afSpeedMult) Native
Function ForceMovementSpeedRamp(Float afSpeedMult, Float afRampTime = 0.1) Native
Function ForceTargetAngle(Float afXAngle = 0.0, Float afYAngle = 0.0, Float afZAngle = 0.0) Native
Function ForceTargetDirection(Float afXAngle = 0.0, Float afYAngle = 0.0, Float afZAngle = 0.0) Native
Function ForceTargetSpeed(Float afSpeed) Native
actorbase Function GetActorBase() Native
actor[] Function GetAllCombatTargets() Native
Int Function GetBribeAmount() Native
Int Function GetCombatState() Native
Actor Function GetCombatTarget() Native
faction Function GetCrimeFaction() Native
package Function GetCurrentPackage() Native
Actor Function GetDialogueTarget() Native
Int Function GetEquippedItemType(Int aiEquipIndex) Native
armor Function GetEquippedShield() Native
spell Function GetEquippedSpell(Int aiSource) Native
weapon Function GetEquippedWeapon(Int aiEquipIndex = 0) Native
Int Function GetFactionRank(faction akFaction) Native
Int Function GetFactionReaction(Actor akOther) Native
Int Function GetFlyingState() Native
ObjectReference Function GetForcedLandingMarker() Native
Int Function GetGoldAmount() Native
Int Function GetHighestRelationshipRank() Native
Actor Function GetKiller() Native
Int Function GetLevel() Native
actorbase Function GetLeveledActorBase() Native
Float Function GetLightLevel() Native
Int Function GetLowestRelationshipRank() Native
Bool Function GetNoBleedoutRecovery() Native
Bool Function GetPlayerControls() Native
race Function GetRace() Native
Int Function GetRelationshipRank(Actor akOther) Native
Int Function GetSitState() Native
Int Function GetSleepState() Native
Bool Function HasAssociation(associationtype akAssociation, Actor akOther = None) Native
Bool Function HasDetectionLOS(ObjectReference akOther) Native
Bool Function HasFamilyRelationship(Actor akOther = None) Native
Bool Function HasMagicEffect(magiceffect akEffect) Native
Bool Function HasMagicEffectWithKeyword(keyword akKeyword) Native
Bool Function HasParentRelationship(Actor akOther) Native
Bool Function HasPerk(perk akPerk) Native
Bool Function HasSpell(form akForm) Native
Bool Function IsAIEnabled() Native
Bool Function IsAlarmed() Native
Bool Function IsAlerted() Native
Bool Function IsAllowedToFly() Native
Bool Function IsArrested() Native
Bool Function IsArrestingTarget() Native
Bool Function IsBeingRidden() Native
Bool Function IsBeingRiddenBy(Actor akActor) Native
Bool Function IsBleedingOut() Native
Bool Function IsBribed() Native
Bool Function IsChild() Native
Bool Function IsCommandedActor() Native
Bool Function IsDead() Native
Bool Function IsDetectedBy(Actor akOther) Native
Bool Function IsDismembered(String asBodyPart = "") Native
Bool Function IsDoingFavor() Native
Bool Function IsEquipped(form akItem) Native
Bool Function IsEssential() Native
Bool Function IsFlying() Native
Bool Function IsGhost() Native
Bool Function IsGuard() Native
Bool Function IsHostileToActor(Actor akActor) Native
Bool Function IsInCombat() Native
Bool Function IsInFaction(faction akFaction) Native
Bool Function IsInIronSights() Native
Bool Function IsInKillMove() Native
Bool Function IsInPowerArmor() Native
Bool Function IsInScene() Native
Bool Function IsIntimidated() Native
Bool Function IsOnMount() Native
Bool Function IsOverEncumbered() Native
Bool Function IsOwner(ObjectReference akObject) Native
Bool Function IsPlayersLastRiddenHorse() Native
Bool Function IsPlayerTeammate() Native
Bool Function IsRunning() Native
Bool Function IsSeatOccupied(keyword apKeyword) Native
Bool Function IsSneaking() Native
Bool Function IsSprinting() Native
Bool Function IsTalking() Native
Bool Function IsTrespassing() Native
Bool Function IsUnconscious() Native
Bool Function IsWeaponDrawn() Native
Function Kill(Actor akKiller = None) Native
Function KillEssential(Actor akKiller = None) Native
Function KillSilent(Actor akKiller = None) Native
Function MakePlayerFriend() Native
Function MarkItemAsFavorite(form akItem, Int aiSlot = -1) Native
Function ModFactionRank(faction akFaction, Int aiMod) Native
Function ModFavorPoints(Int iFavorPoints = 1) Native
Function ModFavorPointsWithGlobal(globalvariable FavorPointsGlobal) Native
Function MoveToPackageLocation() Native
Event OnCombatStateChanged(Actor akTarget, Int aeCombatState)
EndEvent

Event OnCommandModeCompleteCommand(Int aeCommandType, ObjectReference akTarget)
EndEvent

Event OnCommandModeEnter()
EndEvent

Event OnCommandModeExit()
EndEvent

Event OnCommandModeGiveCommand(Int aeCommandType, ObjectReference akTarget)
EndEvent

Event OnCompanionDismiss()
EndEvent

Event OnConsciousnessStateChanged(Bool abUnconscious)
EndEvent

Event OnCripple(actorvalue akActorValue, Bool abCrippled)
EndEvent

Event OnDeath(Actor akKiller)
EndEvent

Event OnDeferredKill(Actor akKiller)
EndEvent

Event OnDifficultyChanged(Int aOldDifficulty, Int aNewDifficulty)
EndEvent

Event OnDying(Actor akKiller)
EndEvent

Event OnEnterBleedout()
EndEvent

Event OnEnterSneaking()
EndEvent

Event OnEscortWaitStart()
EndEvent

Event OnEscortWaitStop()
EndEvent

Event OnGetUp(ObjectReference akFurniture)
EndEvent

Event OnItemEquipped(form akBaseObject, ObjectReference akReference)
EndEvent

Event OnItemUnequipped(form akBaseObject, ObjectReference akReference)
EndEvent

Event OnKill(Actor akVictim)
EndEvent

Event OnLocationChange(location akOldLoc, location akNewLoc)
EndEvent

Event OnPackageChange(package akOldPackage)
EndEvent

Event OnPackageEnd(package akOldPackage)
EndEvent

Event OnPackageStart(package akNewPackage)
EndEvent

Event OnPartialCripple(actorvalue akActorValue, Bool abCrippled)
EndEvent

Event OnPickpocketFailed()
EndEvent

Event OnPlayerCreateRobot(Actor akNewRobot)
EndEvent

Event OnPlayerEnterVertibird(ObjectReference akVertibird)
EndEvent

Event OnPlayerFallLongDistance(Float afDamage)
EndEvent

Event OnPlayerFireWeapon(form akBaseObject)
EndEvent

Event OnPlayerHealTeammate(Actor akTeammate)
EndEvent

Event OnPlayerLoadGame()
EndEvent

Event OnPlayerModArmorWeapon(form akBaseObject, objectmod akModBaseObject)
EndEvent

Event OnPlayerModRobot(Actor akRobot, objectmod akModBaseObject)
EndEvent

Event OnPlayerSwimming()
EndEvent

Event OnPlayerUseWorkBench(ObjectReference akWorkBench)
EndEvent

Event OnRaceSwitchComplete()
EndEvent

Event OnSit(ObjectReference akFurniture)
EndEvent

Event OnSpeechChallengeAvailable(ObjectReference akSpeaker)
EndEvent

Function OpenInventory(Bool abForceOpen = false) Native
Bool Function PathToReference(ObjectReference aTarget, Float afWalkRunPercent) Native
Bool Function PlayIdle(idle akIdle) Native
Bool Function PlayIdleAction(action aAction, ObjectReference aTarget = None) Native
Bool Function PlayIdleWithTarget(idle akIdle, ObjectReference akTarget) Native
Function PlaySubGraphAnimation(String asEventName) Native
Function RemoveFromAllFactions() Native
Function RemoveFromFaction(faction akFaction) Native
Function RemovePerk(perk akPerk) Native
Bool Function RemoveSpell(spell akSpell) Native
Function ResetHealthAndLimbs() Native
Function Resurrect() Native
Function SendAssaultAlarm() Native
Function SendTrespassAlarm(Actor akCriminal) Native
Function SetAlert(Bool abAlerted = true) Native
Function SetAllowFlying(Bool abAllowed = true, Bool abAllowCrash = true, Bool abAllowSearch = false) Native
Function SetAlpha(Float afTargetAlpha, Bool abFade = false) Native
Function SetAnimArchetypeConfident() Native
Function SetAnimArchetypeDepressed() Native
Function SetAnimArchetypeElderly() Native
Function SetAnimArchetypeFriendly() Native
Function SetAnimArchetypeIrritated() Native
Function SetAnimArchetypeNervous() Native
Function SetAnimArchetypeNeutral() Native
Function SetAttackActorOnSight(Bool abAttackOnSight = true) Native
Function SetAvailableToBeCompanion() Native
Function SetAvoidPlayer(Bool abAvoid = true) Native
Function SetBribed(Bool abBribe = true) Native
Function SetCanDoCommand(Bool abCanCommand = true) Native
Function SetCombatStyle(combatstyle akCombatStyle) Native
Function SetCommandState(Bool abStartCommandMode) Native
Function SetCompanion(Bool SetCompanion = true, Bool FillCompanionAlias = true) Native
Function SetCrimeFaction(faction akFaction) Native
Function SetCriticalStage(Int aiStage) Native
Function SetDogAnimArchetypeAgitated() Native
Function SetDogAnimArchetypeAlert() Native
Function SetDogAnimArchetypeNeutral() Native
Function SetDogAnimArchetypePlayful() Native
Function SetDoingFavor(Bool abDoingFavor = true, Bool abWorkShopMode = false) Native
Function SetEssential(Bool abEssential) Native
Function SetEyeTexture(textureset akNewTexture) Native
Function SetFactionRank(faction akFaction, Int aiRank) Native
Function SetForcedLandingMarker(ObjectReference aMarker) Native
Function SetGhost(Bool abIsGhost = true) Native
Function SetHasCharGenSkeleton(Bool abCharGen = true) Native
Function SetHeadTracking(Bool abEnable = true) Native
Function SetIntimidated(Bool abIntimidate = true) Native
Function SetLookAt(ObjectReference akTarget, Bool abPathingLookAt = false) Native
Function SetNoBleedoutRecovery(Bool abAllowed) Native
Function SetNotShowOnStealthMeter(Bool abNotShow) Native
Function SetOutfit(outfit akOutfit, Bool abSleepOutfit = false) Native
Function SetOverrideVoiceType(voicetype akVoiceType) Native
Function SetPlayerControls(Bool abControls) Native
Function SetPlayerResistingArrest() Native
Function SetPlayerTeammate(Bool abTeammate = true, Bool abCanDoFavor = true, Bool abGivePlayerXP = false) Native
Function SetProtected(Bool abProtected) Native
Function SetRace(race akRace = None) Native
Function SetRelationshipRank(Actor akOther, Int aiRank) Native
Bool Function SetRestrained(Bool abRestrained = true) Native
Function SetSubGraphFloatVariable(String asVariableName, Float afValue) Native
Bool Function SetUnconscious(Bool abUnconscious = true) Native
Function SetVehicle(Actor akVehicle) Native
Function ShowBarterMenu() Native
Bool Function SnapIntoInteraction(ObjectReference akTarget) Native
Function StartCannibal(Actor akTarget) Native
Function StartCombat(Actor akTarget, Bool abPreferredTarget = false) Native
Function StartDeferredKill() Native
Function StartFrenzyAttack(Float aChance = 0.1, Float aInterval = 0.5) Native
Function StartSneaking() Native
Function StartVampireFeed(Actor akTarget) Native
Function StopCombat() Native
Function StopCombatAlarm() Native
Function SwitchToPowerArmor(ObjectReference aArmorFurniture) Native
Bool Function TrapSoul(Actor akTarget) Native
Function UnequipAll() Native
Function UnequipItem(form akItem, Bool abPreventEquip = false, Bool abSilent = false) Native
Function UnequipItemSlot(Int aiSlot) Native
Function UnequipSpell(spell akSpell, Int aiSource) Native
Function UnLockOwnedDoorsInCell() Native
Bool Function WillIntimidateSucceed() Native
Bool Function WornHasKeyword(keyword akKeyword) Native
Bool Function WouldBeStealing(ObjectReference akObject) Native
Int Function WouldRefuseCommand(ObjectReference akObject) Native
