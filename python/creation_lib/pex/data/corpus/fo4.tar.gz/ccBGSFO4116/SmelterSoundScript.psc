Scriptname ccBGSFO4116:SmelterSoundScript Extends ObjectReference

globalvariable Property isSmelterMoving Auto
sound Property ccBGSFO4116_QSTSlagLPM Auto
ObjectReference Property MoltenLava Auto
ObjectReference Property Spigot Auto

Function OnActivate(ObjectReference akActionRef) Native
Function OnCellAttach() Native
Function OnCellDetach() Native
Function PlaySound() Native
