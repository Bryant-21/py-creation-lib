Scriptname AddFactionToPlayerOnActivate Extends ObjectReference

faction Property FactionToAdd Auto

Function OnActivate(ObjectReference akActionRef) Native
