Scriptname CompanionMurderLocationToggleScript Extends Quest

location Property BostonAirportLocation Auto Const
location Property BostonAirportAliasCellLocation Auto Const
location Property InstituteLocation Auto Const
location Property BostonAirportRuinsLocation Auto Const
location Property PrydwenQuartersLocation Auto Const
location Property PrydwenLocation Auto Const
followersscript Property Followers Auto Const
location Property RailroadHQLocation Auto Const

Function OkayToMurderInBrotherhoodHQ() Native
Function OkayToMurderInInstitute() Native
Function OkayToMurderInRailroadHQ() Native
