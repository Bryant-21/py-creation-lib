Scriptname CityCYRedTape03HankDistanceScript Extends Quest

Struct DistanceCheckStage
    Int StageToSet
    Int TurnOffStageDone
    Int PrereqStage
    Float TargetDistance
EndStruct

referencealias Property Hank Auto
distancecheckstage[] Property DistanceCheckStages Auto
referencealias Property EquipmentMarker Auto

Function OnDistanceLessThan(objectreference akObj1, objectreference akObj2, Float afDistance, Int aiEventID) Native
Function StartDistanceCheck() Native
