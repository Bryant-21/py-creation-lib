Scriptname CompanionPowerArmorKeywordScript Extends Actor

keyword Property isPowerArmorFrame Auto Const
keyword Property pAttachSlot2 Auto Const
keyword Property pAttachPassenger Auto Const

Event OnItemEquipped(form akBaseObject, objectreference akReference)
EndEvent

Event OnItemUnequipped(form akBaseObject, objectreference akReference)
EndEvent
