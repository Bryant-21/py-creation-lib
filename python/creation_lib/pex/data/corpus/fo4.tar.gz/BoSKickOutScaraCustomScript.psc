Scriptname BoSKickOutScaraCustomScript Extends ReferenceAlias

globalvariable Property BoSLiSlain Auto Const
quest Property BoS301 Auto Const
quest Property BoSKickOut Auto Const

Event OnDying(actor akKiller)
EndEvent
