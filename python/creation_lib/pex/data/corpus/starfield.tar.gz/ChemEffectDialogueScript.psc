Scriptname ChemEffectDialogueScript Extends ActiveMagicEffect

keyword Property PlayerConsumeChem Auto

Event OnEffectStart(objectreference akTarget, actor akCaster, magiceffect akBaseEffect, Float afMagnitude, Float afDuration)
EndEvent
