Scriptname DefaultDisableSelfTrigger Extends ObjectReference

Bool Property PlayerOnly Auto
faction[] Property TriggeredByFactions Auto
referencealias[] Property TriggeredByAliases Auto
objectreference[] Property TriggeredByReferences Auto
Int Property PlayerMinLevel Auto

Event onBeginState(String asOldState)
EndEvent

Event onTriggerEnter(ObjectReference triggerRef)
EndEvent
