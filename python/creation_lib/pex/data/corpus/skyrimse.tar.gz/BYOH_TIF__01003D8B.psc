Scriptname BYOH_TIF__01003D8B Extends TopicInfo

objectreference Property DecorateMarker Auto
miscobject Property Gold Auto
Int Property GoldAmount Auto
globalvariable Property HDRiftenBedroom Auto

Function Fragment_0(objectreference akSpeakerRef) Native
String Function GetState() Native
Function GotoState(String newState) Native
