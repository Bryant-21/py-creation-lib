Scriptname CF01QuestScript Extends Quest

faction Property CrimeFactionUC Auto

Function ModCrimeGold(Int amount) Native
Function RemovePlayerContraband() Native
Function SendPlayerToJail() Native
