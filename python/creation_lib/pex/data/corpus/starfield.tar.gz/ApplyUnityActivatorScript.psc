Scriptname ApplyUnityActivatorScript Extends ReferenceAlias

ReferenceAlias Property SourceActor Auto
miscobject Property Credits Auto
actorvalue Property Oxygen Auto
actorvalue Property Health Auto
ReferenceAlias Property ReceivingActor Auto

Function ApplyUnityCharacter(actor akSourceActor) Native
Function OnActivate(objectreference akActionRef) Native
