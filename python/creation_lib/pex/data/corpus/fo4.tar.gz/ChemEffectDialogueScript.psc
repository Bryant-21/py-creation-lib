Scriptname ChemEffectDialogueScript Extends ActiveMagicEffect

keyword Property PlayerConsumeChem Auto

Event OnEffectStart(actor akTarget, actor akCaster)
EndEvent
