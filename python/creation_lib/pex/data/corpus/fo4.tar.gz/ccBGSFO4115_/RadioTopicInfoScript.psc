Scriptname ccBGSFO4115_:RadioTopicInfoScript Extends TopicInfo

Int Property NewCurrentSong Auto Const

Function OnBegin(objectreference akSpeakerRef, Bool abHasBeenSaid) Native
