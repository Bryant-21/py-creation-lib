Scriptname DialogueECSConstantQuestScript Extends Quest

Struct NPCData
    referencealias NPCAlias
    referencealias MarkerAlias
EndStruct

referencealias Property ECSConstantShip Auto
npcdata[] Property NPCDatum Auto
refcollectionalias Property GenericNPCs Auto

Function MoveNPCs() Native
Function OnQuestInit() Native
