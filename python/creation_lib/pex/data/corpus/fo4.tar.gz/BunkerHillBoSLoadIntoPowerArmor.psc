Scriptname BunkerHillBoSLoadIntoPowerArmor Extends Actor

keyword Property LinkPowerArmor Auto

Event OnCellLoad()
EndEvent
