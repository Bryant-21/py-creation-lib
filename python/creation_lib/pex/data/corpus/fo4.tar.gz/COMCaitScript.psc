Scriptname COMCaitScript Extends Quest

Int Property InfatuationPlayerResponse Auto
