Scriptname CreationClub:VRWorkshops:VRWorkshopNPCScript Extends Actor

effectshader Property TeleportInFXS Auto
sound Property TeleportSound Auto
effectshader Property TeleportOutFXS Auto

Event OnDeath(Actor akKiller)
EndEvent

Event OnInit()
EndEvent

Event OnLoad()
EndEvent
