Scriptname BunkerHil_UnlockGateScript Extends ObjectReference

keyword Property LinkCustom01 Auto Const

Event OnTriggerEnter(ObjectReference akActionRef)
EndEvent
