Scriptname CityCYRunaway01GuardScript Extends ReferenceAlias

Int Property LobbyTriggerStage Auto

Function GuardAlarm() Native
Function OnLoad() Native
Function OnTimer(Int aiTimerId) Native
