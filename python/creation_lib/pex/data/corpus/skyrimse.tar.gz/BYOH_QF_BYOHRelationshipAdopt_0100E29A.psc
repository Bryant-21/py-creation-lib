Scriptname BYOH_QF_BYOHRelationshipAdopt_0100E29A Extends Quest

Quest Property BYOHRelationshipAdoptableOrphanage Auto

Function Fragment_0() Native
String Function GetState() Native
Function GotoState(String newState) Native
