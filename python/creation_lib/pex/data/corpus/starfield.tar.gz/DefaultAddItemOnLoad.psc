Scriptname DefaultAddItemOnLoad Extends ObjectReference

form Property ItemToAdd Auto
Int Property Count Auto

Event OnLoad()
EndEvent
