Scriptname BoSR04PlayerScript Extends ReferenceAlias

alias Property BoSR04Scribe Auto Const
location Property PrydwenLocation Auto Const
quest Property BoSR04 Auto Const

Event OnLocationChange(location akOldLoc, location akNewLoc)
EndEvent
