Scriptname ashPileOnDeathSCRIPT Extends ActiveMagicEffect

Float Property DelayRandMax Auto
Float Property DelayRandMin Auto
Bool Property bSetAlphaZero Auto
activator Property AshPileObject Auto
Int Property decalCount Auto
effectshader Property MagicEffectShader Auto
Float Property ShaderDuration Auto
impactdataset Property SplatterImpactData Auto

Event OnDying(actor Killer)
EndEvent

Event OnEffectStart(actor Target, actor Caster)
EndEvent
