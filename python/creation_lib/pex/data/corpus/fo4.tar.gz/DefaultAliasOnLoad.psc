Scriptname DefaultAliasOnLoad Extends DefaultAlias

Event OnLoad()
EndEvent
