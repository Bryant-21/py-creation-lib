Scriptname CreationClub:StartAfterCharGenScript Extends Quest

Int Property MyStageToSet Auto
Int Property CharGenStageToWatch Auto
Quest Property MQ102 Auto

Event OnInit()
EndEvent

Event OnTimer(Int aiTimerID)
EndEvent

Function SetCreationStage() Native
