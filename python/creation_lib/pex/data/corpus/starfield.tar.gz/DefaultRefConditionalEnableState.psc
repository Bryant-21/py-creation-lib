Scriptname DefaultRefConditionalEnableState Extends ObjectReference

conditionform Property EnableConditions Auto
Bool Property ShowTraces Auto
Bool Property DisableIfFalse Auto

Function OnLoad() Native
