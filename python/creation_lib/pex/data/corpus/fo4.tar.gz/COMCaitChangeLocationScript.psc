Scriptname COMCaitChangeLocationScript Extends ReferenceAlias

globalvariable Property COMCait_CZComment Auto Const
location Property CombatZoneLocation Auto Const

Event OnLocationChange(location akOldLoc, location akNewLoc)
EndEvent
