Scriptname CF06QuestScript Extends Quest

faction Property CrimeFactionNeon Auto
actorvalue Property Assistance Auto
referencealias Property CF06_AstralLoungeBayuMarker Auto
actorvalue Property Confidence Auto
referencealias Property CF06_AstralLoungeLoadDoor Auto
faction Property PlayerFaction Auto
location Property CityNeonTradeTowerAstralLoungeLocation Auto
cell Property CityNeonTradeTowerAstralLounge Auto
Int Property iStageToMoveBayu Auto
Int Property iStageDoneWithBayu Auto
referencealias Property CF06_BenjaminBayu Auto

Function CallNeonCrime() Native
Function OnQuestInit() Native
Function OnTimerGameTime(Int aiTimerID) Native
Function ReleasePlayer() Native
Function StartGetOffPlanetTimer() Native
