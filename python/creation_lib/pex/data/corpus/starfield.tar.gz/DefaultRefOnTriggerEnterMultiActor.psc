Scriptname DefaultRefOnTriggerEnterMultiActor Extends DefaultOnEnterMultiActor

quest Property QuestToSet Auto
Bool Property DeleteWhenDone Auto
Int Property TurnOffStageDone Auto
Int Property TurnOffStage Auto
Int Property PrereqStage Auto
Int Property StageToSet Auto

Function TriggerMe() Native
Function TryToSetStage(Bool PlayerCheckOverride = FALSE, objectreference RefToCheck = NONE, form FormToCheck = NONE, objectreference[] ReferenceArray = NONE, referencealias[] AliasArray = NONE, faction[] FactionArray = NONE, form[] FormArray = NONE, location[] LocationArray = NONE, locationalias[] LocationAliasArray = NONE, Bool LocationMatchIfChild) Native
