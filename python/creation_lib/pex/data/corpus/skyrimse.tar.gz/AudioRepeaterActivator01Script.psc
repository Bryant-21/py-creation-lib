Scriptname AudioRepeaterActivator01Script Extends ObjectReference

sound Property SoundDescriptor Auto
Float Property delayMax Auto
Float Property delayMin Auto

String Function GetState() Native
Function GotoState(String newState) Native
Function OnCellAttach() Native
Function OnCellDetach() Native
