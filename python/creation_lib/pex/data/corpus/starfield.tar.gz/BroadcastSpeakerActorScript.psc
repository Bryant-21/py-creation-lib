Scriptname BroadcastSpeakerActorScript Extends Actor

keyword Property LinkedRefBroadcastSpeaker Auto
objectreference[] Property SpeakerRefs Auto

Function ToggleSpeakers(Bool ShouldTurnOn = True) Native
