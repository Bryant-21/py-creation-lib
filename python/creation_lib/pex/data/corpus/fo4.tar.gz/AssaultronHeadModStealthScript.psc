Scriptname AssaultronHeadModStealthScript Extends ActiveMagicEffect

actorvalue Property endurancecondition Auto
actorvalue Property RightMobilityCondition Auto
ammo Property AmmoAssaultron Auto
spell Property stealthSpell Auto
sound Property laserChargeSound Auto
sound Property LaserTailSound Auto
sound Property LaserFireSound Auto
Int Property laserState Auto
actorvalue Property LeftAttackCondition Auto
actorvalue Property RightAttackCondition Auto
spell Property PcrThermalCoreCloak Auto
actorvalue Property headlaserAV Auto
magiceffect Property stealthEffect Auto
actorvalue Property LeftMobilityCondition Auto
imagespacemodifier Property laserImod Auto
sound Property laserReadySound Auto
weapon Property pAssaultronLaser Auto
visualeffect Property pAssaultronHeadChargeV Auto

Function beginChargingLaser(actor SelfRef) Native
Function cloak(actor SelfRef) Native
Function deCloak(actor SelfRef) Native
Function endLaser(actor SelfRef) Native
Function fireLaser(actor SelfRef) Native
Function laserCrippled(actor SelfRef) Native
Function limbCrippledReduceLaserCoolTime() Native
Event OnAnimationEvent(objectreference akSource, String asEventName)
EndEvent

Event OnCombatStateChanged(actor akTarget, Int aeCombatState)
EndEvent

Event OnCripple(actorvalue akActorValue, Bool abCrippled)
EndEvent

Event OnDying(actor akKiller)
EndEvent

Event OnEffectFinish(actor akTarget, actor akCaster)
EndEvent

Event OnEffectStart(actor akTarget, actor akCaster)
EndEvent

Event OnTimer(Int aiTimerID)
EndEvent

Function readyLaser(actor SelfRef) Native
