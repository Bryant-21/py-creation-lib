Scriptname CommonArrayFunctions Extends ScriptObject

Bool Function CheckActorAgainstFactionArray(actor ObjectToCheck, faction[] ArrayToCheck, Bool returnValueIfArrayIsEmpty = false) Global Native
Bool Function CheckFormAgainstArray(form FormToCheck, form[] ArrayToCheck, Bool returnValueIfArrayIsEmpty = false) Global Native
Bool Function CheckFormAgainstKeywordArray(form ObjectToCheck, keyword[] ArrayToCheck, Bool returnValueIfArrayIsEmpty = false) Global Native
Bool Function CheckLocationAgainstArray(location ObjectToCheck, location[] ArrayToCheck, Bool returnValueIfArrayIsEmpty = false, Bool matchIfChildLocation = false) Global Native
Bool Function CheckLocationAgainstLocationAliasArray(location ObjectToCheck, locationalias[] ArrayToCheck, Bool returnValueIfArrayIsEmpty = false, Bool matchIfChildLocation = false) Global Native
Bool Function CheckObjectAgainstKeywordArray(objectreference ObjectToCheck, keyword[] ArrayToCheck, Bool returnValueIfArrayIsEmpty = false) Global Native
Bool Function CheckObjectReferenceAgainstArray(objectreference ObjectToCheck, objectreference[] ArrayToCheck, Bool returnValueIfArrayIsEmpty = false) Global Native
Bool Function CheckObjectReferenceAgainstReferenceAliasArray(objectreference ObjectToCheck, referencealias[] ArrayToCheck, Bool returnValueIfArrayIsEmpty = false) Global Native
Int Function FindInReferenceAliasArray(objectreference ObjectToCheck, referencealias[] ArrayToCheck) Global Native
faction Function GetFirstFoundFactionInArrayForActor(actor ActorToCheck, faction[] ArrayToCheck) Global Native
keyword Function GetFirstFoundKeywordInArrayForLocation(location LocationToCheck, keyword[] ArrayToCheck) Global Native
Bool Function IsActorInArrayHostileToActor(actor ActorToCheck, objectreference[] ArrayToCheck) Global Native
