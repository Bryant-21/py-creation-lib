Scriptname AddItemFavorite Extends ObjectReference

Int Property FavoriteSlot Auto
globalvariable Property ItemHasFavorited Auto

Event OnContainerChanged(ObjectReference akNewContainer, ObjectReference akOldContainer)
EndEvent

Event OnInit()
EndEvent
