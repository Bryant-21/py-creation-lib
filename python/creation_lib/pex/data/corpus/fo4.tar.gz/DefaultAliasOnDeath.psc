Scriptname DefaultAliasOnDeath Extends DefaultAlias

objectreference[] Property KilledByReferences Auto Const
referencealias[] Property KilledByAliases Auto Const
Bool Property UseOnDyingInstead Auto Const
faction[] Property KilledByFactions Auto Const

Event OnDeath(actor akKiller)
EndEvent

Event OnDying(actor akKiller)
EndEvent
