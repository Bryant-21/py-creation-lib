Scriptname BYOH_QF_BYOHHousePale_01010BEE Extends Quest

book Property BYOHHouseJarlFriendLetter Auto
referencealias Property Alias_HouseInteriorMarker Auto
locationalias Property Alias_houseLocation Auto
book Property BYOHHouseJarlIntroLetter Auto
referencealias Property Alias_HouseHorse Auto
wicourierscript Property WICourier Auto
locationalias Property Alias_Hold Auto
referencealias Property Alias_Steward Auto
locationalias Property Alias_HoldCity Auto
referencealias Property Alias_Jarl Auto
book Property Charter Auto
globalvariable Property GameDaysPassed Auto
referencealias Property Alias_CarpentersWorkbench Auto
referencealias Property Alias_Charter Auto
referencealias Property Alias_HouseCarriageDriver Auto
referencealias Property Alias_IntroNote Auto
referencealias Property Alias_CourierNote Auto
referencealias Property Alias_DraftingTable Auto

Function Fragment_0() Native
Function Fragment_1() Native
Function Fragment_10() Native
Function Fragment_12() Native
Function Fragment_14() Native
Function Fragment_15() Native
Function Fragment_16() Native
Function Fragment_18() Native
Function Fragment_20() Native
Function Fragment_21() Native
Function Fragment_23() Native
Function Fragment_25() Native
Function Fragment_27() Native
Function Fragment_3() Native
Function Fragment_4() Native
Function Fragment_5() Native
String Function GetState() Native
Function GotoState(String newState) Native
