Scriptname ccBGSFO4046_:PickupCloakEffectScript Extends activemagiceffect

actorvalue Property PipBoyActorValue Auto
armor Property PipBoyThree Auto
armor Property PipBoyOne Auto
keyword Property BlockKeyword Auto
keyword Property DataDoneKeyword Auto
armor Property PipBoyTwo Auto

Function OnEffectStart(actor akTarget, actor akCaster) Native
