Scriptname BYOH_TIF__01007B64 Extends TopicInfo

quest Property RelationshipAdoption Auto
referencealias Property Child Auto

Function Fragment_0(ObjectReference akSpeakerRef) Native
String Function GetState() Native
Function GotoState(String newState) Native
