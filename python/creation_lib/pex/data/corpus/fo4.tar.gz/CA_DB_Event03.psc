Scriptname CA_DB_Event03 Extends ca_dialoguebump_basescript

Function InitializeEventID() Native
