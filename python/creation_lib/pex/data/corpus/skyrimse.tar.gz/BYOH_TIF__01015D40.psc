Scriptname BYOH_TIF__01015D40 Extends TopicInfo

Function Fragment_0(ObjectReference akSpeakerRef) Native
String Function GetState() Native
Function GotoState(String newState) Native
