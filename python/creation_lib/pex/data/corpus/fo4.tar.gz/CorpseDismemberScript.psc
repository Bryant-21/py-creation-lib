Scriptname CorpseDismemberScript Extends ReferenceAlias

quest Property pQuest Auto
Int Property iStageToSet Auto
ReferenceAlias Property pCorpse Auto

Event OnLoad()
EndEvent
