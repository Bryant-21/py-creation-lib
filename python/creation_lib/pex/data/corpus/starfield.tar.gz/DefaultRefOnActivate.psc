Scriptname DefaultRefOnActivate Extends DefaultRef

Event OnActivate(objectreference akActionRef)
EndEvent
