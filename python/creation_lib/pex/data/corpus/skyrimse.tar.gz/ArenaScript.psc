Scriptname ArenaScript Extends Quest

Int Property Level1Fights Auto
armor Property LoanerShield Auto
keyword Property Wave5Keyword Auto
referencealias Property PitDoor Auto
faction Property PacifyFaction Auto
ObjectReference Property Gate1 Auto
Int Property NumberOfPlayerFights Auto
Bool Property NextWagerFightIsExotic Auto
referencealias Property Combatant09 Auto
arenacombatquest Property SpecialFightDB Auto
referencealias Property Combatant02 Auto
referencealias Property TransitionCombatant Auto
arenacombatquest Property Fight09 Auto
Bool Property CombatOngoing Auto
Bool Property PlayerChoseTheField Auto
Bool Property NextWagerFightIsPeople Auto
arenacombatquest Property Fight13 Auto
Int Property ArrestOffset Auto
Quest Property ArenaWagerFighterQuest Auto
keyword Property Wave1Keyword Auto
arenacombatquest Property SpecialFightJail Auto
arenacombatquest Property Fight03 Auto
arenacombatquest Property Fight10 Auto
miscobject Property Gold Auto
arenacombatquest Property Fight06 Auto
keyword Property LinkedDoorKeyword Auto
referencealias Property Combatant06 Auto
keyword Property Wave2Keyword Auto
Bool Property PlayerWonWager Auto
arenacombatquest Property Fight04 Auto
arenacombatquest Property Fight11 Auto
Bool Property NextWagerFightIsEasyAnimals Auto
Quest Property PointerQuest Auto
arenacombatquest Property Fight07 Auto
faction Property SelfLoathing Auto
Bool Property CombatPreSet Auto
keyword Property Wave4Keyword Auto
Bool Property DBFightWentAwry Auto
Int Property WagerAmount Auto
arenacombatquest Property Fight05 Auto
arenacombatquest Property Fight12 Auto
referencealias Property Combatant01 Auto
Bool Property RewardDue Auto
Int Property FightsToNextLevel Auto
Bool Property WagerOngoing Auto
Quest Property DB03 Auto
referencealias Property Combatant04 Auto
Bool Property PlayerGotTheSkinny Auto
weapon Property LoanerSword Auto
ObjectReference Property Gate3 Auto
arenacombatquest Property Fight08 Auto
referencealias Property Combatant08 Auto
arenacombatquest Property TransitionFight Auto
Int Property Level3Fights Auto
keyword Property Wave3Keyword Auto
Bool Property WagerResolutionRequired Auto
faction Property EastmarchCrimeFaction Auto
Int Property Level2Fights Auto
Int Property Level0Fights Auto
referencealias Property Combatant05 Auto
faction Property ArenaFaction Auto
referencealias Property Combatant10 Auto
referencealias Property Combatant03 Auto
arenacombatquest Property CurrentFight Auto
arenacombatquest Property NextWagerFight Auto
Bool Property NextWagerFightIsToughAnimals Auto
Quest Property EastmarchJail Auto
ObjectReference Property Gate2 Auto
arenacombatquest Property Fight01 Auto
referencealias Property Combatant07 Auto
arenacombatquest Property Fight02 Auto

Bool Function _CleanupBody(referencealias combatant) Native
Function CleanupBodies() Native
Function CombatOver() Native
Function EndWagerFight() Native
referencealias Function GetCombatantAlias(Int index) Native
ObjectReference Function GetDoorForWave(Int wave) Native
arenacombatquest Function GetFightQuestFromIndex(Int questIndex) Native
Int Function GetIndexFromFightQuest(arenacombatquest rQuest) Native
keyword Function GetKeywordForWave(Int wave) Native
String Function GetState() Native
Function GotoState(String newState) Native
arenacombatquest Function PickNextFight(Int offset) Native
Function PickNextWagerFight(arenacombatquest lastFight) Native
Function PlaceBet(Int amount) Native
Function PlayerAvoidedWager() Native
Function PlayerJoin() Native
Function Promote() Native
Function RegisterCombatant(ObjectReference Fighter) Native
Function RegisterSpawnPoint(ObjectReference spawnMarker) Native
Function RegisterTransitionCombatant(ObjectReference Fighter) Native
Function ResolveWager() Native
Function Reward() Native
Function Setup() Native
Function StartCombat() Native
Function StartWagerFight() Native
