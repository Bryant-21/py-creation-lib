Scriptname bwcStatuePuzzle Extends ObjectReference

ObjectReference Property brightLightLeft Auto
ObjectReference Property rightFlame Auto
ObjectReference Property dimLight Auto
Bool Property leftLever Auto
ObjectReference Property rightSound Auto
ObjectReference Property brightLightBack Auto
ObjectReference Property leftSound Auto
ObjectReference Property brightLightRight Auto
ObjectReference Property puzzDoor Auto
Bool Property rightLever Auto
ObjectReference Property doorMarker Auto
ObjectReference Property leftFlame Auto

String Function GetState() Native
Function GotoState(String newState) Native
Function ONACTIVATE(ObjectReference trigRef) Native
