Scriptname CompanionOnDismissScript Extends Actor

Int Property StageToSet Auto Const
quest Property QuestWithStageToSet Auto Const

Event OnInit()
EndEvent
