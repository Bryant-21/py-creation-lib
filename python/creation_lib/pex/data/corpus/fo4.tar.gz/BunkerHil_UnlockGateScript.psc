Scriptname BunkerHil_UnlockGateScript Extends ObjectReference

keyword Property LinkCustom01 Auto

Event OnTriggerEnter(ObjectReference akActionRef)
EndEvent
