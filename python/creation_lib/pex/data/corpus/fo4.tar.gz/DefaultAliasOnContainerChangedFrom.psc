Scriptname DefaultAliasOnContainerChangedFrom Extends DefaultAlias

referencealias[] Property ItemChangedFromAliases Auto Const
objectreference[] Property ItemChangedFromReferences Auto Const
faction[] Property ItemChangedFromFactions Auto Const

Event OnContainerChanged(objectreference akNewContainer, objectreference akOldContainer)
EndEvent
