Scriptname COM_CoraBookRemovalScript Extends ReferenceAlias

form Property ItemFilter Auto

Function OnUnload() Native
