Scriptname CZ_CombatantTeleportOnLoad Extends ReferenceAlias

objectreference Property Marker Auto Const
quest Property CZ Auto Const

Event OnLoad()
EndEvent
