Scriptname DefaultCaptiveAlias Extends ReferenceAlias

sq_captivescript Property SQ_Captive Auto
faction Property BoundFaction Auto
globalvariable Property SQ_CaptiveState_2_Freed Auto
Bool Property DeleteWhenCleanedUp Auto
Bool Property RemoveFromFactions Auto
Int Property StageToSetOnCleanUp Auto
Int Property StageToSetWhenFreed Auto
quest Property QuestToSet Auto
Bool Property AlsoRemoveFromCaptiveFaction Auto
Bool Property DisableOnUnload Auto
Bool Property StartBound Auto
sq_followersscript Property SQ_Followers Auto
keyword Property SQ_Captive_FurnitureType_Bound Auto
keyword Property SQ_Captive_DialogueSubtype_FreedPrisonerGratitude Auto
faction Property CaptiveFaction Auto
keyword Property SQ_Link_CaptiveFurniture Auto
actorvalue Property SQ_CaptiveState Auto
globalvariable Property SQ_CaptiveState_0_Unset Auto
globalvariable Property SQ_CaptiveState_1_Captive Auto

Function AddToFactions() Native
Function CleanupIfReady() Native
Function ClearFactions() Native
Function FreePrisoner(Bool playerIsLiberator, Bool OpenPrisonerInventory = true) Native
Function OnAliasChanged(objectreference akObject, Bool abRemove) Native
Event OnAliasInit()
EndEvent

Function OnAliasShutdown() Native
Event OnLoad()
EndEvent

Event OnUnload()
EndEvent

Function RemoveFromCaptiveFactionIfNeeded() Native
Function ResetAVs() Native
Function SetState() Native
