Scriptname ConcordMuseumLightSparks Extends ObjectReference

keyword Property LinkCustom01 Auto

Function EnableDisableLight() Native
