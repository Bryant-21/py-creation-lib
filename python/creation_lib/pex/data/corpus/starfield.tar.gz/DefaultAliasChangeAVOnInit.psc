Scriptname DefaultAliasChangeAVOnInit Extends ReferenceAlias

Struct ActorValueDatum
    Int TypeOfChange
    actorvalue ActorValueToChange
    Float NewValue
EndStruct

actorvaluedatum[] Property ActorValueData Auto

Function OnAliasInit() Native
