Scriptname ccOTMFO4001:ccOTMFO4001_EncEncounterQuestScript Extends Quest

Struct TrackedActor
    actor EncounterActor
    Int CombatState
EndStruct

Function ActorLoaded(actor ActorLoaded, Bool Loaded) Native
Function ActorsCombatStateChanged(actor actorChanged, actor target, Int CombatState) Native
Function LinkTrigger(ccotmfo4001:ccotmfo4001_encencountertriggerscript akTrigger) Native
Function OnInit() Native
Function OnStoryScript(keyword akKeyword, location akLocation, objectreference akRef1, objectreference akRef2, Int aiValue1, Int aiValue2) Native
Function ShutDown() Native
Function TriggerUnloaded() Native
