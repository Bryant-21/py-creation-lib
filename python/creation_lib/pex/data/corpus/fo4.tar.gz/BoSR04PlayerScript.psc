Scriptname BoSR04PlayerScript Extends ReferenceAlias

alias Property BoSR04Scribe Auto
location Property PrydwenLocation Auto
quest Property BoSR04 Auto

Event OnLocationChange(location akOldLoc, location akNewLoc)
EndEvent
