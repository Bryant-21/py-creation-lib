Scriptname abMrHandySelfDestruct Extends RobotSelfDestructScript

explosion Property selfDestructExplosionFX Auto
keyword Property bot_HasHandLeft Auto
keyword Property bot_HasHandMiddle Auto
keyword Property bot_HasHandRight Auto

Event OnActivate(objectreference akActionRef)
EndEvent

Event OnBeginState(String asOldState)
EndEvent

Event OnCombatStateChanged(actor akTarget, Int aeCombatState)
EndEvent

Event OnCripple(actorvalue akActorValue, Bool abCrippled)
EndEvent

Function ResetSelfDestruct() Native
