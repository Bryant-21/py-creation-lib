Scriptname CaitActorScript Extends Actor

globalvariable Property AO_Companion_CaitExplainLockPick_DONE Auto Const
keyword Property AO_CaitExplainLockPick_Start Auto Const

Event OnLoad()
EndEvent

Event OnTimer(Int aiTimerID)
EndEvent

Function StartSendStoryEventTimer() Native
