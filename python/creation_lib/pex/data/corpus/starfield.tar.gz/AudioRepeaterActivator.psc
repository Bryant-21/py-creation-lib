Scriptname AudioRepeaterActivator Extends ObjectReference

wwiseevent Property SoundDescriptor Auto
Float Property delayMax Auto
Float Property delayMin Auto

Float Function GetWaitTime() Native
Event OnCellAttach()
EndEvent

Event OnCellDetach()
EndEvent

Event OnTimer(Int aiTimerID)
EndEvent
