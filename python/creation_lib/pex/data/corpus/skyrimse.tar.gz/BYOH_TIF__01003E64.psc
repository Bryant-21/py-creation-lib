Scriptname BYOH_TIF__01003E64 Extends TopicInfo

faction Property BYOHRelationshipAdoptableFaction Auto

Function Fragment_4(ObjectReference akSpeakerRef) Native
String Function GetState() Native
Function GotoState(String newState) Native
