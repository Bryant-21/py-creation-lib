Scriptname BoSKickoutPAMCustomScript Extends ReferenceAlias

quest Property BoSKickOut Auto Const
quest Property BoS302B Auto Const

Event OnDying(actor akKiller)
EndEvent
