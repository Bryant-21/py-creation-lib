Scriptname BYOH_TIF__01003E52 Extends TopicInfo

referencealias Property WhiterunHouse Auto
referencealias Property SolitudeHouse Auto

Function Fragment_0(ObjectReference akSpeakerRef) Native
String Function GetState() Native
Function GotoState(String newState) Native
