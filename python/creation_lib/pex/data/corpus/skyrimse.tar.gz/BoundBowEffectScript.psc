Scriptname BoundBowEffectScript Extends ActiveMagicEffect

magiceffect Property BoundBowFFSelf Auto
ammo Property boundArrow Auto

String Function GetState() Native
Function GotoState(String newState) Native
Function OnEffectFinish(Actor Target, Actor Caster) Native
Function OnEffectStart(Actor Target, Actor Caster) Native
Function onLoad() Native
