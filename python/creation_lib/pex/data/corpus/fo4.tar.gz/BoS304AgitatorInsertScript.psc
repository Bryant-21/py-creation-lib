Scriptname BoS304AgitatorInsertScript Extends ObjectReference

quest Property BoS304 Auto Const

Event OnActivate(ObjectReference akActionRef)
EndEvent
