Scriptname DefaultAliasOnContainerChangedTo Extends DefaultAlias

faction[] Property ItemChangedToFactions Auto
objectreference[] Property ItemChangedToReferences Auto
Bool Property PlayerPickupOnly Auto
referencealias[] Property ItemChangedToAliases Auto

Event OnContainerChanged(objectreference akNewContainer, objectreference akOldContainer)
EndEvent
