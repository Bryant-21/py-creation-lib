Scriptname Crew_RecruitQuestScript Extends Quest

Float Property CostMult_Taskmaster Auto
sq_crewscript Property SQ_Crew Auto
actorvalue Property Crew_HireSpeechChallengeAttempted Auto
globalvariable Property Crew_RecruitCost_TextReplacementValue Auto
actor Property CrewMemberRef Auto
sq_followersscript Property SQ_Followers Auto
referencealias Property Alias_CrewMember Auto
referencealias Property playerShip Auto
perk Property Trait_Taskmaster Auto

Function Recruited() Native
Function RecruitedUnasssigned() Native
Function SetCostMultAndUpdateCost(Float Mult) Native
Function SpeechChallengeAttempted() Native
Bool Function Trace(ScriptObject CallingObject, String asTextToPrint, Int aiSeverity, String MainLogName, String SubLogName, Bool bShowNormalTrace, Bool bShowWarning, Bool bPrefixTraceWithLogNames) Native
Function UpdateCost() Native
Bool Function warning(ScriptObject CallingObject, String asTextToPrint, Int aiSeverity, String MainLogName, String SubLogName, Bool bShowNormalTrace, Bool bShowWarning, Bool bPrefixTraceWithLogNames) Native
