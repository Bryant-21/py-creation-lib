Scriptname BYOH_TIF__01003DEF Extends TopicInfo

quest Property RelationshipAdoption Auto
referencealias Property Child Auto

Function Fragment_0(ObjectReference akSpeakerRef) Native
String Function GetState() Native
Function GotoState(String newState) Native
