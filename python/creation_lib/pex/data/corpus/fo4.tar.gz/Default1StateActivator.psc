Scriptname Default1StateActivator Extends ObjectReference

String Property Anim Auto Const

Event OnActivate(ObjectReference akActionRef)
EndEvent
