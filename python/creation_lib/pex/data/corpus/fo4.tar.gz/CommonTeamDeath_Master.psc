Scriptname CommonTeamDeath_Master Extends ObjectReference

Int Property stage Auto
quest Property myQuest Auto

Function SetStageOnDeath() Native
