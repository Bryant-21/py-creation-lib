Scriptname BoSMarshalQuestScript Extends Quest

referencealias[] Property BoSMarshalAliases Auto Const

Function BeginRevertingActors() Native
Event OnTimer(Int timerID)
EndEvent

Function RevertActor(actor a) Native
Function RevertActors() Native
