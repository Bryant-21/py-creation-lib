Scriptname AudioContainerNoAnimScript Extends ObjectReference

wwiseevent Property OpenSound Auto
wwiseevent Property CloseSound Auto

Event OnLoad()
EndEvent

Event OnMenuOpenCloseEvent(String asMenuName, Bool abOpening)
EndEvent

Event OnUnload()
EndEvent
