Scriptname AddPowerRequirement Extends ObjectReference

keyword Property LinkToPowerSource Auto
message Property PowerRequiredMessage Auto

Function OnCellLoad() Native
Function OnTimer(Int aiTimerID) Native
Function OnUnload() Native
Function UpdatePowerState() Native
