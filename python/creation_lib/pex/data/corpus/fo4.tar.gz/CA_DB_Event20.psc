Scriptname CA_DB_Event20 Extends ca_dialoguebump_basescript

Function InitializeEventID() Native
