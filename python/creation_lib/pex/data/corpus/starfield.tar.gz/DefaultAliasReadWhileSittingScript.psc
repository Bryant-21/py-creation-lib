Scriptname DefaultAliasReadWhileSittingScript Extends ReferenceAlias

package[] Property ReadingPackages Auto
idle Property IdleBookReadStart Auto

Event OnSit(objectreference akFurniture)
EndEvent
