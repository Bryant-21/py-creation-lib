Scriptname ccOTMFO4001:ccOTMFO4001_QuestScript Extends Quest

Float Property EnclaveHomingBeaconMaxDistance Auto Const
Quest Property ccOTMFO4001_CreationChecker Auto Const
Int Property CurrentBloodMarker Auto
Int Property DisplaySignalMessageActiveStage Auto Const
objectreference Property ccOTMFO4001_AtlanticOfficeElevatorBlocker Auto Const
worldspace Property Commonwealth Auto Const
referencealias Property AtlanticOfficesElevator Auto Const
message Property ccOTMFO4001_EnclaveSignalStrengthMessage Auto Const
referencealias Property Transmitter Auto Const
Quest Property ccOTMFO4001_Radio Auto Const
Int Property EnclaveFieldCampTroops Auto
refcollectionalias Property EnclaveHQKlaxons Auto Const
Float Property EnclaveHomingBeaconRadioFrequency Auto Const
Float Property DistanceFromTransmitterToAdvanceQuest Auto Const
Int Property StageToSetWhenArriving Auto Const
Quest Property ccOTMFO4001_Quest Auto Const

Function ActivateEnclaveKlaxons() Native
Function BloodMarkerTriggered(Int BloodMarkerNumber) Native
Function EnclaveCampSoldierKilled() Native
Function OnDistanceLessThan(objectreference akObj1, objectreference akObj2, Float afDistance) Native
Function OnInit() Native
Function OnQuestInit() Native
Function OnStageSet(Int auiStageID, Int auiItemID) Native
Function OnTimer(Int aiTimerID) Native
Function SetElevatorFunctional(Bool makeFunctional) Native
Function ShutDown() Native
