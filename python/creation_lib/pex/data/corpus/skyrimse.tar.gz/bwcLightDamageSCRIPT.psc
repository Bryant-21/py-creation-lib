Scriptname bwcLightDamageSCRIPT Extends ObjectReference

Bool Property maxDmg Auto
effectshader Property effect Auto

String Function GetState() Native
Function GotoState(String newState) Native
Function ONTRIGGERENTER(ObjectReference ref) Native
Function ONTRIGGERLEAVE(ObjectReference ref) Native
