Scriptname DefaultMessageOnEffectStart Extends ActiveMagicEffect

message Property MessageToShow Auto

Function OnEffectStart(objectreference akTarget, actor akCaster, magiceffect akBaseEffect, Float afMagnitude, Float afDuration) Native
