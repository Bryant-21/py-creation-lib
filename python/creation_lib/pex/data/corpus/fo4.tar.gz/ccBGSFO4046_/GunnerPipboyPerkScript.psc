Scriptname ccBGSFO4046_:GunnerPipboyPerkScript Extends Perk

Struct GunnerStruct
    objectreference GunnerReferences
    terminal GunnerTerminals
EndStruct

keyword Property DataDoneKeyword Auto
gunnerstruct[] Property GunnerStructs Auto
idle Property IdlePipBoyJackIn Auto
message Property NoValDataMessage Auto
actorvalue Property PipBoyActorValue Auto

Function OnEntryRun(Int auiEntryID, objectreference akTarget, actor akOwner) Native
