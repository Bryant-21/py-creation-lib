Scriptname BoS303WarningScript Extends ReferenceAlias

message Property BoS303WarningMessage Auto
globalvariable Property PlayerInstitute_KickedOut Auto
globalvariable Property BoS303BoardGo Auto
globalvariable Property BoS303IngramGoing Auto
quest Property BoS303 Auto
ReferenceAlias Property BoS303Ingram Auto

Function LaunchVertibird() Native
Event OnActivate(objectreference akActionRef)
EndEvent
