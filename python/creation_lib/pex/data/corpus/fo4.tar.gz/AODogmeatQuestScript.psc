Scriptname AODogmeatQuestScript Extends Quest

Int Property StartupStage Auto
Int Property ShutdownStage Auto
globalvariable Property AO_Dogmeat_FindType_GLOBAL Auto
Bool Property ShouldProcessCollection Auto
referencealias Property myActor Auto
referencealias Property myObject Auto
Bool Property StartDistancePolling Auto

Event OnStageSet(Int auiStageID, Int auiItemID)
EndEvent
