Scriptname BHExtBOSEnable Extends ObjectReference

keyword Property LinkCustom01 Auto Const
keyword Property LinkCustom02 Auto Const
Int Property stage Auto Const
quest Property Inst302Combat Auto Const

Event OnTriggerEnter(ObjectReference akActionRef)
EndEvent
