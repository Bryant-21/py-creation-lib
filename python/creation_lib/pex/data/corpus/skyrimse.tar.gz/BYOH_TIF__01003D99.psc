Scriptname BYOH_TIF__01003D99 Extends TopicInfo

Function Fragment_0(ObjectReference akSpeakerRef) Native
String Function GetState() Native
Function GotoState(String newState) Native
