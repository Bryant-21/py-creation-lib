Scriptname AchievementHarderTheyFallScript Extends Actor

quest Property pAchievements Auto Const

Event OnDeath(Actor akKiller)
EndEvent
