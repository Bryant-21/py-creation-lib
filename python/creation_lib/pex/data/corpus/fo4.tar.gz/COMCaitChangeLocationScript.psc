Scriptname COMCaitChangeLocationScript Extends ReferenceAlias

globalvariable Property COMCait_CZComment Auto
location Property CombatZoneLocation Auto

Event OnLocationChange(location akOldLoc, location akNewLoc)
EndEvent
