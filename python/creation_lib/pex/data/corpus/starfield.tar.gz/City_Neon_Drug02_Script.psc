Scriptname City_Neon_Drug02_Script Extends Quest

referencealias Property BayuFurniture Auto
actorvalue Property Assistance Auto
referencealias Property LegrandesLoadDoor Auto
Int Property maxRefills Auto
faction Property PlayerFaction Auto
referencealias Property Alias_IngredientHopper Auto
location Property CityNeonLegrandesLiquorsLocation Auto
cell Property CityNeonLegrandesLiquors Auto
Int Property iStageToMoveBayu Auto
Int Property iStageDoneWithBayu Auto
referencealias Property BenjaminBayu Auto
city_neon_druggamescript Property City_Neon_Drug_Game Auto

Function AddItemsToHopper() Native
Function OnQuestInit() Native
Function ReleasePlayer() Native
Function ReplayGame() Native
