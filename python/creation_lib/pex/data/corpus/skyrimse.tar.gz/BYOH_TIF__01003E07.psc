Scriptname BYOH_TIF__01003E07 Extends TopicInfo

quest Property RelationshipAdoption Auto

Function Fragment_1(ObjectReference akSpeakerRef) Native
String Function GetState() Native
Function GotoState(String newState) Native
