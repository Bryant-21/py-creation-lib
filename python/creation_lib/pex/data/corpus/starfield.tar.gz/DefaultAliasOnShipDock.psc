Scriptname DefaultAliasOnShipDock Extends DefaultAlias

Bool Property SetStageWhenDockingComplete Auto
Int Property WhichShipToCheck Auto

Function OnShipDock(Bool abComplete, spaceshipreference akDocking, spaceshipreference akParent) Native
