Scriptname DefaultAliasOnOpen Extends DefaultAlias

referencealias[] Property TriggeredByAliases Auto
objectreference[] Property TriggeredByReferences Auto
Bool Property PlayerTriggerOnly Auto
faction[] Property TriggeredByFactions Auto

Event OnOpen(objectreference akActionRef)
EndEvent
