Scriptname BYOH_PF_BYOHUrchin_SofieForce_01004029 Extends Package

Function Fragment_0(Actor akActor) Native
String Function GetState() Native
Function GotoState(String newState) Native
