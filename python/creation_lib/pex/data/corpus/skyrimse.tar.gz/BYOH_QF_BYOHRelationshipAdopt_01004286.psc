Scriptname BYOH_QF_BYOHRelationshipAdopt_01004286 Extends Quest

referencealias Property Alias_Constance Auto
referencealias Property Alias_Aventus Auto
referencealias Property Alias_Orphan07 Auto
faction Property RelationshipAdoptableFaction Auto
referencealias Property Alias_Francois Auto
referencealias Property Alias_Orphan03 Auto
referencealias Property Alias_Samuel Auto
referencealias Property Alias_Orphan02 Auto
referencealias Property Alias_Orphan06 Auto
referencealias Property Alias_Runa Auto
referencealias Property Alias_Orphan05 Auto
referencealias Property Alias_Hroar Auto
Bool Property AllowOrphanageAdoption Auto
referencealias Property Alias_Orphan04 Auto
referencealias Property Alias_Orphan01 Auto

Function Fragment_0() Native
Function Fragment_1() Native
Function Fragment_2() Native
Function Fragment_3() Native
Function Fragment_4() Native
Function Fragment_6() Native
String Function GetState() Native
Function GotoState(String newState) Native
