Scriptname DLC03:SFTA00AliasHannibalScannedScript Extends ReferenceAlias

Int Property StageToSetOnScanned Auto
actorvalue Property SFBGS003_SQ_Bounty_isScannedAV Auto

Function OnLoad() Native
Function OnScanned() Native
