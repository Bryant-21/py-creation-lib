Scriptname BoS202Quest Extends Quest

referencealias Property BoS202BehemothAlias Auto Const
inputenablelayer Property EnableLayer Auto
