Scriptname DefaultRefMapMarkerOnDiscoveryScript Extends ObjectReference

Bool Property VisibleOnStarMap Auto
Int Property MapMarkerCategory Auto
Int Property MapMarkerType Auto

Function OnMapMarkerDiscovered() Native
