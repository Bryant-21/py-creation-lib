Scriptname ArenaWagerFighterQuestScript Extends Quest

referencealias Property Fighter Auto

String Function GetState() Native
Function GotoState(String newState) Native
