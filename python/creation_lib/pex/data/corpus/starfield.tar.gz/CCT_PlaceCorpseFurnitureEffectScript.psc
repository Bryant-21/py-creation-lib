Scriptname CCT_PlaceCorpseFurnitureEffectScript Extends ActiveMagicEffect

furniture Property CreatureCorpseFeed Auto
Float Property markerOffset Auto
Float Property fDelay Auto
conditionform Property CCT_IsFlier Auto
keyword Property ActorTypePredator Auto
furniture Property CreatureCorpseFeed_Flyer Auto

Function OnEffectStart(objectreference akTarget, actor akCaster, magiceffect akBaseEffect, Float afMagnitude, Float afDuration) Native
Function OnTimer(Int aiTimerID) Native
