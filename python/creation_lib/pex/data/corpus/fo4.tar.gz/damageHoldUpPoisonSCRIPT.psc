Scriptname damageHoldUpPoisonSCRIPT Extends ActiveMagicEffect

refcollectionalias Property victimAliasCollection Auto
keyword Property AnimFlavorHandsup Auto
actorvalue Property pHoldupCommandAV Auto
magiceffect Property pHoldupEffect Auto
globalvariable Property holdupDistanceGlobal Auto
quest Property holdupquest Auto
actorvalue Property Assistance Auto
actorvalue Property Morality Auto
actorvalue Property pHoldupFleeAV Auto
scene Property pHoldupScene Auto
referencealias Property VictimAlias Auto
actorvalue Property pHoldupAV Auto

Event OnCombatStateChanged(actor akTarget, Int aeCombatState)
EndEvent

Event OnEffectFinish(actor akTarget, actor akCaster)
EndEvent

Event OnEffectStart(actor akTarget, actor akCaster)
EndEvent
