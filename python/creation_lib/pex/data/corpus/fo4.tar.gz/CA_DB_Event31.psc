Scriptname CA_DB_Event31 Extends ca_dialoguebump_basescript

Function InitializeEventID() Native
