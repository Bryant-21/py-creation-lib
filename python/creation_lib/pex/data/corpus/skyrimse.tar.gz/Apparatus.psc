Scriptname Apparatus Extends MiscObject

String Function GetState() Native
Function GotoState(String newState) Native
