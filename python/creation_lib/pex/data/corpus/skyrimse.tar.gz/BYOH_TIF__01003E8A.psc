Scriptname BYOH_TIF__01003E8A Extends TopicInfo

referencealias Property Aventus Auto
referencealias Property Francois Auto
referencealias Property Hroar Auto
referencealias Property Samuel Auto
quest Property RelationshipAdoptableOrphanage Auto
referencealias Property Runa Auto

Function Fragment_0(ObjectReference akSpeakerRef) Native
String Function GetState() Native
Function GotoState(String newState) Native
