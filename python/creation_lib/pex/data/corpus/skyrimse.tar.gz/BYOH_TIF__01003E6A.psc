Scriptname BYOH_TIF__01003E6A Extends TopicInfo

quest Property RelationshipAdoption Auto

Function Fragment_0(ObjectReference akSpeakerRef) Native
String Function GetState() Native
Function GotoState(String newState) Native
