Scriptname BoSKickOutDanseCustomScript Extends ReferenceAlias

quest Property BoSKickOut Auto Const
quest Property BOS302 Auto Const

Event OnDying(actor akKiller)
EndEvent
