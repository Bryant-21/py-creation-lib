Scriptname DefaultRefOnCombatStateChanged Extends DefaultActor

Bool Property IncludeOnHitEvent Auto
Int Property CombatStateToCheckFor Auto

Function CombatStateChangedOrHit(objectreference TargetOrAggressor) Native
Event OnCombatStateChanged(objectreference akTarget, Int aeCombatState)
EndEvent

Function OnHit(objectreference akTarget, objectreference akAggressor, form akSource, projectile akProjectile, Bool abPowerAttack, Bool abSneakAttack, Bool abBashAttack, Bool abHitBlocked, String asMaterialName) Native
Function OnLoad() Native
Function OnUnload() Native
