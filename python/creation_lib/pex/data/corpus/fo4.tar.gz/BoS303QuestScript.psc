Scriptname BoS303QuestScript Extends Quest

referencealias Property Alias_Vertibird Auto Const
referencealias Property Alias_Dogmeat Auto Const
referencealias Property Alias_Companion Auto Const
inputenablelayer Property EnableLayer Auto
globalvariable Property PlayerHasActiveDogmeatCompanion Auto Const
globalvariable Property PlayerHasActiveCompanion Auto Const

Function AllAboard() Native
