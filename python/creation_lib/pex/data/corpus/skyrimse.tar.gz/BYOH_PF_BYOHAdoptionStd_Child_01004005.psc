Scriptname BYOH_PF_BYOHAdoptionStd_Child_01004005 Extends Package

globalvariable Property GameHour Auto

Function Fragment_0(Actor akActor) Native
String Function GetState() Native
Function GotoState(String newState) Native
