Scriptname DefaultEnableRefOnLoadOrReset Extends ObjectReference

Bool Property ShouldFadeIn Auto
Bool Property EnableOnLoad Auto
Bool Property EnableOnReset Auto

Event OnLoad()
EndEvent

Event OnReset()
EndEvent
