Scriptname BoS101ArcJet02OverrideTriggerScript Extends ObjectReference

quest Property BoS101 Auto Const
referencealias Property BoS101_Danse Auto Const
ObjectReference Property BoS101QSDanseMarker Auto Const
cell Property ArcjetSystems02 Auto Const

Event OnTriggerEnter(ObjectReference akActionRef)
EndEvent
