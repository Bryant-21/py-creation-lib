Scriptname BobbleheadSkillScript Extends ObjectReference

perk Property PerkToAdd Auto

Event OnActivate(ObjectReference akActionRef)
EndEvent
