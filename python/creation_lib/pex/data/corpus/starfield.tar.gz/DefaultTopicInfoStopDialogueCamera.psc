Scriptname DefaultTopicInfoStopDialogueCamera Extends TopicInfo

Bool Property StopCameraOnBegin Auto

Event OnBegin(objectreference akSpeakerRef, Bool abHasBeenSaid)
EndEvent

Event OnEnd(objectreference akSpeakerRef, Bool abHasBeenSaid)
EndEvent
