Scriptname CA_QuestScript Extends Quest

Struct EventDatum
    Int Stage
    Bool Optional_CheckCompanionProximity
    objectreference Optional_Target
    keyword EventKeyword
    globalvariable Optional_Size
    Float ResponseDelay
EndStruct

Int Property Stage Auto
Bool Property Optional_CheckCompanionProximity Auto
objectreference Property Optional_Target Auto
keyword Property EventKeyword Auto
eventdatum[] Property EventData Auto
globalvariable Property Optional_Size Auto
Float Property ResponseDelay Auto

Event OnStageSet(Int auiStageID, Int auiItemID)
EndEvent
