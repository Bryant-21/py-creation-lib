Scriptname BoS101QuestScript Extends Quest

leveleditem Property LL_Armor_Power_T60_Set_BOSPaladin_HelmetOnly Auto
referencealias Property BoS101Danse Auto
Quest Property BoS101 Auto

Event OnAnimationEvent(objectreference akSource, String asEventName)
EndEvent

Function RegisterMe() Native
