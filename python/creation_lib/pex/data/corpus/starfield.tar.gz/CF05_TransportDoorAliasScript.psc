Scriptname CF05_TransportDoorAliasScript Extends ReferenceAlias

key Property KeyToCheck Auto
Int Property iNoKeyStage Auto
Int Property iHasKeyStage Auto

Function OnActivate(objectreference akActionRef) Native
