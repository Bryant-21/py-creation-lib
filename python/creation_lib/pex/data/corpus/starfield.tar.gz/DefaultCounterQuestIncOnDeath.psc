Scriptname DefaultCounterQuestIncOnDeath Extends ReferenceAlias

Bool Property CheckForOnDyingInstead Auto
Bool Property SupportRespawning Auto

Function Increment() Native
Event OnDeath(objectreference akKiller)
EndEvent

Event OnDying(objectreference akKiller)
EndEvent
