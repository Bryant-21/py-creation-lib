Scriptname DefaultAliasSetAVOnDeath Extends ReferenceAlias

actorvalue Property AVToSet Auto
Bool Property ShowTraces Auto
Float Property AVNewValue Auto
Bool Property UseOnDying Auto
Bool Property SetAVOnKiller Auto

Function OnDeath(objectreference akKiller) Native
Function OnDying(objectreference akKiller) Native
Function ProcessDeathEvent(objectreference akKiller) Native
