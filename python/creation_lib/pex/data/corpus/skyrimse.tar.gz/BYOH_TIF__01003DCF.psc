Scriptname BYOH_TIF__01003DCF Extends TopicInfo

miscobject Property Gold001 Auto
message Property FavorJobsBeggarMessage Auto
spell Property FavorJobsBeggarsAbility Auto
quest Property RelationshipAdoption Auto

Function Fragment_0(ObjectReference akSpeakerRef) Native
String Function GetState() Native
Function GotoState(String newState) Native
