Scriptname BHIntCombatSetup Extends ObjectReference

globalvariable Property BHIntCombatDoonce Auto
keyword Property LinkCustom03 Auto Const
faction Property PlayerFaction Auto Const
keyword Property LinkCustom02 Auto Const
faction Property BunkerHillRRFaction Auto Const
faction Property BunkerHillBoSFaction Auto Const
keyword Property LinkCustom01 Auto Const
faction Property BunkerHillInstituteFaction Auto Const

Function LoadBattle() Native
Event OnTriggerEnter(ObjectReference akActionRef)
EndEvent
