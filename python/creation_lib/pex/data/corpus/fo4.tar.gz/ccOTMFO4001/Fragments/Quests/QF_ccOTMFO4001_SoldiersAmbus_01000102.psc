Scriptname ccOTMFO4001:Fragments:Quests:QF_ccOTMFO4001_SoldiersAmbus_01000102 Extends Quest

Quest Property ccOTMFO4001_Quest Auto

Function Fragment_Stage_0000_Item_00() Native
Function Fragment_Stage_0005_Item_00() Native
Function Fragment_Stage_0010_Item_00() Native
Function Fragment_Stage_0020_Item_00() Native
Function Fragment_Stage_0100_Item_00() Native
Function Fragment_Stage_1000_Item_00() Native
