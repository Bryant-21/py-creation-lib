Scriptname BEBlockPilotSeatScriptObjRef Extends ObjectReference

message Property PilotSeatNotAuthorizedMessage Auto

Function OnActivate(ObjectReference akActivator) Native
Function OnInit() Native
