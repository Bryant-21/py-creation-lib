Scriptname CityCYRedTape02ShipScript Extends ReferenceAlias

actorvalue Property ShipSystemEngineHealth Auto
actorvalue Property ShipSystemGravDriveHealth Auto

Function OnLoad() Native
