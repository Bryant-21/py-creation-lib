Scriptname Crew_LeadershipScript Extends Actor

actorvalue Property CrewSlotCost Auto
Int Property CrewSlotCostValue Auto

Function OnInit() Native
