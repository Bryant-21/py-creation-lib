Scriptname DefaultAliasOnShipTakeOff Extends DefaultAliasParent

location[] Property LocationsToCheckAgainst Auto
Bool Property SetStageWhenTakeOffComplete Auto
Bool Property LocationMatchIfChild Auto
locationalias[] Property LocationAliasesToCheckAgainst Auto

locationalias[] Function GetLocationAliasesToCheckAgainst() Native
Bool Function GetLocationMatchIfChild() Native
location[] Function GetLocationsToCheckAgainst() Native
Function OnShipTakeOff(Bool abComplete) Native
