Scriptname BladesOnUnloadScript Extends ReferenceAlias

String Function GetState() Native
Function GotoState(String newState) Native
Function OnUnload() Native
