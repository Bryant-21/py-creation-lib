Scriptname BoSPoliceStationChangeLocationScript Extends ReferenceAlias

quest Property BoSScene_PoliceStation Auto Const
Int Property iStageToSet Auto Const
ReferenceAlias Property PASoldier Auto Const
ReferenceAlias Property FieldScribe Auto Const
location Property CambridgePDLocation Auto Const
Int Property iPrereqStage Auto Const

Event OnLocationChange(location akOldLoc, location akNewLoc)
EndEvent
