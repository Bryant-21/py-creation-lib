Scriptname ccBGSFO4046_:Fragments:Quests:QF_ccBGSFO4046_BestOfThree_01000846 Extends Quest

actorbase[] Property CreaturesToPlace Auto Const
perk Property GunnerPerk Auto Const
leveleditem Property TesCanLeveledItem Auto Const
formlist Property ModListScrap Auto Const
Quest Property VaultTecTransmitter Auto Const
Int Property IntLevel Auto Const
projectile[] Property TesCanProjectile Auto Const
form Property TesCanWeapon Auto Const
actor Property GunnerThreeRef Auto Const
referencealias Property TeslaCannonAlias Auto Const
formlist Property TrapExplOnHit Auto Const
Quest Property GunnerSignal Auto Const
leveleditem[] Property npclists Auto Const
formlist Property TrapExplGasWeapon Auto Const
objectreference Property GunnerCaroniREF Auto Const

Function Fragment_Stage_0002_Item_00() Native
Function Fragment_Stage_0005_Item_00() Native
Function Fragment_Stage_0006_Item_00() Native
Function Fragment_Stage_0007_Item_00() Native
Function Fragment_Stage_0010_Item_00() Native
Function Fragment_Stage_0015_Item_00() Native
Function Fragment_Stage_0018_Item_00() Native
Function Fragment_Stage_0020_Item_00() Native
Function Fragment_Stage_0022_Item_00() Native
Function Fragment_Stage_0025_Item_00() Native
Function Fragment_Stage_0030_Item_00() Native
