Scriptname CA_DB_Event19 Extends ca_dialoguebump_basescript

Function InitializeEventID() Native
