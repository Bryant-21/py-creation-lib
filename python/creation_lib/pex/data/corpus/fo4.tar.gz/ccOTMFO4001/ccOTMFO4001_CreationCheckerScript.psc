Scriptname ccOTMFO4001:ccOTMFO4001_CreationCheckerScript Extends Quest

Struct EnclaveCreationStruct
    globalvariable HasCompletedCreationGlobal
    Int QuestFormID
    String PluginName
    Int QuestCompletionStage
    globalvariable HasCreationGlobal
EndStruct

Struct EnclaveArmorStruct
    Int ID
    armor ArmorPiece
    objectmod PaintJob
EndStruct

Struct EnclaveQuestStruct
    Quest QuestToTrack
    Int QuestCompletionStage
    globalvariable HasCompletedCreationGlobal
EndStruct

Struct EnclaveArmorAllExternalStruct
    Int PaintJobFormID
    Int ID
    Int ArmorPieceFormID
    String PluginName
    globalvariable HasCreationGlobal
EndStruct

Struct EnclaveHellfireActorBaseStruct
    Int Level
    Bool IsHellfire
    actorbase Soldier
    Bool IsLegendary
EndStruct

Struct EnclaveArmorExternalPaintStruct
    Int PaintJobFormID
    Int ID
    armor ArmorPiece
    String PluginName
    globalvariable HasCreationGlobal
EndStruct

enclavehellfireactorbasestruct[] Property EnclaveHellfireActorBases Auto
leveledactor Property ccOTMFO4001_LCharEnclaveHellfireTrooperPowerArmorLegendary Auto
enclavearmorexternalpaintstruct[] Property EnclaveArmor_ExternalPaint Auto
faction Property ccOTMFO4001_EnclaveFaction Auto
Quest Property ccOTMFO4001_Quest Auto
leveledactor Property ccOTMFO4001_LCharEnclaveHellfireTrooperPowerArmor Auto
enclavearmorallexternalstruct[] Property EnclaveArmor_AllExternal Auto
faction Property PlayerFaction Auto
globalvariable Property ccOTMFO4001_HasCompletedCreationGeneric Auto
Quest Property ccOTMFO4001_SoldiersAmbushPlayer Auto
enclavearmorstruct[] Property EnclaveArmorSets Auto
globalvariable Property ccOTMFO4001_HasCreationEnclaveCombatPaintJobs_Excluded Auto
globalvariable Property ccOTMFO4001_HasCreationGeneric Auto
Float Property HoursToWaitForAmbush Auto
enclavecreationstruct[] Property Creations Auto

Function CheckForCreationCompletionStates() Native
Function CheckForCreations() Native
Function OnInit() Native
Function OnTimerGameTime(Int aiTimerID) Native
Function PrepareHellfireLChars(Bool AddHellfireSoldiers) Native
Function SetUpEnclaveArmorSets() Native
Function TryToAddToEnclaveArmorSet(armor ArmorPiece, objectmod PaintJob, Int ID) Native
