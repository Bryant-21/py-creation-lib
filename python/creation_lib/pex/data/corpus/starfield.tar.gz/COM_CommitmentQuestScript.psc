Scriptname COM_CommitmentQuestScript Extends Quest

referencealias Property CompanionAlias Auto
Quest Property SQ_Companions Auto
miscobject Property CommitmentGift Auto
referencealias Property CommitmentGiftAlias Auto

Function GiveCommitmentGift() Native
Function MakeCommitted() Native
