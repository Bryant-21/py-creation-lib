Scriptname AliasTargetingScopeScript Extends ReferenceAlias

magiceffect Property TargetingScopeEquippedEffect Auto
keyword Property HasScopeTargeting Auto
spell Property TargetingScopeSpell Auto

Event OnItemEquipped(form akBaseObject, objectreference akReference)
EndEvent

Event OnItemUnequipped(form akBaseObject, objectreference akReference)
EndEvent

Event OnTimer(Int aiTimerID)
EndEvent
