Scriptname BlackreachLockScript Extends ObjectReference

String Property openAnim Auto
ObjectReference Property DweBREntranceStair Auto
message Property LackTheItem Auto
Bool Property isAnimating Auto
miscobject Property DwarvenKey Auto

String Function GetState() Native
Function GotoState(String newState) Native
Function onActivate(ObjectReference triggerRef) Native
Function SetOpen(Bool abOpen) Native
