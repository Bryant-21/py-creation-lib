Scriptname CZKillAliasScript Extends ReferenceAlias

Int Property StageToSetOnDeath Auto
Bool Property Decapitate Auto
Int Property StageToDie Auto
Float Property MaxAliveTime Auto
ReferenceAlias Property Killer Auto
Bool Property KillAfterNextOnHit Auto

Event OnAliasInit()
EndEvent

Event OnDeath(actor akKiller)
EndEvent

Event OnHit(objectreference akTarget, objectreference akAggressor, form akSource, projectile akProjectile, Bool abPowerAttack, Bool abSneakAttack, Bool abBashAttack, Bool abHitBlocked, String asMaterialName)
EndEvent

Event OnTimer(Int aiTimerID)
EndEvent
