Scriptname BoSVertibirdSmokeGrenadeScript Extends ObjectReference

message Property VFTDispatchMessage Auto
keyword Property BoSVertibirdGrenadeKW Auto
message Property VFTNoLandingMessage Auto
globalvariable Property BoSFastTravelCanUse Auto
quest Property VFT Auto
message Property VFTInProgressMessage Auto

Event OnInit()
EndEvent
