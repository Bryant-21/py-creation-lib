Scriptname BYOH_TIF__01003DEA Extends TopicInfo

referencealias Property Samuel Auto
quest Property RelationshipAdoptableOrphanage Auto
referencealias Property Hroar Auto
referencealias Property Runa Auto
referencealias Property Aventus Auto
referencealias Property Francois Auto

Function Fragment_0(ObjectReference akSpeakerRef) Native
String Function GetState() Native
Function GotoState(String newState) Native
