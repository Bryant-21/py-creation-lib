Scriptname DefaultAliasSetTimestampOnInit Extends ReferenceAlias

actorvalue Property TimestampAV Auto
Float Property TimestampOffset Auto

Function OnAliasInit() Native
