Scriptname barredDoor Extends objectReference

Bool Property busy Auto
sound Property barredSFX Auto
Bool Property barred Auto
message Property UnlockMeMSG Auto
message Property BarredMSG Auto

String Function GetState() Native
Function GotoState(String newState) Native
Function onActivate(objectReference actronaut) Native
Function onCellLoad() Native
