Scriptname CZCrowdOnBeginTIF Extends TopicInfo

action Property ActionCustomCheering Auto Const
Bool Property laugh Auto Const
action Property ActionCustomLaughing Auto Const
action Property ActionCustomBooing Auto Const
Bool Property cheer Auto Const

Event OnBegin(objectreference akSpeakerRef, Bool abHasBeenSaid)
EndEvent
