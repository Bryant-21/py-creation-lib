Scriptname BoS202VBirdScript Extends ReferenceAlias

action Property ActionPropellersOn Auto
action Property ActionPropellersOff Auto

Event OnLoad()
EndEvent
