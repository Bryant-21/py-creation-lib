Scriptname AlftandBlackreachLockScript Extends BlackreachLockScript

Bool Property isOpen Auto

String Function GetState() Native
Function GotoState(String newState) Native
