Scriptname Armor Extends Form

String Function GetState() Native
Float Function GetWarmthRating() Native
Function GotoState(String newState) Native
