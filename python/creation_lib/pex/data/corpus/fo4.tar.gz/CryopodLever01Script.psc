Scriptname CryopodLever01Script Extends ObjectReference

Bool Property IsPlayersPod Auto

Event OnActivate(ObjectReference akActionRef)
EndEvent

Event OnLoad()
EndEvent

Event OnOpen(ObjectReference akActionRef)
EndEvent
