Scriptname BQScript Extends Quest

Int Property RewardAmount Auto
miscobject Property Gold001 Auto
keyword Property BQActiveQuest Auto
locationalias Property Hold Auto
locationalias Property Alias_Location Auto

String Function GetState() Native
Function GotoState(String newState) Native
Function PlayerChangedLocation() Native
Function RewardPlayer() Native
