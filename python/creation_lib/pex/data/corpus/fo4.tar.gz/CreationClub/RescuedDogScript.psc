Scriptname CreationClub:RescuedDogScript Extends ObjectReference

idle Property Dogmeat_Neutral_ToyShake Auto Const
miscobject Property TeddyBear Auto Const
referencealias Property CurrentName Auto

Event OnInit()
EndEvent

Event OnWorkshopNPCTransfer(location akNewWorkshop, keyword akActionKW)
EndEvent
