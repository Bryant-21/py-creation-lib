Scriptname AssaultronRaceScript Extends ActiveMagicEffect

keyword Property LinkAssaultronPad Auto Const

Event OnActivate(objectreference akActionRef)
EndEvent

Event OnEffectStart(actor akTarget, actor akCaster)
EndEvent
