Scriptname DefaultCollectionSetGroupFaction Extends RefCollectionAlias

faction Property GroupFaction Auto
Bool Property ShowTraces Auto

Function OnAliasChanged(objectreference akObject, Bool abRemove) Native
Function OnAliasInit() Native
Function SetGroupFaction(actor actorToUpdate) Native
Function SetGroupFactionOnAll() Native
