Scriptname ActivateLinkedChestDummyScript Extends ObjectReference

String Function GetState() Native
Function GotoState(String newState) Native
Function onActivate(ObjectReference actronaut) Native
