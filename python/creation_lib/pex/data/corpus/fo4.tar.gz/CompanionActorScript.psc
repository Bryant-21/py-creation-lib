Scriptname CompanionActorScript Extends Actor

Struct ThresholdData
    message ThresholdMessage
    quest Controlling_Quest
    globalvariable AffinitySceneToPlay_FirstTimeReached
    Bool IsMajorAffinityThreshold
    globalvariable Threshold_Global
    Bool ThresholdHasBeenPreviouslyReached
    globalvariable AffinitySceneToPlay_Repeat_GoingUp
    globalvariable AffinitySceneToPlay_Repeat_GoingDown
    Int Controlling_Quest_Stage
    globalvariable ConditionalGlobal
EndStruct

Struct MurderThresholdData
    Float AffinityPenalty
    Int MaxVictimsAllowed
    Int StageToSet
    quest QuestToSet
EndStruct

Struct EventData
    globalvariable Disposition_Global
    keyword Event_Keyword
    globalvariable ConditionalGlobal
    message Message_to_Display
EndStruct

Struct TraitPreference
    Bool Likes
    actorvalue Trait
EndStruct

keyword Property DislikesEvent Auto Const
thresholddata[] Property ThresholdData_Array Auto
Bool Property ShouldGivePlayerItems Auto
perk Property InfatuationPerk Auto Const
actorvalue Property TemporaryAngerLevel Auto Const
quest Property Tutorial Auto Const
message Property InfatuationRomanticMessage Auto Const
murderthresholddata[] Property MurderThreshold_Array Auto Const
message Property InfatuationPerkMessage Auto Const
keyword Property CA_Event_Murder Auto Const
formlist Property ConsideredMurderFactionList Auto Const
globalvariable Property InfatuationThreshold Auto Const
globalvariable Property MurderToggle Auto Const
leveleditem Property ItemToGive Auto Const
scene Property DismissScene Auto Const
traitpreference[] Property TraitPreference_Array Auto Const
globalvariable Property StartingThreshold Auto Const
Float Property MinAffinity Auto Const
keyword Property LikesEvent Auto Const
actorvalue Property Experience Auto Const
globalvariable Property MQComplete Auto Const
Int Property MinAffinityChangeFromLastThresholdCrossedRequired Auto Const
Int Property BodyCountAllowedBeforeMurderSession Auto Const
keyword Property HatesEvent Auto Const
Float Property MaxAffinity Auto Const
topic Property IdleTopic Auto Const
faction[] Property NotConsideredMurder_Array Auto
thresholddata[] Property CustomThresholdData_Array Auto
formlist Property DismissCompanionSettlementKeywordList Auto Const
globalvariable Property AllowDismissToSettlements Auto Const
eventdata[] Property EventData_Array Auto Const
actorvalue Property HasItemForPlayer Auto Const
location Property HomeLocation Auto
keyword[] Property KeywordsToAddWhileCurrentCompanion Auto
keyword Property LovesEvent Auto Const

Function AddThresholdToQueueAndSetSceneToPlay(thresholddata ThresholdToQueue, Float NewAffinity) Native
Function AffinitySceneFinished(Actor ActorToSet) Global Native
Function AffinitySceneForceGreeted(Actor ActorToSet) Global Native
Function CheckAffinityAndSetThresholdAndStage(Float NewAffinity, thresholddata ClosestThresholdData) Native
Function EndMurderSession() Native
Function FinishedSceneRemoveThresholdFromQueueAndSetSceneToPlay(globalvariable RelatedThreshold_Global) Native
Float Function GetAffinityModifyValue(eventdata EventDataToUse, globalvariable EventSize) Native
thresholddata Function GetClosestThresholdData(Float NewAffinity, thresholddata[] ThresholdDataArray) Native
eventdata Function GetEventDataByKeyword(eventdata[] ArrayToSearch, keyword KeywordToFind) Native
thresholddata Function GetNextLockedThreshold(Bool GetNextLockedPositiveThreshold = true) Native
thresholddata Function GetNextThreshold(Bool GetNextInThePositiveDirection = true) Native
thresholddata Function GetThresholdDataForThresholdGlobal(globalvariable ThresholdGlobalToFind) Native
Float Function GetWithPlayerAffinityGain() Native
Function GivePlayerItem() Native
Function HandleHasItemForPlayerTimer() Native
Function HandleWithPlayer() Native
Bool Function IsInfatuated() Native
Bool Function isMurder(Actor ActorVictim, Bool GameConsidersMurder) Native
Bool Function isPlayerNearby() Native
Bool Function IsRomantic() Native
Bool Function IsThresholdChanging(globalvariable ClosestThreshold, Float NewAffinity) Native
Function ModAffinity(Float Amount) Native
Function MurderSession(Actor ActorVictim, Actor ActorKiller) Native
Function NewMurderSession() Native
Event OnCompanionDismiss()
EndEvent

Event OnDeath(Actor akKiller)
EndEvent

Event OnInit()
EndEvent

Event OnTimer(Int aiTimerID)
EndEvent

Event OnTimerGameTime(Int aiTimerID)
EndEvent

Function ProcessMurderThreshold(Int Threshold) Native
Function RomanceDeclined(Bool isPermanent = false) Native
Function RomanceFail() Native
Function RomanceSuccess() Native
Function SayLastDialogueBumpLine() Native
Function SetAffinity(Float Amount) Native
Function SetAffinityBetweenThresholds(globalvariable ThresholdA, globalvariable ThresholdB) Native
Function SetAffinityTowardNextLowestThreshold(Float percentageBetweenCurrentAffinityValueAndNextLowestThreshold = 0.50) Native
Function SetHasLeftPlayerPermanently() Native
Function SetLastDialogueBump(globalvariable LastDialogueBumpToSet) Native
Function SetQueuedThresholdSceneToPlay() Native
Function setStageBasedOnThresholdData(thresholddata ThresholdDataToUse) Native
Function SetTemporaryAngerLevel(Bool isReallyAngry = false) Native
Function ShowRomanticInfatuationMessage() Native
Function ShowThresholdMessage(globalvariable ThresholdGlobal) Native
Function SortThesholdDataArray(thresholddata[] ThresholdDataArray) Native
Function StartHasItemTimer() Native
Function StartRomanceTalkTimer(Float interval) Native
Bool Function TestEventForAffinityBump(keyword EventToTest, globalvariable ThresholdToTestFor = none) Native
Bool Function TestValueForAffinityBump(Float ModifyValueToTest, globalvariable ThresholdToTestFor = none) Native
Function TraceAffinityStats() Native
Function TryToModAffinity(eventdata EventDataToUse, globalvariable EventSize) Native
Function TryToSayCustomTopic(keyword TopicKeyword, objectreference Target = None) Native
Function TryToSetTraitValues(actorvalue TraitToFind, globalvariable EventSize, Bool ShouldAlsoSetAffinity = false) Native
Function TryToShowMessage(eventdata EventDataToUse) Native
Function UnlockInfatuationPerk() Native
Function UnsetHasLeftPlayerPermanently() Native
