Scriptname DefaultAliasOnSit Extends DefaultAlias

message Property NotAllowedDuringCombat Auto
Bool Property AllowDuringCombat Auto
referencealias Property SitTarget Auto

Function OnSit(objectreference akFurniture) Native
