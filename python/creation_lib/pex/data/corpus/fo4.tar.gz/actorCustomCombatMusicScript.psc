Scriptname actorCustomCombatMusicScript Extends Actor

musictype Property mySpecialMusic Auto
Bool Property bStartedMyMusic Auto

Event OnCombatStateChanged(Actor akTarget, Int aeCombatState)
EndEvent

Event OnDeath(Actor akKiller)
EndEvent

Event OnUnload()
EndEvent
