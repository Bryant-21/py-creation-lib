Scriptname CA_DialogueBump_TopicInfoScript Extends TopicInfo

String Property Description Auto
keyword[] Property CA_CustomEvents Auto
