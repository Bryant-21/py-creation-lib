Scriptname BoS101DOTriggerScript Extends ObjectReference

ObjectReference Property BoS101OTMarker Auto
referencealias Property BoS101Danse Auto
cell Property ArcjetSystems01 Auto
quest Property BoS101 Auto

Event OnTriggerEnter(ObjectReference akActionRef)
EndEvent
