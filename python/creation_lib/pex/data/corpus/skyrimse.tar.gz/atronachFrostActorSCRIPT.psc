Scriptname atronachFrostActorSCRIPT Extends actor

effectshader Property AtronachFrostFXS Auto
spell Property frostBurst Auto
spell Property FrostSpell Auto

String Function GetState() Native
Function GotoState(String newState) Native
Function onAnimationEVENT(objectreference deliverator, String eventName) Native
Function onDeath(actor myKiller) Native
Function onLoad() Native
