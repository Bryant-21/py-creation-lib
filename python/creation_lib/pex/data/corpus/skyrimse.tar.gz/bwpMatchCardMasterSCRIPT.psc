Scriptname bwpMatchCardMasterSCRIPT Extends ObjectReference

Int Property flippedCard Auto

String Function GetState() Native
Function GotoState(String newState) Native
