Scriptname BYOH_TIF__01003D87 Extends TopicInfo

quest Property RelationshipAdoptableOrphanage Auto
referencealias Property Samuel Auto
referencealias Property Aventus Auto
referencealias Property Francois Auto
referencealias Property Hroar Auto
referencealias Property Runa Auto

Function Fragment_0(ObjectReference akSpeakerRef) Native
String Function GetState() Native
Function GotoState(String newState) Native
