Scriptname DefaultAliasOnShipGravJump Extends DefaultAliasParent

location[] Property LocationsToCheckAgainst Auto
Bool Property CheckDestinationLocation Auto
Bool Property SetStageIfJumpingFails Auto
Bool Property SetStageWhenJumpingComplete Auto
Bool Property LocationMatchIfChild Auto
locationalias[] Property LocationAliasesToCheckAgainst Auto

locationalias[] Function GetLocationAliasesToCheckAgainst() Native
Bool Function GetLocationMatchIfChild() Native
location[] Function GetLocationsToCheckAgainst() Native
Function OnShipGravJump(location aDestination, Int aState) Native
