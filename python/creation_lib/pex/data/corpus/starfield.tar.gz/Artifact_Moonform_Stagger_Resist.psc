Scriptname Artifact_Moonform_Stagger_Resist Extends ActiveMagicEffect

perk Property StaggerResist_Perk Auto

Function OnEffectFinish(objectreference akTarget, actor akCaster, magiceffect akBaseEffect, Float afMagnitude, Float afDuration) Native
Function OnEffectStart(objectreference akTarget, actor akCaster, magiceffect akBaseEffect, Float afMagnitude, Float afDuration) Native
