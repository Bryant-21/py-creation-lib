Scriptname CF05_GuardTriggerAliasScript Extends ReferenceAlias

scene Property CF05_1000_CargoBayGuard01_TeleportPlayer Auto
ReferenceAlias Property GuardAliasToCheck Auto
armor Property UniformToCheck Auto
Int Property iStageDone Auto
scene Property GuardSceneToPlay Auto
Int Property iStageToCheck Auto
Bool Property CheckStage Auto

Function OnTriggerEnter(objectreference akActionRef) Native
