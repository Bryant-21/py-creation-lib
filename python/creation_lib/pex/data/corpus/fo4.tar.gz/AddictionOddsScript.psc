Scriptname AddictionOddsScript Extends ActiveMagicEffect

actorvalue Property TrackingActorValue Auto Const
Float Property Magnitude Auto

Event OnEffectStart(actor akTarget, actor akCaster)
EndEvent
