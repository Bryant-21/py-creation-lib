Scriptname City_AkilaLife05Script Extends Quest

actorvalue Property ProduceUses Auto
refcollectionalias Property RocksCollection Auto
globalvariable Property AkilaLife05_RocksCurrent Auto
Int Property RockTotal Auto
Int Property RockCurrent Auto

Function OnActorValueLessThan(objectreference akObjRef, actorvalue akActorValue) Native
Function OnQuestStarted() Native
Function RegisterRocks() Native
