Scriptname AODogmeatQuestScript Extends Quest

Int Property StartupStage Auto Const
Int Property ShutdownStage Auto Const
globalvariable Property AO_Dogmeat_FindType_GLOBAL Auto Const
Bool Property ShouldProcessCollection Auto Const
referencealias Property myActor Auto Const
referencealias Property myObject Auto Const
Bool Property StartDistancePolling Auto Const

Event OnStageSet(Int auiStageID, Int auiItemID)
EndEvent
