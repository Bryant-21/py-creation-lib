Scriptname ccBGSFO4046_:GunnerPipboyPerkScript Extends Perk

Struct GunnerStruct
    objectreference GunnerReferences
    terminal GunnerTerminals
EndStruct

keyword Property DataDoneKeyword Auto Const
gunnerstruct[] Property GunnerStructs Auto Const
idle Property IdlePipBoyJackIn Auto Const
message Property NoValDataMessage Auto Const
actorvalue Property PipBoyActorValue Auto Const

Function OnEntryRun(Int auiEntryID, objectreference akTarget, actor akOwner) Native
