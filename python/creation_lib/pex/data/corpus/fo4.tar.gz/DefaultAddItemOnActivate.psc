Scriptname DefaultAddItemOnActivate Extends ObjectReference

form Property ItemToGive Auto
Bool Property bDisableWhenDone Auto
Int Property iNumberToGiveMax Auto
Int Property iNumberToGiveMin Auto

Event OnActivate(ObjectReference akActionRef)
EndEvent
