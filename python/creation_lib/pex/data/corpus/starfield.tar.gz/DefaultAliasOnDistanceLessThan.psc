Scriptname DefaultAliasOnDistanceLessThan Extends ReferenceAlias

ReferenceAlias Property TargetAlias Auto
Bool Property ShowTraces Auto
Int Property PrereqStage Auto
Int Property StageToSet Auto
Float Property TargetDistance Auto

Function OnAliasInit() Native
Function OnDistanceLessThan(objectreference akObj1, objectreference akObj2, Float afDistance, Int aiEventID) Native
