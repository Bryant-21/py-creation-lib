Scriptname BYOH_TIF__01003F05 Extends TopicInfo

referencealias Property WhiterunHouse Auto
referencealias Property MarkarthHouse Auto
referencealias Property SolitudeHouse Auto
referencealias Property WindhelmHouse Auto
referencealias Property PaleHouse Auto
referencealias Property RiftenHouse Auto

Function Fragment_0(ObjectReference akSpeakerRef) Native
String Function GetState() Native
Function GotoState(String newState) Native
