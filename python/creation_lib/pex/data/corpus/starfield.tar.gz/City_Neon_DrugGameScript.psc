Scriptname City_Neon_DrugGameScript Extends Quest

Struct HopperItem
    miscobject hopperIngredient
    Int countNeeded
    Int countGiven
EndStruct

Struct RewardItem
    message rewardMessage
    globalvariable rewardCredits
EndStruct

Int Property StageRoundFail Auto
scene Property City_Neon_Drug_Game_120_Aurora01 Auto
scene Property City_Neon_Drug_Game_Drug03_GameOVer Auto
Int Property City_Neon_Drug03_ObjectiveRound3 Auto
Int Property City_Neon_Drug03_ObjectiveRound2 Auto
Int Property City_Neon_Drug03_ObjectiveRound1 Auto
Int Property City_Neon_Drug02_ObjectiveRound3 Auto
Int Property City_Neon_Drug02_ObjectiveRound2 Auto
Int Property City_Neon_Drug02_ObjectiveRound1 Auto
Int Property City_Neon_Drug03_FinishGameStage Auto
Int Property City_Neon_Drug03_FinalRoundSuccessStage Auto
Int Property City_Neon_Drug02_FinishGameStage Auto
Int Property City_Neon_Drug02_FinalRoundSuccessStage Auto
Int Property StageGameComplete Auto
city_neon_drug02_script Property City_Neon_Drug02 Auto
Int Property StageRoundFinish Auto
Int Property StageUsedWrongIngredients Auto
Int Property StageUsedAllTime Auto
Int Property StageUsedHalfTime Auto
Int Property StageRoundStart Auto
miscobject Property Credits Auto
rewarditem[] Property Rewards Auto
hopperitem[] Property HopperItems Auto
message Property Neon_Drug_07_ShiftFailed Auto
city_neon_drug03_script Property City_Neon_Drug03 Auto
referencealias Property Alias_IngredientHopper Auto
referencealias Property Alias_AssemblyHopper Auto
referencealias Property Alias_ConveyorBelt Auto
globalvariable Property Neon_Drug_ManufactureCount Auto
globalvariable Property Neon_Drug_RetryCount Auto

Function Cleanup() Native
Function OnQuestStarted() Native
Function RewardPlayer() Native
Function ValidateItemsUsed() Native
