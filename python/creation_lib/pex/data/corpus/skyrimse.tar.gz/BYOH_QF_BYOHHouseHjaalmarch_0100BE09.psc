Scriptname BYOH_QF_BYOHHouseHjaalmarch_0100BE09 Extends Quest

locationalias Property Alias_Hold Auto
locationalias Property Alias_HoldCity Auto
referencealias Property Alias_IntroNote Auto
referencealias Property Alias_HouseInteriorMarker Auto
referencealias Property Alias_Jarl Auto
referencealias Property Alias_Steward Auto
book Property Charter Auto
referencealias Property Alias_HouseCarriageDriver Auto
book Property BYOHHouseJarlFriendLetter Auto
referencealias Property Alias_CarpentersWorkbench Auto
globalvariable Property GameDaysPassed Auto
book Property BYOHHouseJarlIntroLetter Auto
referencealias Property Alias_Charter Auto
referencealias Property Alias_DraftingTable Auto
wicourierscript Property WICourier Auto
referencealias Property Alias_HouseHorse Auto
locationalias Property Alias_houseLocation Auto
referencealias Property Alias_CourierNote Auto

Function Fragment_0() Native
Function Fragment_1() Native
Function Fragment_10() Native
Function Fragment_12() Native
Function Fragment_14() Native
Function Fragment_15() Native
Function Fragment_16() Native
Function Fragment_18() Native
Function Fragment_20() Native
Function Fragment_21() Native
Function Fragment_23() Native
Function Fragment_25() Native
Function Fragment_26() Native
Function Fragment_3() Native
Function Fragment_4() Native
Function Fragment_5() Native
String Function GetState() Native
Function GotoState(String newState) Native
