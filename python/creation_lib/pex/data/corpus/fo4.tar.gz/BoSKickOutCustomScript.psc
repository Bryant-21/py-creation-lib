Scriptname BoSKickOutCustomScript Extends ReferenceAlias

quest Property BoSKickOut Auto Const

Event OnDying(actor akKiller)
EndEvent
