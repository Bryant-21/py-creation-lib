Scriptname BoSPilotSceneManagerScript Extends Quest

Struct SceneData
    Int Stage
    scene ExternalScene
    referencealias ExternalAlias
    referencealias LocalAlias
EndStruct

Struct VertibirdTakeDamageData
    keyword BoS_VBirdOnHit_DialogueSubtype
EndStruct

scenedata[] Property SceneDataSettings Auto
keyword Property BoS_VBirdOnHit_DialogueSubtype Auto
referencealias Property VertibirdAlias Auto
referencealias Property PilotAlias Auto

Event OnHit(objectreference akTarget, objectreference akAggressor, form akSource, projectile akProjectile, Bool abPowerAttack, Bool abSneakAttack, Bool abBashAttack, Bool abHitBlocked, String apMaterial)
EndEvent

Event OnQuestInit()
EndEvent

Event OnStageSet(Int auiStageID, Int auiItemID)
EndEvent
