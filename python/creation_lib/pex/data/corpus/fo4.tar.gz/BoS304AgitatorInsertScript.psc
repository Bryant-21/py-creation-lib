Scriptname BoS304AgitatorInsertScript Extends ObjectReference

quest Property BoS304 Auto

Event OnActivate(ObjectReference akActionRef)
EndEvent
