Scriptname BFBPuzzle01Control Extends ObjectReference

Int Property pillarCount Auto
Bool Property doorOpened Auto
ObjectReference Property refActOnFailure02 Auto
ObjectReference Property refActOnFailure04 Auto
ObjectReference Property refActOnSuccess01 Auto
action Property animAction Auto
Bool Property puzzleSolved Auto
ObjectReference Property refActOnFailure03 Auto
Int Property numPillarsSolved Auto
ObjectReference Property puzzleDoorActivator Auto
ObjectReference Property refActOnFailure01 Auto

Function doorOrDarts() Native
String Function GetState() Native
Function GotoState(String newState) Native
Function onActivate(ObjectReference triggerRef) Native
