Scriptname defaultSpawnOnActivateSCRIPT Extends ObjectReference

Bool Property DoOnce Auto
actorbase Property ActorToSpawn Auto
Bool Property PlayerActivateOnly Auto
ObjectReference Property SpawnAtReference Auto

Event onACTIVATE(ObjectReference akActionRef)
EndEvent
