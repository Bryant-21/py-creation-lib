Scriptname ccOTMFO4001:ccOTMFO4001_SoldiersAmbushScript Extends Quest

Struct SoldiersStruct
    referencealias LocalAlias
    referencealias ExternalAlias
EndStruct

referencealias Property ClosestSettlementCenterMarker Auto Const
referencealias Property External_AmbushSoldierOrders Auto Const
referencealias Property Alias_Orders Auto Const
soldiersstruct[] Property AmbushSoldiers Auto Const
Float Property ClosestSettlementMinimumDistance Auto Const
Float Property AmbushDistance Auto Const

Function AddAliases() Native
Function DisableSoldiers() Native
Function MoveSquadIntoAmbushPositionAndEnable() Native
Function TryToPrepareAmbush() Native
