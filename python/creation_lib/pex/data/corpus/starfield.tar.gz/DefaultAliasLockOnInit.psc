Scriptname DefaultAliasLockOnInit Extends ReferenceAlias

Int Property LockLevel Auto

Function OnAliasInit() Native
