Scriptname CA_DB_Event10 Extends ca_dialoguebump_basescript

Function InitializeEventID() Native
