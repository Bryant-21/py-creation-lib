Scriptname CircuitBreakerMasterScript Extends ObjectReference

keyword Property LinkCustom04 Auto Const
keyword Property LinkCustom01 Auto Const
keyword Property LinkCustom03 Auto Const
keyword Property LinkCustom02 Auto Const
Bool Property DenyOnPosition Auto
Bool Property LockToOnPosition Auto
message Property DenyOnPositionMessage Auto
Bool Property OnPosition Auto

Function HandleSwitch(ObjectReference akActionRef) Native
Event OnInit()
EndEvent

Event OnLoad()
EndEvent
