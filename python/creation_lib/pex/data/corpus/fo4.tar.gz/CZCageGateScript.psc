Scriptname CZCageGateScript Extends ReferenceAlias

Int Property EndStage Auto
quest Property CZ Auto
Int Property PreReqStage Auto
scene Property CZ_TommyInCage_Scene Auto

Event OnActivate(objectreference akActionRef)
EndEvent

Event OnInit()
EndEvent
