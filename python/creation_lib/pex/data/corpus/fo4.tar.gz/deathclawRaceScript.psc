Scriptname deathclawRaceScript Extends ActiveMagicEffect

actor Property mySelf Auto
explosion Property AoEIntimidateEffect Auto

Function GibTarget() Native
Event onAnimationEvent(objectreference akSource, String asEventName)
EndEvent

Event OnEffectStart(actor akTarget, actor akCaster)
EndEvent
