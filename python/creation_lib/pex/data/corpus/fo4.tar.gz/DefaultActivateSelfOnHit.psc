Scriptname DefaultActivateSelfOnHit Extends Actor

Bool Property doOnce Auto Const

Event OnHit(objectreference akTarget, objectreference akAggressor, form akSource, projectile akProjectile, Bool abPowerAttack, Bool abSneakAttack, Bool abBashAttack, Bool abHitBlocked, String asMaterialName)
EndEvent

Event OnLoad()
EndEvent

Event OnUnload()
EndEvent
