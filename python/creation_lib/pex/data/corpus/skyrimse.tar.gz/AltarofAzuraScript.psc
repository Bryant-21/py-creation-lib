Scriptname AltarofAzuraScript Extends ObjectReference

ObjectReference Property ShrineofAzura Auto

String Function GetState() Native
Function GotoState(String newState) Native
Function OnActivate(ObjectReference akActionRef) Native
