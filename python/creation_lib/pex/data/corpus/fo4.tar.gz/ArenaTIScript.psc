Scriptname ArenaTIScript Extends TopicInfo

Bool Property PlaceWager Auto Const
Int Property Combatant Auto Const
Bool Property CollectPrize Auto Const
Bool Property CollectEarnings Auto Const

Function CollectEarnings() Native
Event OnEnd(objectreference akSpeakerRef, Bool abHasBeenSaid)
EndEvent

Function PlaceWager() Native
