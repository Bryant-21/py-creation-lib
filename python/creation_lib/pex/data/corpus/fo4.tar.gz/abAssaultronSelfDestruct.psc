Scriptname abAssaultronSelfDestruct Extends RobotSelfDestructScript

explosion Property selfDestructExplosionFX Auto

Event OnActivate(objectreference akActionRef)
EndEvent

Event OnBeginState(String asOldState)
EndEvent

Event OnCombatStateChanged(actor akTarget, Int aeCombatState)
EndEvent

Event OnCripple(actorvalue akActorValue, Bool abCrippled)
EndEvent

Function ResetSelfDestruct() Native
