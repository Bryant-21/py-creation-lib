Scriptname CompanionActorScript Extends Actor

Struct ThresholdData
    message ThresholdMessage
    quest Controlling_Quest
    globalvariable AffinitySceneToPlay_FirstTimeReached
    Bool IsMajorAffinityThreshold
    globalvariable Threshold_Global
    Bool ThresholdHasBeenPreviouslyReached
    globalvariable AffinitySceneToPlay_Repeat_GoingUp
    globalvariable AffinitySceneToPlay_Repeat_GoingDown
    Int Controlling_Quest_Stage
    globalvariable ConditionalGlobal
EndStruct

Struct MurderThresholdData
    Float AffinityPenalty
    Int MaxVictimsAllowed
    Int StageToSet
    quest QuestToSet
EndStruct

Struct EventData
    globalvariable Disposition_Global
    keyword Event_Keyword
    globalvariable ConditionalGlobal
    message Message_to_Display
EndStruct

Struct TraitPreference
    Bool Likes
    actorvalue Trait
EndStruct

keyword Property DislikesEvent Auto
thresholddata[] Property ThresholdData_Array Auto
Bool Property ShouldGivePlayerItems Auto
perk Property InfatuationPerk Auto
actorvalue Property TemporaryAngerLevel Auto
quest Property Tutorial Auto
message Property InfatuationRomanticMessage Auto
murderthresholddata[] Property MurderThreshold_Array Auto
message Property InfatuationPerkMessage Auto
keyword Property CA_Event_Murder Auto
formlist Property ConsideredMurderFactionList Auto
globalvariable Property InfatuationThreshold Auto
globalvariable Property MurderToggle Auto
leveleditem Property ItemToGive Auto
scene Property DismissScene Auto
traitpreference[] Property TraitPreference_Array Auto
globalvariable Property StartingThreshold Auto
Float Property MinAffinity Auto
keyword Property LikesEvent Auto
actorvalue Property Experience Auto
globalvariable Property MQComplete Auto
Int Property MinAffinityChangeFromLastThresholdCrossedRequired Auto
Int Property BodyCountAllowedBeforeMurderSession Auto
keyword Property HatesEvent Auto
Float Property MaxAffinity Auto
topic Property IdleTopic Auto
faction[] Property NotConsideredMurder_Array Auto
thresholddata[] Property CustomThresholdData_Array Auto
formlist Property DismissCompanionSettlementKeywordList Auto
globalvariable Property AllowDismissToSettlements Auto
eventdata[] Property EventData_Array Auto
actorvalue Property HasItemForPlayer Auto
location Property HomeLocation Auto
keyword[] Property KeywordsToAddWhileCurrentCompanion Auto
keyword Property LovesEvent Auto

Function AddThresholdToQueueAndSetSceneToPlay(thresholddata ThresholdToQueue, Float NewAffinity) Native
Function AffinitySceneFinished(Actor ActorToSet) Global Native
Function AffinitySceneForceGreeted(Actor ActorToSet) Global Native
Function CheckAffinityAndSetThresholdAndStage(Float NewAffinity, thresholddata ClosestThresholdData) Native
Function EndMurderSession() Native
Function FinishedSceneRemoveThresholdFromQueueAndSetSceneToPlay(globalvariable RelatedThreshold_Global) Native
Float Function GetAffinityModifyValue(eventdata EventDataToUse, globalvariable EventSize) Native
thresholddata Function GetClosestThresholdData(Float NewAffinity, thresholddata[] ThresholdDataArray) Native
eventdata Function GetEventDataByKeyword(eventdata[] ArrayToSearch, keyword KeywordToFind) Native
thresholddata Function GetNextLockedThreshold(Bool GetNextLockedPositiveThreshold = true) Native
thresholddata Function GetNextThreshold(Bool GetNextInThePositiveDirection = true) Native
thresholddata Function GetThresholdDataForThresholdGlobal(globalvariable ThresholdGlobalToFind) Native
Float Function GetWithPlayerAffinityGain() Native
Function GivePlayerItem() Native
Function HandleHasItemForPlayerTimer() Native
Function HandleWithPlayer() Native
Bool Function IsInfatuated() Native
Bool Function isMurder(Actor ActorVictim, Bool GameConsidersMurder) Native
Bool Function isPlayerNearby() Native
Bool Function IsRomantic() Native
Bool Function IsThresholdChanging(globalvariable ClosestThreshold, Float NewAffinity) Native
Function ModAffinity(Float Amount) Native
Function MurderSession(Actor ActorVictim, Actor ActorKiller) Native
Function NewMurderSession() Native
Event OnCompanionDismiss()
EndEvent

Event OnDeath(Actor akKiller)
EndEvent

Event OnInit()
EndEvent

Event OnTimer(Int aiTimerID)
EndEvent

Event OnTimerGameTime(Int aiTimerID)
EndEvent

Function ProcessMurderThreshold(Int Threshold) Native
Function RomanceDeclined(Bool isPermanent = false) Native
Function RomanceFail() Native
Function RomanceSuccess() Native
Function SayLastDialogueBumpLine() Native
Function SetAffinity(Float Amount) Native
Function SetAffinityBetweenThresholds(globalvariable ThresholdA, globalvariable ThresholdB) Native
Function SetAffinityTowardNextLowestThreshold(Float percentageBetweenCurrentAffinityValueAndNextLowestThreshold = 0.50) Native
Function SetHasLeftPlayerPermanently() Native
Function SetLastDialogueBump(globalvariable LastDialogueBumpToSet) Native
Function SetQueuedThresholdSceneToPlay() Native
Function setStageBasedOnThresholdData(thresholddata ThresholdDataToUse) Native
Function SetTemporaryAngerLevel(Bool isReallyAngry = false) Native
Function ShowRomanticInfatuationMessage() Native
Function ShowThresholdMessage(globalvariable ThresholdGlobal) Native
Function SortThesholdDataArray(thresholddata[] ThresholdDataArray) Native
Function StartHasItemTimer() Native
Function StartRomanceTalkTimer(Float interval) Native
Bool Function TestEventForAffinityBump(keyword EventToTest, globalvariable ThresholdToTestFor = none) Native
Bool Function TestValueForAffinityBump(Float ModifyValueToTest, globalvariable ThresholdToTestFor = none) Native
Function TraceAffinityStats() Native
Function TryToModAffinity(eventdata EventDataToUse, globalvariable EventSize) Native
Function TryToSayCustomTopic(keyword TopicKeyword, objectreference Target = None) Native
Function TryToSetTraitValues(actorvalue TraitToFind, globalvariable EventSize, Bool ShouldAlsoSetAffinity = false) Native
Function TryToShowMessage(eventdata EventDataToUse) Native
Function UnlockInfatuationPerk() Native
Function UnsetHasLeftPlayerPermanently() Native
