Scriptname bosm01danseoverridesquestscript Extends Quest

referencealias Property BoSPaladinDanse Auto
referencealias Property FollowersQuestCompanion Auto

Function BeginDanseScene() Native
Function EndDanseScene() Native
Event OnTimer(Int timerID)
EndEvent
