Scriptname BoS302DanseKillHandlerScript Extends ReferenceAlias

quest Property BOS302 Auto
globalvariable Property BoS302DanseExecuted Auto

Event OnDying(actor akKiller)
EndEvent
