Scriptname ArenaTransitionCombatQuest Extends ArenaCombatQuest

referencealias Property CombatantSpot Auto
faction Property ArenaFaction Auto
referencealias Property Combatant Auto
faction Property SelfLoathing Auto

Function Cleanup() Native
String Function GetState() Native
Function GotoState(String newState) Native
Function PlayerEnteredArena() Native
Function SetupTransition(Bool isTransition) Native
