Scriptname CA_TopicInfoScript Extends TopicInfo

objectreference Property EventTarget Auto
globalvariable Property Size Auto
keyword Property EventKeyword Auto
Bool Property CheckCompanionProximity Auto
Bool Property OnEnd Auto
Bool Property OnBegin Auto

Event OnBegin(objectreference akSpeakerRef, Bool abHasBeenSaid)
EndEvent

Event OnEnd(objectreference akSpeakerRef, Bool abHasBeenSaid)
EndEvent

Function sendEvent(Bool shouldSendEvent) Native
