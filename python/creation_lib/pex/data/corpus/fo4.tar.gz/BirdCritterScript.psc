Scriptname BirdCritterScript Extends ObjectReference

sound Property NPCCrowWingFlapLand Auto
sound Property NPCCrowCall Auto
birdspawnerscript Property myParentScript Auto
sound Property NPCCrowCallDistressed Auto
sound Property NPCCrowWingFlap Auto
keyword Property LinkCustom01 Auto
sound Property NPCCrowWingFlapTakeoff Auto

Function flee() Native
Function flyToTree(Bool akHide, Bool InteriorFlee = false) Native
Function land() Native
Function loadBird() Native
Event OnBeginState(String asOldState)
EndEvent

Event OnLoad()
EndEvent

Event OnTimer(Int aiTimerID)
EndEvent

Event OnTranslationAlmostComplete()
EndEvent

Event OnTranslationComplete()
EndEvent

Event OnUnload()
EndEvent

Function playLandingSounds() Native
Function playTakeoffSounds() Native
Function spawnBird(String akPerchName, birdspawnerscript akParentScript) Native
Function timerBetweenFlights() Native
