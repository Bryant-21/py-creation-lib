Scriptname BYOH_TIF__01003DC1 Extends TopicInfo

quest Property RelationshipAdoption Auto
message Property FavorJobsBeggarMessage Auto
spell Property FavorJobsBeggarsAbility Auto
miscobject Property Gold001 Auto

Function Fragment_0(ObjectReference akSpeakerRef) Native
String Function GetState() Native
Function GotoState(String newState) Native
