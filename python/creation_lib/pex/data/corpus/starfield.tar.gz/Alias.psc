Scriptname Alias Extends ScriptObject

Bool Function CopyIntoAlias(Alias TargetAlias, Bool SkipIfEmpty, Bool CopyOver) Native
quest Function GetOwningQuest() Native
Bool Function IsFilled() Native
Bool Function IsSameType(Alias AliasToCheck) Native
Event OnAliasInit()
EndEvent

Event OnAliasReset()
EndEvent

Event OnAliasShutdown()
EndEvent

Function OnAliasStarted() Native
Function RefillAlias() Native
Function RefillDependentAliases() Native
Function StartObjectProfiling() Native
Function StopObjectProfiling() Native
