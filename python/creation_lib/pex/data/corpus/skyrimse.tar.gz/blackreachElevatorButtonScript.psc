Scriptname blackreachElevatorButtonScript Extends ObjectReference

ObjectReference Property Gears06 Auto
ObjectReference Property Gears01 Auto
ObjectReference Property GateMarker Auto
ObjectReference Property LampLight Auto
ObjectReference Property LampFlame Auto
ObjectReference Property MapMarker Auto
globalvariable Property ElevatorPoweredVariable Auto
ObjectReference Property Gears04 Auto
ObjectReference Property Gears03 Auto
ObjectReference Property Gears02 Auto
ObjectReference Property Gears05 Auto

String Function GetState() Native
Function GotoState(String newState) Native
Function onActivate(ObjectReference akActivator) Native
