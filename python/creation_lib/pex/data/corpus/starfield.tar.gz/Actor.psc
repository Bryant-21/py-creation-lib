Scriptname Actor Extends ObjectReference

Int Property CritStage_GooEnd Auto
Int Property CritStage_FreezeEnd Auto
Int Property CritStage_FreezeStart Auto
Int Property CritStage_DisintegrateEnd Auto
Int Property CritStage_DisintegrateStart Auto
Int Property PathingResult_Failure Auto
Int Property PathingResult_Stopped Auto
Int Property PathingResult_Cleared Auto
Int Property PathingResult_Timeout Auto
Int Property CritStage_None Auto
Int Property CritStage_GooStart Auto
Int Property PathingResult_Success Auto

Function AddBountyCrime(form akBountyCrime) Native
Function AddPassiveAffinity(Float afAmountToAdd) Native
Function AddPerk(perk akPerk, Bool abNotify = false) Native
Function AddToFaction(faction akFaction) Native
Function AllowBleedoutDialogue(Bool abCanTalk) Native
Function AllowPCDialogue(Bool abTalk) Native
Function ApplyUnityCharacterData() Native
Function AttachAshPile(form akAshPileBase = None) Native
Int Function AttackOutpostObjects(ObjectReference akOutpostBeacon) Native
Function AttemptAnimationSetSwitch() Native
Bool Function CanFlyHere() Native
Bool Function CanMoveVertical() Native
Bool Function CanStrafe() Native
Bool Function ChangeAnimArchetype(keyword apKeyword = none) Native
Function ChangeAnimFaceArchetype(keyword apKeyword = none) Native
Bool Function ChangeAnimFlavor(keyword apKeyword = none) Native
Function ChangeHeadPart(headpart apHeadPart, Bool abRemovePart = false, Bool abRemoveExtraParts = false) Native
Function ClearArrested() Native
Function ClearExpressionOverride() Native
Function ClearExtraArrows() Native
Function ClearForcedLandingMarker() Native
Function ClearForcedMovement() Native
Function ClearLookAt() Native
Function CopyAppearance(Actor akSourceToCopyFrom) Native
Bool Function Dismount() Native
Function DispelAllSpells() Native
Function DoCombatSpellApply(spell akSpell, ObjectReference akTarget) Native
Function DogDropItems() Native
Function DogPlaceInMouth(form akItem) Native
Function DrawWeapon() Native
Function EnableAI(Bool abEnable = true, Bool abPauseVoice = false) Native
Function EndDeferredKill() Native
Function EquipItem(form akItem, Bool abPreventRemoval = false, Bool abSilent = false) Native
Function EquipSpell(spell akSpell, Int aiSource) Native
Function EvaluatePackage(Bool abResetAI = false) Native
Function ForceMovementDirection(Float afXAngle = 0.0, Float afYAngle = 0.0, Float afZAngle = 0.0) Native
Function ForceMovementDirectionRamp(Float afXAngle = 0.0, Float afYAngle = 0.0, Float afZAngle = 0.0, Float afRampTime = 0.1) Native
Function ForceMovementRotationSpeed(Float afXMult = 0.0, Float afYMult = 0.0, Float afZMult = 0.0) Native
Function ForceMovementRotationSpeedRamp(Float afXMult = 0.0, Float afYMult = 0.0, Float afZMult = 0.0, Float afRampTime = 0.1) Native
Function ForceMovementSpeed(Float afSpeedMult) Native
Function ForceMovementSpeedRamp(Float afSpeedMult, Float afRampTime = 0.1) Native
Function ForceTargetAngle(Float afXAngle = 0.0, Float afYAngle = 0.0, Float afZAngle = 0.0) Native
Function ForceTargetDirection(Float afXAngle = 0.0, Float afYAngle = 0.0, Float afZAngle = 0.0) Native
Function ForceTargetSpeed(Float afSpeed) Native
Actor Function GetActorInDialogueWithRobot() Native
actor[] Function GetAllActorsInCombatWithMe() Native
actor[] Function GetAllCombatTargets() Native
Int Function GetBribeAmount() Native
Int Function GetCombatState() Native
Actor Function GetCombatTarget() Native
ObjectReference Function GetCrewAssignment() Native
faction Function GetCrimeFaction() Native
package Function GetCurrentPackage() Native
Actor Function GetDialogueTarget() Native
Int Function GetEquippedItemType(Int aiEquipIndex) Native
armor Function GetEquippedShield() Native
spell Function GetEquippedSpell(Int aiSource) Native
weapon Function GetEquippedWeapon(Int aiEquipIndex = 0) Native
Int Function GetFactionRank(faction akFaction) Native
Int Function GetFactionReaction(Actor akOther) Native
Int Function GetFlyingState() Native
ObjectReference Function GetForcedLandingMarker() Native
ObjectReference Function GetFurnitureUsing() Native
Int Function GetGoldAmount() Native
faction Function GetGroupFaction() Native
Int Function GetHighestRelationshipRank() Native
Actor Function GetKiller() Native
Int Function GetLevel() Native
actorbase Function GetLeveledActorBase() Native
Float Function GetLightLevel() Native
Int Function GetLowestRelationshipRank() Native
actorbase Function GetMatchingPlanetActorBase() Native
Bool Function GetNoBleedoutRecovery() Native
Bool Function GetPlayerControls() Native
race Function GetRace() Native
Int Function GetRelationshipRank(Actor akOther) Native
Int Function GetSitState() Native
Int Function GetSleepState() Native
spaceshipreference Function GetSpaceship() Native
Bool Function HasAssociation(associationtype akAssociation, Actor akOther = None) Native
Bool Function HasDetectionLOS(ObjectReference akOther) Native
Bool Function HasFamilyRelationship(Actor akOther = None) Native
Bool Function HasMagicEffect(magiceffect akEffect) Native
Bool Function HasMagicEffectWithKeyword(keyword akKeyword) Native
Bool Function HasParentRelationship(Actor akOther) Native
Bool Function HasPerk(perk akPerk) Native
Bool Function HasSpell(form akForm) Native
Bool Function IsAIEnabled() Native
Bool Function IsAlarmed() Native
Bool Function IsAlerted() Native
Bool Function IsAllowedToFly() Native
Bool Function IsArrested() Native
Bool Function IsArrestingTarget() Native
Bool Function IsBeingRidden() Native
Bool Function IsBeingRiddenBy(Actor akActor) Native
Int Function IsBleedingOut() Native
Bool Function IsBribed() Native
Bool Function IsChild() Native
Bool Function IsCommandedActor() Native
Bool Function IsDead() Native
Bool Function IsDetectedBy(Actor akOther) Native
Bool Function IsDoingFavor() Native
Bool Function IsEquipped(form akItem) Native
Bool Function IsEssential() Native
Bool Function IsFlying() Native
Bool Function IsGhost() Native
Bool Function IsGuard() Native
Bool Function IsHostileToActor(Actor akActor) Native
Bool Function IsInCombat() Native
Bool Function IsInFaction(faction akFaction) Native
Bool Function IsInIronSights() Native
Bool Function IsInKillMove() Native
Bool Function IsInScene() Native
Bool Function IsIntimidated() Native
Bool Function IsOnMount() Native
Bool Function IsOverEncumbered() Native
Bool Function IsOwner(ObjectReference akObject) Native
Bool Function IsPlayersLastRiddenHorse() Native
Bool Function IsPlayerTeammate() Native
Bool Function IsRunning() Native
Bool Function IsSeatOccupied(keyword apKeyword) Native
Bool Function IsSneaking() Native
Bool Function IsSprinting() Native
Bool Function IsTalking() Native
Bool Function IsTrespassing() Native
Bool Function IsUnconscious() Native
Bool Function IsWeaponDrawn() Native
Function Kill(Actor akKiller = None) Native
Function KillEssential(Actor akKiller = None) Native
Function KillSilent(Actor akKiller = None) Native
Function MakePlayerFriend() Native
Function MarkItemAsFavorite(form akItem, Int aiSlot = -1) Native
Function ModFactionRank(faction akFaction, Int aiMod) Native
Function ModFavorPoints(Int iFavorPoints = 1) Native
Function ModFavorPointsWithGlobal(globalvariable FavorPointsGlobal) Native
Bool Function MoveToFurniture(ObjectReference akTargetFurniture) Native
Function MoveToPackageLocation() Native
Function OnActorActivatedRef(ObjectReference akActivatedRef) Native
Function OnAffinityEvent(affinityevent akAffinityEvent, actorvalue akActorValue, globalvariable akReactionValue, ObjectReference akTarget) Native
Function OnCombatListAdded(Actor akTarget) Native
Function OnCombatListRemoved(Actor akTarget) Native
Event OnCombatStateChanged(ObjectReference akTarget, Int aeCombatState)
EndEvent

Event OnCommandModeCompleteCommand(Int aeCommandType, ObjectReference akTarget)
EndEvent

Event OnCommandModeEnter()
EndEvent

Event OnCommandModeExit()
EndEvent

Event OnCommandModeGiveCommand(Int aeCommandType, ObjectReference akTarget)
EndEvent

Event OnCompanionDismiss()
EndEvent

Event OnConsciousnessStateChanged(Bool abUnconscious)
EndEvent

Event OnCripple(actorvalue akActorValue, Bool abCrippled)
EndEvent

Event OnDeath(ObjectReference akKiller)
EndEvent

Event OnDeferredKill(Actor akKiller)
EndEvent

Event OnDifficultyChanged(Int aOldDifficulty, Int aNewDifficulty)
EndEvent

Event OnDying(ObjectReference akKiller)
EndEvent

Event OnEnterBleedout()
EndEvent

Function OnEnterOutpostBeaconMode() Native
Function OnEnterShipInterior(ObjectReference akShip) Native
Event OnEnterSneaking()
EndEvent

Event OnEscortWaitStart()
EndEvent

Event OnEscortWaitStop()
EndEvent

Function OnExitShipInterior(ObjectReference akShip) Native
Event OnGetUp(ObjectReference akFurniture)
EndEvent

Function OnHomeShipSet(spaceshipreference akShip, spaceshipreference akPrevious) Native
Event OnItemEquipped(form akBaseObject, ObjectReference akReference)
EndEvent

Event OnItemUnequipped(form akBaseObject, ObjectReference akReference)
EndEvent

Event OnKill(ObjectReference akVictim)
EndEvent

Event OnLocationChange(location akOldLoc, location akNewLoc)
EndEvent

Function OnOutpostPlaced(ObjectReference akOutpostBeacon) Native
Event OnPackageChange(package akOldPackage)
EndEvent

Event OnPackageEnd(package akOldPackage)
EndEvent

Event OnPackageStart(package akNewPackage)
EndEvent

Event OnPartialCripple(actorvalue akActorValue, Bool abCrippled)
EndEvent

Function OnPickLock(ObjectReference akLockedRef, Bool abCrime, Bool abSucceeded, terminalmenu akLockedTerminalMenu, Int aiTerminalMenuItem) Native
Event OnPickpocketFailed()
EndEvent

Function OnPlayerArrested(ObjectReference akGuard, location akLocation, Int aeCrimeType) Native
Function OnPlayerAssaultActor(ObjectReference akVictim, location akLocation, Bool aeCrime) Native
Function OnPlayerBuyShip(spaceshipreference akShip) Native
Function OnPlayerCompleteResearch(ObjectReference akBench, location akLocation, researchproject akProject) Native
Function OnPlayerCraftItem(ObjectReference akBench, location akLocation, form akCreatedItem) Native
Event OnPlayerCreateRobot(Actor akNewRobot)
EndEvent

Function OnPlayerCrimeGold(ObjectReference akVictim, form akFaction, Int aeCrimeGold, Int aeCrimeType) Native
Event OnPlayerEnterVertibird(ObjectReference akVertibird)
EndEvent

Function OnPlayerFailedPlotRoute(Int aeFailedPlotReason) Native
Event OnPlayerFallLongDistance(Float afDamage)
EndEvent

Event OnPlayerFireWeapon(form akBaseObject)
EndEvent

Function OnPlayerFollowerWarp(ObjectReference akFollower) Native
Event OnPlayerHealTeammate(Actor akTeammate)
EndEvent

Function OnPlayerItemAdded(form akBaseObject, ObjectReference akOwner, ObjectReference akSourceContainer, Int aeAcquireType) Native
Function OnPlayerJail(ObjectReference akGuard, form akFaction, location akLocation, Int aeCrimeGold) Native
Event OnPlayerLoadGame()
EndEvent

Function OnPlayerLoiteringBegin() Native
Function OnPlayerLoiteringEnd() Native
Event OnPlayerModArmorWeapon(form akBaseObject, objectmod akModBaseObject)
EndEvent

Function OnPlayerModifiedShip(spaceshipreference akShip) Native
Event OnPlayerModRobot(Actor akRobot, objectmod akModBaseObject)
EndEvent

Function OnPlayerMurderActor(ObjectReference akVictim, location akLocation, Bool aeCrime) Native
Function OnPlayerPayFine(ObjectReference akGuard, form akFaction, Int aeCrimeGold) Native
Function OnPlayerPlanetSurveyComplete(planet akPlanet) Native
Function OnPlayerScannedObject(ObjectReference akScannedRef) Native
Function OnPlayerSellShip(spaceshipreference akShip) Native
Event OnPlayerSwimming()
EndEvent

Function OnPlayerTrespass(ObjectReference akVictim, location akLocation, Bool aeCrime) Native
Event OnPlayerUseWorkBench(ObjectReference akWorkBench)
EndEvent

Event OnRaceSwitchComplete()
EndEvent

Function OnRecoverFromBleedout() Native
Event OnSit(ObjectReference akFurniture)
EndEvent

Event OnSpeechChallengeAvailable(ObjectReference akSpeaker)
EndEvent

Function OnUnconscious(ObjectReference akAttacker) Native
Function OpenInventory(Bool abForceOpen = false, form akFilter, Bool abIncludeOnlyFromFilter) Native
Int Function PathToReference(ObjectReference aTarget, Float afNormalizedSpeed, Float afNormalizedRotationSpeed, Float afTargetRadius, Bool abHardRadius) Native
Bool Function PlayIdle(idle akIdle) Native
Bool Function PlayIdleAction(action aAction, ObjectReference aTarget = None) Native
Bool Function PlayIdleWithTarget(idle akIdle, ObjectReference akTarget) Native
Function PlaySubGraphAnimation(String asEventName) Native
Function RemoveFromAllFactions() Native
Function RemoveFromFaction(faction akFaction) Native
Function RemovePerk(perk akPerk) Native
Bool Function RemoveSpell(spell akSpell) Native
Function ResetHealthAndLimbs() Native
Function Resurrect() Native
Function SendAssaultAlarm() Native
Function SendSmugglingAlarm(Actor akCriminal) Native
Function SendTrespassAlarm(Actor akCriminal) Native
Function SetAlert(Bool abAlerted = true) Native
Function SetAllowFlying(Bool abAllowed = true, Bool abAllowCrash = true, Bool abAllowSearch = false) Native
Function SetAlpha(Float afTargetAlpha, Bool abFade = false) Native
Function SetAttackActorOnSight(Bool abAttackOnSight = true) Native
Function SetAvoidPlayer(Bool abAvoid = true) Native
Function SetBribed(Bool abBribe = true) Native
Function SetCanDoCommand(Bool abCanCommand = true) Native
Function SetCombatStyle(combatstyle akCombatStyle) Native
Function SetCommandState(Bool abStartCommandMode) Native
Function SetCrimeFaction(faction akFaction) Native
Function SetCriticalStage(Int aiStage) Native
Function SetDoingFavor(Bool abDoingFavor = true, Bool abWorkShopMode = false) Native
Function SetEssential(Bool abEssential) Native
Function SetFactionRank(faction akFaction, Int aiRank) Native
Function SetForcedLandingMarker(ObjectReference aMarker) Native
Function SetGhost(Bool abIsGhost = true) Native
Function SetGroupFaction(faction akFaction) Native
Function SetHasCharGenSkeleton(Bool abCharGen = true) Native
Function SetHeadTracking(Bool abEnable = true) Native
Function SetIntimidated(Bool abIntimidate = true) Native
Function SetLookAt(ObjectReference akTarget, Bool abPathingLookAt = false) Native
Function SetNoBleedoutRecovery(Bool abAllowed) Native
Function SetNotShowOnStealthMeter(Bool abNotShow) Native
Function SetOutfit(outfit akOutfit, Bool abSleepOutfit = false) Native
Function SetOverrideVoiceType(voicetype akVoiceType) Native
voicetype Function SetOverrideVoiceTypeRandom(formlist akVoiceList) Native
Function SetPlayerControls(Bool abControls) Native
Function SetPlayerResistingArrest() Native
Function SetPlayerTeammate(Bool abTeammate = true, Bool abCanDoFavor = true, Bool abGivePlayerXP = false) Native
Function SetProtected(Bool abProtected) Native
Function SetRace(race akRace = None) Native
Function SetRelationshipRank(Actor akOther, Int aiRank) Native
Bool Function SetRestrained(Bool abRestrained = true) Native
Function SetSubGraphFloatVariable(String asVariableName, Float afValue) Native
Bool Function SetUnconscious(Bool abUnconscious = true) Native
Function SetVehicle(Actor akVehicle) Native
Function SetWantSprinting(Bool abWantSprint) Native
Function SheatheWeapon() Native
Function ShowBarterMenu() Native
Function ShowCrewAssign(Bool abAssign) Native
Bool Function SnapIntoInteraction(ObjectReference akTarget) Native
Bool Function StartCombat(ObjectReference akTarget, Bool abPreferredTarget = false) Native
Function StartDeferredKill() Native
Function StartFrenzyAttack(Float aChance = 0.1, Float aInterval = 0.5) Native
Function StartSneaking() Native
Function StartVampireFeed(Actor akTarget) Native
Function StopCombat() Native
Function StopCombatAlarm() Native
Function SwitchToPowerArmor(ObjectReference aArmorFurniture) Native
Bool Function TrapSoul(Actor akTarget) Native
Function UnequipAll() Native
Function UnequipItem(form akItem, Bool abPreventEquip = false, Bool abSilent = false) Native
Function UnequipItemSlot(Int aiSlot) Native
Function UnequipSpell(spell akSpell, Int aiSource) Native
Function UnLockOwnedDoorsInCell() Native
Bool Function WillIntimidateSucceed() Native
Bool Function WornCoversBipedSlot(Int aiSlot) Native
Bool Function WornHasKeyword(keyword akKeyword) Native
Bool Function WouldBeStealing(ObjectReference akObject) Native
Int Function WouldRefuseCommand(ObjectReference akObject) Native
