Scriptname BYOH_TIF__01003E00 Extends TopicInfo

referencealias Property MarkarthHouse Auto
referencealias Property HjaalmarchHouse Auto
referencealias Property WindhelmHouse Auto
referencealias Property WhiterunHouse Auto
referencealias Property SolitudeHouse Auto
referencealias Property RiftenHouse Auto

Function Fragment_0(ObjectReference akSpeakerRef) Native
String Function GetState() Native
Function GotoState(String newState) Native
