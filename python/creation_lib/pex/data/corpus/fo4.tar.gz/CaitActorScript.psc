Scriptname CaitActorScript Extends Actor

globalvariable Property AO_Companion_CaitExplainLockPick_DONE Auto
keyword Property AO_CaitExplainLockPick_Start Auto

Event OnLoad()
EndEvent

Event OnTimer(Int aiTimerID)
EndEvent

Function StartSendStoryEventTimer() Native
