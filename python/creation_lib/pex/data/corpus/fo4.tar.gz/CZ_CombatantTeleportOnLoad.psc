Scriptname CZ_CombatantTeleportOnLoad Extends ReferenceAlias

objectreference Property Marker Auto
quest Property CZ Auto

Event OnLoad()
EndEvent
