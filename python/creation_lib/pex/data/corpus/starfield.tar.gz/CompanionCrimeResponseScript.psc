Scriptname CompanionCrimeResponseScript Extends Actor

sq_companionsscript Property SQ_Companions Auto
actorvalue Property Aggression Auto
faction[] Property IgnoreSharedCrimeForAnyoneInTheseFactions Auto
actorvalue Property Assistance Auto
faction Property CurrentCompanionFaction Auto
globalvariable Property COM_AngerReason_Common_1_Murder Auto
keyword Property COM_NotCivilian Auto
affinityevent Property AffinityEventOnCombat Auto
affinityevent Property AffinityEventOnKill Auto

Bool Function AmIAngry() Native
Bool Function AmIHere() Native
Function AutoDismiss() Native
Function CivilianCombat(Actor CivilianActor) Native
Function CivilianKilled(Actor CivilianActor) Native
Bool Function IsValidCrimeVictim(Actor ActorToCheck) Native
Function OnLoad() Native
Function OnUnload() Native
Function Pacify() Native
Function ProcessCombatantsForCrimeFactionAnger(Bool TestMyCombatTargets) Native
Function ProcessCrimeFactionAnger(Actor ActorToTest, faction myCrimeFaction, Bool SkipLockedInCompanionCheck) Native
Function RegisterForEvents() Native
Bool Function TestForLockedInCompanion() Native
Bool Function Trace(ScriptObject CallingObject, String asTextToPrint, Int aiSeverity, String MainLogName, String SubLogName, Bool bShowNormalTrace, Bool bShowWarning, Bool bPrefixTraceWithLogNames) Native
Function UnregisterForEvents() Native
Bool Function warning(ScriptObject CallingObject, String asTextToPrint, Int aiSeverity, String MainLogName, String SubLogName, Bool bShowNormalTrace, Bool bShowWarning, Bool bPrefixTraceWithLogNames) Native
