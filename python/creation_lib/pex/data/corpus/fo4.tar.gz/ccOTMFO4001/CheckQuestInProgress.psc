Scriptname ccOTMFO4001:CheckQuestInProgress Extends Quest

objectreference Property EnableMarker_CaravanCamp Auto Const
objectreference Property EnableMarker_GhoulDisableAtlantic Auto Const
objectreference Property EnableMarker_AtlanticCamp Auto Const

Function CheckQuestState() Native
Function OnInit() Native
