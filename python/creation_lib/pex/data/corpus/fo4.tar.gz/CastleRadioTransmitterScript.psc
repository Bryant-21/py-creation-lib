Scriptname CastleRadioTransmitterScript Extends ObjectReference

Bool Property bRepaired Auto
Bool Property DebugAlwaysOn Auto

Event OnInit()
EndEvent

Function RepairMe(Bool bDebugAlwaysOn = false) Native
