Scriptname BYOH_TIF__01003E2C Extends TopicInfo

referencealias Property WindhelmHouse Auto
referencealias Property SolitudeHouse Auto
referencealias Property MarkarthHouse Auto
referencealias Property RiftenHouse Auto
referencealias Property WhiterunHouse Auto

Function Fragment_0(ObjectReference akSpeakerRef) Native
String Function GetState() Native
Function GotoState(String newState) Native
