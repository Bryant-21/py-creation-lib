Scriptname CA_DB_Event04 Extends ca_dialoguebump_basescript

Function InitializeEventID() Native
