Scriptname DefaultCollectionOnCombatStateChanged Extends DefaultCollectionAlias

Bool Property IncludeOnHitEvent Auto
Int Property CombatStateToCheckFor Auto

Function CombatStateChangedOrHit(objectreference akSenderRef, objectreference TargetOrAggressor) Native
Function OnAliasInit() Native
Event OnCombatStateChanged(objectreference akSenderRef, objectreference akTarget, Int aeCombatState)
EndEvent

Function OnHit(objectreference akTarget, objectreference akAggressor, form akSource, projectile akProjectile, Bool abPowerAttack, Bool abSneakAttack, Bool abBashAttack, Bool abHitBlocked, String asMaterialName) Native
Function OnLoad(objectreference akSenderRef) Native
Function OnUnload(objectreference akSenderRef) Native
