Scriptname CharGenFridgeDoorScript Extends ObjectReference

Event OnClose(ObjectReference akActionRef)
EndEvent

Event OnOpen(ObjectReference akActionRef)
EndEvent
