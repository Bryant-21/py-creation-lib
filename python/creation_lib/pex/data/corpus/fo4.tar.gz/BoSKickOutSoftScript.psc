Scriptname BoSKickOutSoftScript Extends Quest

Quest Property BoS204 Auto Const
Quest Property BoS303 Auto Const
Quest Property BoS101POI Auto Const
Quest Property BoS201B Auto Const
Quest Property BoS302 Auto Const
Quest Property BoS000 Auto Const
Quest Property BoS304 Auto Const
Quest Property BoS203 Auto Const
Quest Property BoS301 Auto Const
Quest Property BoS202 Auto Const
Quest Property BoS302B Auto Const
Quest Property DNPrime_BoS304 Auto Const
Quest Property BoS202LinkMQ Auto Const
Quest Property BoS200 Auto Const
referencealias Property BoSRBerylliumAgitatorQuestItem Auto Const
Quest Property BoSM01 Auto Const
Quest Property BoS101 Auto Const
Quest Property BoSPostQuest Auto Const
Quest Property BoSKickOutSoft Auto Const
Quest Property BoS201 Auto Const
Quest Property BoS100 Auto Const

Function SoftKickOut() Native
