Scriptname AssaultronHeadModStealthScript Extends ActiveMagicEffect

actorvalue Property endurancecondition Auto Const
actorvalue Property RightMobilityCondition Auto Const
ammo Property AmmoAssaultron Auto Const
spell Property stealthSpell Auto
sound Property laserChargeSound Auto Const
sound Property LaserTailSound Auto Const
sound Property LaserFireSound Auto Const
Int Property laserState Auto
actorvalue Property LeftAttackCondition Auto Const
actorvalue Property RightAttackCondition Auto Const
spell Property PcrThermalCoreCloak Auto Const
actorvalue Property headlaserAV Auto Const
magiceffect Property stealthEffect Auto
actorvalue Property LeftMobilityCondition Auto Const
imagespacemodifier Property laserImod Auto Const
sound Property laserReadySound Auto Const
weapon Property pAssaultronLaser Auto Const
visualeffect Property pAssaultronHeadChargeV Auto Const

Function beginChargingLaser(actor SelfRef) Native
Function cloak(actor SelfRef) Native
Function deCloak(actor SelfRef) Native
Function endLaser(actor SelfRef) Native
Function fireLaser(actor SelfRef) Native
Function laserCrippled(actor SelfRef) Native
Function limbCrippledReduceLaserCoolTime() Native
Event OnAnimationEvent(objectreference akSource, String asEventName)
EndEvent

Event OnCombatStateChanged(actor akTarget, Int aeCombatState)
EndEvent

Event OnCripple(actorvalue akActorValue, Bool abCrippled)
EndEvent

Event OnDying(actor akKiller)
EndEvent

Event OnEffectFinish(actor akTarget, actor akCaster)
EndEvent

Event OnEffectStart(actor akTarget, actor akCaster)
EndEvent

Event OnTimer(Int aiTimerID)
EndEvent

Function readyLaser(actor SelfRef) Native
