Scriptname CircuitBreakerMasterScript Extends ObjectReference

keyword Property LinkCustom04 Auto
keyword Property LinkCustom01 Auto
keyword Property LinkCustom03 Auto
keyword Property LinkCustom02 Auto
Bool Property DenyOnPosition Auto
Bool Property LockToOnPosition Auto
message Property DenyOnPositionMessage Auto
Bool Property OnPosition Auto

Function HandleSwitch(ObjectReference akActionRef) Native
Event OnInit()
EndEvent

Event OnLoad()
EndEvent
