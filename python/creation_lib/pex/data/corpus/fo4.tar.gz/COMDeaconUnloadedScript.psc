Scriptname COMDeaconUnloadedScript Extends ReferenceAlias

globalvariable Property pCOMDeaconUnloaded Auto

Event OnLoad()
EndEvent

Event OnUnload()
EndEvent
