Scriptname BYOH_TIF__01000898 Extends TopicInfo

favordialoguescript Property DialogueFavorGeneric Auto

Function Fragment_1(ObjectReference akSpeakerRef) Native
String Function GetState() Native
Function GotoState(String newState) Native
