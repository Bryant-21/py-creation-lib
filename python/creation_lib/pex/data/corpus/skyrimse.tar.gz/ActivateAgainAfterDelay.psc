Scriptname ActivateAgainAfterDelay Extends objectReference

Float Property fDelay Auto
keyword Property linkSisterSwitch Auto
objectReference Property blocker Auto

String Function GetState() Native
Function GotoState(String newState) Native
Function onActivate(objectReference triggerRef) Native
Function onLoad() Native
