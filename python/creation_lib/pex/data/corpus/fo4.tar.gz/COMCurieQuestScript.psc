Scriptname COMCurieQuestScript Extends Quest

Int Property bCurieToldAboutAmari Auto

Function CancelNewCurieArrivalTimer() Native
Function NewCurieArrivalTimer() Native
Event OnTimerGameTime(Int iTimer)
EndEvent
