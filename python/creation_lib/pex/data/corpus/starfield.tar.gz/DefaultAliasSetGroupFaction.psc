Scriptname DefaultAliasSetGroupFaction Extends ReferenceAlias

faction Property GroupFaction Auto
Bool Property ShowTraces Auto

Function OnAliasChanged(objectreference akObject, Bool abRemove) Native
Function OnAliasInit() Native
Function SetGroupFaction() Native
