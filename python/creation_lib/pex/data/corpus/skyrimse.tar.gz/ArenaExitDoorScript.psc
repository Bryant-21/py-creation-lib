Scriptname ArenaExitDoorScript Extends ReferenceAlias

location Property PitLocation Auto
message Property ArenaNobodyLeavesMessage Auto
objectreference Property BloodworksDoorMarker Auto

String Function GetState() Native
Function GotoState(String newState) Native
Function OnActivate(objectreference akActionRef) Native
Function Setup() Native
