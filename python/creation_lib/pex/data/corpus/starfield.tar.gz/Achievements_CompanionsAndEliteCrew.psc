Scriptname Achievements_CompanionsAndEliteCrew Extends Quest

refcollectionalias Property RecruitedCompanionsAndEliteCrew Auto
Int Property AchievementID_MaxRelationshipLevelReached Auto
Int Property AffinityLevelNeeded Auto
actorvalue Property COM_AffinityLevel Auto
Int Property AchievementID_RecruitedCount Auto
Int Property CountForAchievement Auto

Function AffinityLevelReached(actor CompanionActor) Native
Function RecruitedCompanionOrEliteCrew(actor RecruitedActor) Native
Bool Function Trace(ScriptObject CallingObject, String asTextToPrint, Int aiSeverity, String MainLogName, String SubLogName, Bool bShowNormalTrace, Bool bShowWarning, Bool bPrefixTraceWithLogNames) Native
Bool Function warning(ScriptObject CallingObject, String asTextToPrint, Int aiSeverity, String MainLogName, String SubLogName, Bool bShowNormalTrace, Bool bShowWarning, Bool bPrefixTraceWithLogNames) Native
