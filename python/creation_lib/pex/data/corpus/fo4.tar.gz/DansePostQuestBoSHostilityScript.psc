Scriptname DansePostQuestBoSHostilityScript Extends Actor

message Property DanseBosHostilityMessageOn Auto
faction Property CurrentCompanionFaction Auto
message Property DanseBosHostilityMessageOff Auto
faction Property BrotherhoodofSteelFaction Auto

Function MakeBoSHostile() Native
Event OnLoad()
EndEvent

Event OnTimerGameTime(Int aiTimerID)
EndEvent

Function Process(Bool showMessage = false) Native
