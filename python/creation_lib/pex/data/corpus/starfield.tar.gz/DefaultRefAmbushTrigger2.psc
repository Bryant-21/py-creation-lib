Scriptname DefaultRefAmbushTrigger2 Extends ObjectReference

keyword Property LinkAmbushTrigger Auto
actorvalue Property AmbushTriggered Auto
Float Property MaxAmbushDelay Auto
Bool Property TriggerIfAnyLinkedActorEntersCombat Auto
keyword Property DMP_AmbushMarker Auto
keyword Property LinkAmbushSequence Auto
Bool Property TriggerIfAnyLinkedActorIsHit Auto
faction Property FactionToApplyInAmbush Auto
Float Property InitialAmbushDelay Auto
Float Property MinAmbushDelay Auto

actor[] Function GetAmbushTriggerActors() Native
Function OnBeginState(String asOldState) Native
Function OnCellLoad() Native
Function OnHit(ObjectReference akTarget, ObjectReference akAggressor, form akSource, projectile akProjectile, Bool abPowerAttack, Bool abSneakAttack, Bool abBashAttack, Bool abHitBlocked, String asMaterialName) Native
Function OnTriggerEnter(ObjectReference akActionRef) Native
Function TriggerAmbush() Native
Function TriggerAmbushForActor(actor actorToTrigger) Native
