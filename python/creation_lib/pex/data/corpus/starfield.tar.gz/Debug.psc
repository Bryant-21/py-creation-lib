Scriptname Debug Extends ScriptObject

Function AutomatedTestLogDebug(String asMessage) Global Native
Function AutomatedTestLogError(String asMessage) Global Native
Function AutomatedTestLogProgress(String asMessage) Global Native
Function CenterOnCell(String asCellname) Global Native
Float Function CenterOnCellAndWait(String asCellname) Global Native
Function CloseUserLog(String asLogName) Global Native
Function DBSendPlayerPosition() Global Native
Function DumpAliasData(quest akQuest) Global Native
Function DumpEventRegistrations(ScriptObject akScript) Global Native
Function EnableAI(Bool abEnable = true) Global Native
Function EnableCollisions(Bool abEnable = true) Global Native
Function EnableDetection(Bool abEnable = true) Global Native
Function EnableMenus(Bool abEnable = true) Global Native
Function ExecuteConsole(String aCommand) Global Native
String Function GetConfigName() Global Native
String Function GetPlatformName() Global Native
String Function GetVersionNumber() Global Native
Function MessageBox(String asMessageBoxText) Global Native
Function Notification(String asNotificationText) Global Native
Bool Function OpenUserLog(String asLogName) Global Native
Float Function PlayerMoveToAndWait(String asDestRef) Global Native
Function QuitGame() Global Native
Function SetGodMode(Bool abGodMode) Global Native
Function ShowRefPosition(objectreference arRef) Global Native
Function StartScriptProfiling(String asScriptName) Global Native
Function StartStackProfiling() Global Native
Function StartStackRootProfiling(String asScriptName, ScriptObject akObj = None) Global Native
Function StopScriptProfiling(String asScriptName) Global Native
Function StopStackProfiling() Global Native
Function StopStackRootProfiling(String asScriptName, ScriptObject akObj = None) Global Native
Function Trace(String asTextToPrint, Int aiSeverity = 0) Global Native
Function TraceAndBox(String asTextToPrint, Int aiSeverity = 0) Global Native
Function TraceConditional(String TextToPrint, Bool ShowTrace, Int Severity = 0) Global Native
Function TraceConditionalGlobal(String TextToPrint, globalvariable ShowTrace) Global Native
Function TraceFunction(String asTextToPrint = "Tracing function on request", Int aiSeverity = 0) Global Native
Bool Function TraceLog(ScriptObject CallingObject, String asTextToPrint, String logName, String SubLogName, Int aiSeverity, Bool bShowNormalTrace, Bool bShowWarning, Bool bPrefixTraceWithLogNames, Bool bPrefixTracesWithCallingObject) Global Native
Function TraceSelf(ScriptObject CallingScript, String FunctionName, String StringToTrace) Global Native
Function TraceStack(String asTextToPrint = "Tracing stack on request", Int aiSeverity = 0) Global Native
Bool Function TraceUser(String asUserLog, String asTextToPrint, Int aiSeverity = 0) Global Native
