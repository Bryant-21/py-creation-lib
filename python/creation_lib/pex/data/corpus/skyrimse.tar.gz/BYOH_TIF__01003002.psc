Scriptname BYOH_TIF__01003002 Extends TopicInfo

miscobject Property Lumber Auto
miscobject Property Gold001 Auto

Function Fragment_0(ObjectReference akSpeakerRef) Native
String Function GetState() Native
Function GotoState(String newState) Native
