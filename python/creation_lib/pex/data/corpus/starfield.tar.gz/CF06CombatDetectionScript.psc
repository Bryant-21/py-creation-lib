Scriptname CF06CombatDetectionScript Extends ObjectReference

quest Property CF06 Auto
faction Property RobotJanitorFaction Auto
faction Property RobotSecurityFaction Auto
location Property LC0939Location Auto

Function OnCellDetach() Native
Function OnCellLoad() Native
Function SetCombatStage() Native
Function UnregisterForKillEvents() Native
