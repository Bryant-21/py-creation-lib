Scriptname Achievements_TrackedStatsScript Extends Quest

Struct ChallengeAchievement
    challenge AchievementChallenge
    Int AchievementNumber
EndStruct

Struct StatsAchievement
    String statString
    Int AchievementNumber
    Int statCount
EndStruct

statsachievement[] Property StatsAchievements Auto
challengeachievement[] Property ChallengeAchievements Auto

Function OnChallengeCompleted(objectreference akOwner, challenge akChallenge) Native
Function OnTrackedStatsEvent(String asStatFilter, Int aiStatValue) Native
Function RegisterTrackedStats() Native
