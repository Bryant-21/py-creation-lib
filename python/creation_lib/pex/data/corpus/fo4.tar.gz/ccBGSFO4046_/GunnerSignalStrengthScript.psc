Scriptname ccBGSFO4046_:GunnerSignalStrengthScript Extends Quest

Int Property RadioTime Auto
message Property SignalStrengthMessage Auto
worldspace Property Commonwealth Auto
Quest Property BestOfThreeQuest Auto
objectreference Property Transmitter Auto

Function OnQuestInit() Native
Function OnTimer(Int aiTimerID) Native
