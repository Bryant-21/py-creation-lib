Scriptname CA_DB_Event02 Extends ca_dialoguebump_basescript

Function InitializeEventID() Native
