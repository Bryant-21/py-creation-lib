Scriptname CA_DB_Event05 Extends ca_dialoguebump_basescript

Function InitializeEventID() Native
