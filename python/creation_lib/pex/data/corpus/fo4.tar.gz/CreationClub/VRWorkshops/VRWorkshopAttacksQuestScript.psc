Scriptname CreationClub:VRWorkshops:VRWorkshopAttacksQuestScript Extends Quest

actorvalue Property LeftAttackCondition Auto Const
refcollectionalias Property AttackEnemiesRefCol Auto Const
effectshader Property TeleportInFXS Auto Const
message Property VRWorkshop_Message_NoEnemySpawners Auto Const
Int Property StageReady Auto Const
sound Property TeleportSound Auto Const
message Property VRWorkshop_Message_AttackStart Auto Const
actorvalue Property EnduranceCondition Auto Const
actorvalue Property LeftMobilityCondition Auto Const
refcollectionalias Property AttackSpawnPointsRefCol Auto Const
actorvalue Property Rads Auto Const
message Property VRWorkshop_Message_AttackStop Auto Const
message Property VRWorkshopShared_MessageBox_AttackModeBleedout Auto Const
Int Property ObjectiveComplete Auto Const
Int Property StageCompleted Auto Const
effectshader Property TeleportOutFXS Auto Const
actorvalue Property RightAttackCondition Auto Const
actorvalue Property RightMobilityCondition Auto Const
actorvalue Property PerceptionCondition Auto Const
actorvalue Property Health Auto Const

Function DisableAllEnemies() Native
Function FailVRAttack() Native
Function PlayTeleportOutEffect(objectreference enemyToDisable) Native
Function SpawnEnemiesAtMarkers() Native
Function StartVRAttack() Native
Function StopVRAttack() Native
