Scriptname BYOH_TIF__01004D0A Extends TopicInfo

objectreference Property DecorateMarker Auto
Int Property GoldAmount Auto
globalvariable Property HDMarkarthAlchemy Auto
miscobject Property Gold Auto

Function Fragment_0(objectreference akSpeakerRef) Native
String Function GetState() Native
Function GotoState(String newState) Native
