Scriptname CompanionPowerArmorKeywordScript Extends Actor

keyword Property isPowerArmorFrame Auto
keyword Property pAttachSlot2 Auto
keyword Property pAttachPassenger Auto

Event OnItemEquipped(form akBaseObject, objectreference akReference)
EndEvent

Event OnItemUnequipped(form akBaseObject, objectreference akReference)
EndEvent
