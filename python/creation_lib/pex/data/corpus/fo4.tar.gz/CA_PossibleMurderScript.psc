Scriptname CA_PossibleMurderScript Extends Quest

Event OnStoryKillActor(objectreference akVictim, objectreference akKiller, location akLocation, Int aiCrimeStatus, Int aiRelationshipRank)
EndEvent
