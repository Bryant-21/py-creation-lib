Scriptname DefaultSetActorValueEffectScript Extends ActiveMagicEffect

actorvalue Property ActorValueToSet Auto
Float Property ValueToSetOnFinish Auto
Float Property ValueToSetOnStart Auto

Event OnEffectFinish(objectreference akTarget, actor akCaster, magiceffect akBaseEffect, Float afMagnitude, Float afDuration)
EndEvent

Event OnEffectStart(objectreference akTarget, actor akCaster, magiceffect akBaseEffect, Float afMagnitude, Float afDuration)
EndEvent
