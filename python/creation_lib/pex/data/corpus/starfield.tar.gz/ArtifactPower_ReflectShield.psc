Scriptname ArtifactPower_ReflectShield Extends ActiveMagicEffect

perk Property ReflectPerk Auto

Function OnEffectFinish(objectreference akTarget, actor akCaster, magiceffect akBaseEffect, Float afMagnitude, Float afDuration) Native
Function OnEffectStart(objectreference akTarget, actor akCaster, magiceffect akBaseEffect, Float afMagnitude, Float afDuration) Native
