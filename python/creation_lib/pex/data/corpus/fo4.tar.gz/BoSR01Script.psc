Scriptname BoSR01Script Extends Quest

locationalias Property Dungeon Auto
Int Property StageToSet Auto
