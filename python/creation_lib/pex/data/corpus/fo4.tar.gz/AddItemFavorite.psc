Scriptname AddItemFavorite Extends ObjectReference

globalvariable Property ItemHasFavorited Auto Const
Int Property FavoriteSlot Auto Const

Event OnContainerChanged(ObjectReference akNewContainer, ObjectReference akOldContainer)
EndEvent

Event OnInit()
EndEvent
