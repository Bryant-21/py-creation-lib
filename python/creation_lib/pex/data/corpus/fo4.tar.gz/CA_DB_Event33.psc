Scriptname CA_DB_Event33 Extends ca_dialoguebump_basescript

Function InitializeEventID() Native
