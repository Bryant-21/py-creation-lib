Scriptname ccBGSFO4116:TerminalScript Extends Terminal

objectreference Property Smelter02 Auto Const
objectreference Property Cart01 Auto Const
objectreference Property Smelter01 Auto Const
globalvariable Property ccBGSFO4116_SmelterToggle Auto Const
sound Property SmelterSound Auto Const
objectreference Property SoundMarker Auto Const
objectreference Property FireEffects Auto Const
Float Property Speed Auto Const
Int Property StagetoSet Auto Const
objectreference Property Cart02 Auto Const
quest Property MyQuest Auto Const
objectreference Property Smelter03 Auto Const
objectreference Property Cart03 Auto Const

Function OnMenuItemRun(Int auiMenuItemID, objectreference akTerminalRef) Native
