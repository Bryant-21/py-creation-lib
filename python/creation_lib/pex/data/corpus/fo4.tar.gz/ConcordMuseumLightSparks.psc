Scriptname ConcordMuseumLightSparks Extends ObjectReference

keyword Property LinkCustom01 Auto Const

Function EnableDisableLight() Native
