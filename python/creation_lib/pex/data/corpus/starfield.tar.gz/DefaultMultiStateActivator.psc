Scriptname DefaultMultiStateActivator Extends ObjectReference

Struct AnimationStateDatum
    String StateJumpAnim01
    String StateJumpAnim02
    Bool EnableOverrideActivateText
    Bool BlockActivationHideText
    message OverrideDisplayName
    Bool EnableBlockActivation
    message OverrideActivateText
    String StateName
    String StateStartAnim01
    String StateStartAnim02
    Bool EnableOverrideDisplayName
    Bool BlockActivation
EndStruct

Int Property CurrentStateIndex Auto
String Property StartStateName Auto
animationstatedatum[] Property AnimationStateData Auto

String Function GetCurrentStateName() Native
Function OnLoad() Native
Function Private_SetAnimationStateIndex(Int newStateIndex, Bool shouldUseJumpAnims) Native
Function SetAnimationState(String newStateName, Bool shouldUseJumpAnims) Native
