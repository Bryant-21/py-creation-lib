Scriptname DefaultRefOnEquipped Extends DefaultRef

Event OnEquipped(actor akActor)
EndEvent
