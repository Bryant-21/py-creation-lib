Scriptname AudioRepeaterActivator Extends ObjectReference

sound Property SoundDescriptor Auto
Float Property delayMin Auto
Float Property delayMax Auto

Float Function GetWaitTime() Native
Event OnCellAttach()
EndEvent

Event OnCellDetach()
EndEvent

Event OnTimer(Int aiTimerID)
EndEvent
