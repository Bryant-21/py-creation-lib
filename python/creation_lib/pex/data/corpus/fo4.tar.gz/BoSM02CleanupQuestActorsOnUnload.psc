Scriptname BoSM02CleanupQuestActorsOnUnload Extends Actor

quest Property BoSM02 Auto

Event OnUnload()
EndEvent
