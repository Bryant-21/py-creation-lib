Scriptname DefaultAliasOnAggro Extends DefaultAlias

objectreference[] Property TargetingOrHitByOneOfTheseReferences Auto
Bool Property PlayerOnly Auto
Int Property CombatStateToCheckFor Auto
referencealias[] Property TargetingOrHitByOneOfTheseAliases Auto
faction[] Property TargetingOrHitByOneOfTheseFactions Auto

Event OnAliasInit()
EndEvent

Event OnCombatStateChanged(actor akTarget, Int aeCombatState)
EndEvent

Event OnHit(objectreference akTarget, objectreference akAggressor, form akSource, projectile akProjectile, Bool abPowerAttack, Bool abSneakAttack, Bool abBashAttack, Bool abHitBlocked, String asMaterialName)
EndEvent
