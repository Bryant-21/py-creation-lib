Scriptname ccOTMFO4001:ccOTMFO4001_CagedMirelurkScript Extends Actor

faction Property ccOTMFO4001_EnclaveFaction Auto
faction Property CreatureFaction Auto
actorvalue Property Suspicious Auto
actorvalue Property Aggression Auto
Float Property aggressionOnReset Auto
Float Property suspicionOnRelease Auto
faction Property MirelurkFaction Auto
Float Property suspicionOnReset Auto
Float Property aggressionOnRelease Auto

Function CellDoorOpened() Native
Function OnReset() Native
