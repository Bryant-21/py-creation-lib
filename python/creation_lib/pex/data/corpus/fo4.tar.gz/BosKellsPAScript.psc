Scriptname BosKellsPAScript Extends Quest

globalvariable Property KellsPABlocked Auto
globalvariable Property KellsPACooldown Auto
scene Property BoS_KellsPA_Scene Auto

Function CancelKellsPATimer() Native
Function FireScene() Native
Event OnTimerGameTime(Int aiTimerID)
EndEvent

Function StartKellsPATimer() Native
