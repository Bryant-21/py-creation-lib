Scriptname abSentryBotSelfDestruct Extends RobotSelfDestructScript

explosion Property onDeathExplosionFX Auto
explosion Property selfDestructExplosionFX Auto

Function Explode(actor selfRef) Native
Event OnActivate(objectreference akActionRef)
EndEvent

Event OnBeginState(String asOldState)
EndEvent

Event OnCombatStateChanged(actor akTarget, Int aeCombatState)
EndEvent

Event OnCripple(actorvalue akActorValue, Bool abCrippled)
EndEvent

Event OnDying(actor akKiller)
EndEvent

Function ResetSelfDestruct() Native
