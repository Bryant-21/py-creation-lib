Scriptname BladesSparringScript Extends ReferenceAlias

ReferenceAlias Property Opponent Auto

String Function GetState() Native
Function GotoState(String newState) Native
Function OnHit(ObjectReference akAggressor, Form akWeapon, Projectile akProjectile, Bool abPowerAttack, Bool abSneakAttack, Bool abBashAttack, Bool abHitBlocked) Native
Function OnMagicEffectApply(ObjectReference akCaster, MagicEffect akEffect) Native
