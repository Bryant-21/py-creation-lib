Scriptname DefaultCollectionAliasOnItemRemoved Extends DefaultCollectionAlias

form Property ItemFilter Auto

Function OnAliasInit() Native
Function OnItemRemoved(objectreference akSenderRef, form akBaseItem, Int aiItemCount, objectreference akItemReference, objectreference akDestContainer, Int aiTransferReason) Native
