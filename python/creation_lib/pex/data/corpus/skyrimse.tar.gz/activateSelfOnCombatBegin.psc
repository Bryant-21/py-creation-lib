Scriptname activateSelfOnCombatBegin Extends Actor

String Function GetState() Native
Function GotoState(String newState) Native
Function OnCombatStateChanged(Actor actorRef, Int combatState) Native
