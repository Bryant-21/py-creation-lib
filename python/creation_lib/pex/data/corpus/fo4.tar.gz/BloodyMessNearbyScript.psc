Scriptname BloodyMessNearbyScript Extends ActiveMagicEffect

Float Property ChanceDismember Auto Const

Event OnEffectStart(actor akTarget, actor akCaster)
EndEvent
