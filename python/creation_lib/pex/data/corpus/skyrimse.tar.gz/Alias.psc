Scriptname Alias

Quest Function GetOwningQuest() Native
String Function GetState() Native
Function GotoState(String newState) Native
Function OnAnimationEvent(ObjectReference akSource, String asEventName) Native
Function OnAnimationEventUnregistered(ObjectReference akSource, String asEventName) Native
Function onBeginState() Native
Function onEndState() Native
Function OnGainLOS(Actor akViewer, ObjectReference akTarget) Native
Function OnLostLOS(Actor akViewer, ObjectReference akTarget) Native
Function OnSleepStart(Float afSleepStartTime, Float afDesiredSleepEndTime) Native
Function OnSleepStop(Bool abInterrupted) Native
Function OnTrackedStatsEvent(String arStatName, Int aiStatValue) Native
Function OnUpdate() Native
Function OnUpdateGameTime() Native
Bool Function RegisterForAnimationEvent(ObjectReference akSender, String asEventName) Native
Function RegisterForLOS(Actor akViewer, ObjectReference akTarget) Native
Function RegisterForSingleLOSGain(Actor akViewer, ObjectReference akTarget) Native
Function RegisterForSingleLOSLost(Actor akViewer, ObjectReference akTarget) Native
Function RegisterForSingleUpdate(Float afInterval) Native
Function RegisterForSingleUpdateGameTime(Float afInterval) Native
Function RegisterForSleep() Native
Function RegisterForTrackedStatsEvent() Native
Function RegisterForUpdate(Float afInterval) Native
Function RegisterForUpdateGameTime(Float afInterval) Native
Function StartObjectProfiling() Native
Function StopObjectProfiling() Native
Function UnregisterForAnimationEvent(ObjectReference akSender, String asEventName) Native
Function UnregisterForLOS(Actor akViewer, ObjectReference akTarget) Native
Function UnregisterForSleep() Native
Function UnregisterForTrackedStatsEvent() Native
Function UnregisterForUpdate() Native
Function UnregisterForUpdateGameTime() Native
