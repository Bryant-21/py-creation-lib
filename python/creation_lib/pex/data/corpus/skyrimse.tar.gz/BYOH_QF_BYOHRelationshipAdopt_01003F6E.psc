Scriptname BYOH_QF_BYOHRelationshipAdopt_01003F6E Extends Quest

referencealias Property Alias_Child1 Auto
locationalias Property Alias_HomeLocation Auto
referencealias Property Alias_Child2 Auto
referencealias Property Alias_Spouse Auto
locationalias Property Alias_CityLocation Auto
referencealias Property Alias_TravelTargetMarker Auto

String Function GetState() Native
Function GotoState(String newState) Native
