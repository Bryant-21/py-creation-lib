Scriptname AttachAshPile Extends ActiveMagicEffect

Bool Property onEffectStartOveride Auto
Bool Property bSetAlphaToZeroEarly Auto
Bool Property bSetAlphaZero Auto
effectshader Property MagicEffectShader Auto
activator Property AshPileObject Auto
Float Property ShaderDuration Auto
Float Property fDelay Auto
Float Property fDelayEnd Auto

Event OnDying(objectreference Killer)
EndEvent

Event OnEffectStart(objectreference Target, actor Caster, magiceffect akBaseEffect, Float afMagnitude, Float afDuration)
EndEvent

Event OnInit()
EndEvent

Event OnTimer(Int aiTimerID)
EndEvent
