Scriptname critCryoFreezeSCRIPT Extends ActiveMagicEffect

actorvalue Property pAnimationMult Auto
actorvalue Property pFreeze Auto
Int Property newSpeedPercent Auto
actorvalue Property pHealth Auto

Event OnEffectFinish(actor akTarget, actor akCaster)
EndEvent

Event OnEffectStart(actor akTarget, actor akCaster)
EndEvent
