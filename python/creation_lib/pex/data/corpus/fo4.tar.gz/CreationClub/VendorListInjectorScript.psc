Scriptname CreationClub:VendorListInjectorScript Extends Quest

leveleditem Property LLC_WorkshopVendorArmor02 Auto Const
leveleditem Property LL_Vendor_Weapon_GunBoS Auto Const
leveleditem Property LLC_WorkshopVendorArmor03 Auto Const
leveleditem Property VL_Vendor_General_Drumlin Auto Const
leveleditem Property LL_Vendor_Weapon_GunSpecialty Auto Const
leveleditem Property VL_Vendor_Clothing Auto Const
leveleditem Property VL_Vendor_General Auto Const
leveleditem Property LLC_DCShopArmor Auto Const
leveleditem Property VL_Vendor_Armor Auto Const
leveleditem Property LLC_WorkshopVendorArmor01 Auto Const
leveleditem Property VL_Vendor_Weapon Auto Const
leveleditem Property LLI_Armor_BoSCombatArmor_Vendor_Outfit Auto Const

Function AddToVendorArmorLists(leveleditem itemToAdd, Int Level = 1, Int Quantity = 1, Bool AddToBoS = True) Native
Function AddToVendorWeaponLists(leveleditem itemToAdd, Int Level = 1, Int Quantity = 1, Bool AddToBoS = True) Native
