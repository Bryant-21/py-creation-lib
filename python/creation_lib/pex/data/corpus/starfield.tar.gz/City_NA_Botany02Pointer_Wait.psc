Scriptname City_NA_Botany02Pointer_Wait Extends Quest

Int Property StageToSet Auto

Function OnTimerGameTime(Int aiTimerID) Native
Function Wait24() Native
