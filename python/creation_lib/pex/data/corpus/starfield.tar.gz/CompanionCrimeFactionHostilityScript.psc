Scriptname CompanionCrimeFactionHostilityScript Extends Actor

faction[] Property IgnoreSharedCrimeForAnyoneInTheseFactions Auto

Event OnCombatStateChanged(objectreference akTarget, Int aeCombatState)
EndEvent

Event OnTimer(Int aiTimerID)
EndEvent

Function TestForSharedCrimeCombatants() Native
