Scriptname AventusSacramentTriggerScript Extends ObjectReference

scene Property pAventusSacramentScene Auto

String Function GetState() Native
Function GotoState(String newState) Native
Function OnTriggerEnter(ObjectReference AkActivator) Native
