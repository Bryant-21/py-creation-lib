Scriptname COMTalkQuestScript Extends Quest

companionactorscript Property CompanionActor Auto
globalvariable Property CA_T1_Infatuation Auto
globalvariable Property CA_T2_Admiration Auto
globalvariable Property CA_T5_Hatred Auto
globalvariable Property CA_T4_Disdain Auto
globalvariable Property CA_T3_Neutral Auto

Function ShowAdmirationMessage() Native
Function ShowDisdainMessage() Native
Function ShowHatredMessage() Native
Function ShowInfatuationMessage() Native
Function ShowNeutralMessage() Native
Function ShowRomanticInfatuationMessage() Native
