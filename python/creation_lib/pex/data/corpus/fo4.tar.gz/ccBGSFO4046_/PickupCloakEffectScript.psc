Scriptname ccBGSFO4046_:PickupCloakEffectScript Extends activemagiceffect

actorvalue Property PipBoyActorValue Auto Const
armor Property PipBoyThree Auto
armor Property PipBoyOne Auto
keyword Property BlockKeyword Auto Const
keyword Property DataDoneKeyword Auto Const
armor Property PipBoyTwo Auto

Function OnEffectStart(actor akTarget, actor akCaster) Native
