Scriptname BoSM02DanseOverrides_TriggerScript Extends ObjectReference

quest Property BoSM02 Auto Const
quest Property BoSM02DanseOverrides Auto Const
referencealias Property BoSM02PaladinDanse Auto Const
Bool Property shouldStartOverride Auto Const
referencealias Property Companion Auto Const

Event OnTriggerEnter(ObjectReference akActionRef)
EndEvent
