Scriptname DefaultContainerAddRefsOnLoad Extends ObjectReference

keyword Property LinkAddItem Auto

Function OnCellLoad() Native
