Scriptname DefaultAliasOnCellLoad Extends DefaultAliasParent

Event OnCellLoad()
EndEvent
