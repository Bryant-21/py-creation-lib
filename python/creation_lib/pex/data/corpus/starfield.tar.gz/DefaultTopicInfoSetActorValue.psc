Scriptname DefaultTopicInfoSetActorValue Extends TopicInfo

Bool Property OnEnd Auto
Bool Property SetActorValueToNewValue Auto
Float Property NewValue Auto
actorvalue Property ValueToModify Auto
Bool Property SetOnPlayer Auto
Bool Property SetOnSpeaker Auto

Function ChangeActorValue(objectreference refToModify) Native
Function HandleActorValueChange(objectreference akSpeakerRef) Native
Function OnBegin(objectreference akSpeakerRef, Bool abHasBeenSaid) Native
Function OnEnd(objectreference akSpeakerRef, Bool abHasBeenSaid) Native
