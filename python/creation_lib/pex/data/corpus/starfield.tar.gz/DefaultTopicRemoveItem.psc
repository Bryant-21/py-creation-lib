Scriptname DefaultTopicRemoveItem Extends TopicInfo

globalvariable Property ItemCountToRemoveGlobal Auto
Int Property ItemCountToRemove Auto
Bool Property RemoveItemOnBegin Auto
miscobject Property MiscItemToRemove Auto
Bool Property RemoveItemOnEnd Auto

Function OnBegin(objectreference akSpeakerRef, Bool abHasBeenSaid) Native
Function OnEnd(objectreference akSpeakerRef, Bool abHasBeenSaid) Native
Function RemoveItem() Native
