Scriptname defaultStartSceneOnActivate Extends ObjectReference

scene Property SceneToPlay Auto

Event OnActivate(ObjectReference akActionRef)
EndEvent
