Scriptname ccOTMFO4001:ccOTMFO4001_EncEncounterTriggerScript Extends ObjectReference

keyword Property ccOTMFO4001_EncEncounter Auto
Float Property ResetDays Auto
globalvariable Property NearestEncampmentGlobal Auto
Float Property EncounterChance Auto

Function EncounterStarted(ccotmfo4001:ccotmfo4001_encencounterquestscript Encounter) Native
Function OnLoad() Native
Function OnUnload() Native
