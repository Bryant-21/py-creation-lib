Scriptname bpwMatchCardScript Extends ObjectReference

Bool Property DIAMONDS Auto
ObjectReference Property DiamondsB Auto
Bool Property HEARTS Auto
Bool Property SPADES Auto
ObjectReference Property SheoA Auto
ObjectReference Property portDoor Auto
ObjectReference Property HeartsB Auto
Bool Property SHEO Auto
ObjectReference Property DiamondsA Auto
ObjectReference Property SheoB Auto
ObjectReference Property skeevDoor Auto
ObjectReference Property SpadesB Auto
Bool Property CLUBS Auto
ObjectReference Property ClubsB Auto
ObjectReference Property ClubsA Auto
ObjectReference Property HeartsA Auto
ObjectReference Property SpadesA Auto
ObjectReference Property controllerScript Auto

String Function GetState() Native
Function GotoState(String newState) Native
Function onACTIVATE(ObjectReference obj) Native
Function onLoad() Native
