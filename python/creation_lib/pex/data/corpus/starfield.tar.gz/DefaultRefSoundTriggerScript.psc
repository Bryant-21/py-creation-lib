Scriptname DefaultRefSoundTriggerScript Extends ObjectReference

wwiseevent Property SoundToPlayEvent Auto
keyword Property LinkKeyword Auto
Bool Property PlayOnceOnly Auto
Bool Property UseLinkKeyword Auto
Bool Property PlayerTriggerOnly Auto

Function OnTriggerEnter(ObjectReference triggerRef) Native
