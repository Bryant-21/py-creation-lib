Scriptname CryopodPostWarScript Extends ObjectReference

cell Property Vault111Cryo Auto
quest Property DialogueVault111 Auto

Event OnActivate(ObjectReference akActionRef)
EndEvent

Event OnInit()
EndEvent
