Scriptname DefaultAliasOnShipSystemPowerChange Extends ReferenceAlias

Struct SystemPowerChangeStage
    Int StageToSet
    Int TurnOffStage
    Int PrereqStage
    Bool SetStageOnlyFromNormalPowerChange
    Bool SetStageOnlyWhenPowerAdded
    actorvalue TargetSystem
EndStruct

systempowerchangestage[] Property SystemPowerChangeStages Auto
Bool Property ShowTraces Auto
Int Property TurnOffStageDone Auto
Int Property TurnOffStage Auto
Int Property PrereqStage Auto

Function OnShipSystemPowerChange(actorvalue akSystem, Bool abAddPower, Bool abDamageRelated) Native
