Scriptname AOScript Extends Quest

Struct AO_Dogmeat_Find_Datum
    globalvariable NextAllowed
    globalvariable Type
    globalvariable CoolDown
EndStruct

Int Property iTimerID_Dogmeat_Find Auto Const
keyword Property AO_Dogmeat_Find_Start Auto Const
Int Property iTimerID_Companion_Search Auto Const
ao_dogmeat_find_datum[] Property AO_Dogmeat_Find_Data Auto Const
keyword[] Property TempAOKeywords Auto Const
globalvariable Property AO_Dogmeat_Find_Allowed Auto Const
keyword Property AO_Finished Auto Const
keyword Property AO_Companion_Search_Start Auto Const
globalvariable Property AO_Companion_Search_Allowed Auto Const
Float Property TimerInterval_Companion_Search Auto Const
keyword Property AOKeywordForLockDoors Auto Const
referencealias Property Companion Auto Const
keyword Property AO_Dogmeat_FindItem_Commanded_Start Auto Const
keyword Property AO_Dogmeat_FindContainer_Commanded_Start Auto Const
Float Property TimerInterval_Dogmeat_Find Auto Const
keyword Property AO_Dogmeat_FindHostile_Commanded_Start Auto Const
keyword Property TempAOStart Auto Const
formlist Property TempAOList Auto Const
referencealias Property DogmeatCompanion Auto Const

Function DogmeatFindEventEnded(globalvariable AO_Dogmeat_FindType_GLOBAL) Native
Function DogmeatFindEventStarted() Native
Function DogmeatLoading(Bool isDogmeatLoading = true) Native
Function FlagObjectAliasFinished(referencealias AliasToFlagWithKeyword) Global Native
Function FlagObjectFinished(objectreference ObjectToFlagWithKeyword) Global Native
AOScript Function GetScript() Global Native
Function HandleTimer_Companion_Search() Native
Function HandleTimer_DogmeatFind() Native
Function HandleTimer_DogmeatFindCoolDown() Native
Event OnInit()
EndEvent

Event OnTimer(Int aiTimerID)
EndEvent

Bool Function SendDogmeatFindContainerStoryManagerEvent() Native
Bool Function SendDogmeatFindHostileStoryManagerEvent() Native
Bool Function SendDogmeatFindItemStoryManagerEvent() Native
