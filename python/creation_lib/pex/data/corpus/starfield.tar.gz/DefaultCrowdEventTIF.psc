Scriptname DefaultCrowdEventTIF Extends TopicInfo

keyword Property EventToSend Auto
Bool Property SendOnEnd Auto
Bool Property SendOnBegin Auto

Event OnBegin(objectreference akSpeakerRef, Bool abHasBeenSaid)
EndEvent

Event OnEnd(objectreference akSpeakerRef, Bool abHasBeenSaid)
EndEvent
