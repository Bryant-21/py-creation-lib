Scriptname DefaultCounter Extends objectReference

Int Property TargetValue Auto
Bool Property AllowDecrementing Auto
Int Property LinkedRefAction Auto
keyword Property LinkedRefKeyword Auto
Int Property StageToSet Auto
quest Property QuestToSet Auto

Function Decrement() Native
Function Increment() Native
