Scriptname BoSKickOutDanseCustomScript Extends ReferenceAlias

quest Property BoSKickOut Auto
quest Property BOS302 Auto

Event OnDying(actor akKiller)
EndEvent
