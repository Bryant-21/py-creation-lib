Scriptname DefaultAliasOnCombatStateChanged Extends DefaultAlias

Int Property CombatStateToCheckFor Auto
referencealias[] Property TargetIsOneOfTheseAliases Auto
faction[] Property TargetIsOneOfTheseFactions Auto
objectreference[] Property TargetIsOneOfTheseReferences Auto

Event OnCombatStateChanged(actor akTarget, Int aeCombatState)
EndEvent
