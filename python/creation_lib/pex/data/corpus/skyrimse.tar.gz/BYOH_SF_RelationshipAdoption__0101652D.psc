Scriptname BYOH_SF_RelationshipAdoption__0101652D Extends Scene

referencealias Property Child1 Auto
referencealias Property Child2 Auto

Function Fragment_0() Native
Function Fragment_1() Native
String Function GetState() Native
Function GotoState(String newState) Native
