Scriptname BYOH_TIF__01003E02 Extends TopicInfo

referencealias Property RiftenHouse Auto
referencealias Property SolitudeHouse Auto
referencealias Property WindhelmHouse Auto
referencealias Property HjaalmarchHouse Auto
referencealias Property WhiterunHouse Auto
referencealias Property MarkarthHouse Auto

Function Fragment_0(ObjectReference akSpeakerRef) Native
String Function GetState() Native
Function GotoState(String newState) Native
