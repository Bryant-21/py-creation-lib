Scriptname COMCurieIntroScript Extends ObjectReference

quest Property pMS19 Auto
quest Property pCOMCurie Auto

Event OnTriggerEnter(ObjectReference akActionRef)
EndEvent
