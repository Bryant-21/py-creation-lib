Scriptname BoS302BWallDetonatorScript Extends ObjectReference

sound Property OBJExplosiveArmLP Auto

Event OnActivate(ObjectReference akActionRef)
EndEvent
