Scriptname COMX688TalkPlayerAliasScript Extends ReferenceAlias

location Property InstituteLocation Auto Const
quest Property COMX688Talk Auto
globalvariable Property CompanionX6TeleportDestination Auto Const
globalvariable Property CompanionX6Disabled Auto Const
ReferenceAlias Property Alias_X6 Auto

Event OnLocationChange(location akOldLoc, location akNewLoc)
EndEvent
