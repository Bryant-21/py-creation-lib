Scriptname CZSpotlightScript Extends ObjectReference

ObjectReference Property RefToWatch Auto
String[] Property AnimNames Auto
Float Property LightOnIntensity Auto
ObjectReference Property CZStageControllerRef Auto
czstagecontrollerscript Property StageController Auto

Function CallSequenceComplete() Native
Function CleanUp() Native
String Function GetAnim(Int SequenceNumberToGet) Native
Function Init() Native
Event OnAnimationEvent(ObjectReference akSource, String asEventName)
EndEvent

Event onCellLoad()
EndEvent

Event OnTimer(Int aiTimerID)
EndEvent

Event OnUnload()
EndEvent

Bool Function RunSequence(Int SequenceNumber, Float SequenceSpeed, Bool hasLightSequence, Int LightState, Float LightTarget, Float lightChangeSpeed, Bool overrideOrders) Native
Function SetLightColor(Float LightTarget, Float lightChangeSpeed = 0.3) Native
Function ShutOffSpotlight() Native
Function StartDirectAt(ObjectReference akActionRef) Native
Function StartLightSequence(Float localLightTarget, Float localLightChangeSpeed) Native
Function StopDirectAt() Native
Function TestSeq(Int SequenceNumber) Native
Function TurnOnSpotlight() Native
