Scriptname DefaultAliasOnUnload Extends DefaultAlias

Event OnUnload()
EndEvent
