Scriptname CuttableWallScript Extends ObjectReference

keyword Property LinkCustom01 Auto
wwiseevent Property DRS_Cuttable_IndIntRmSmWallMid_PlugA03_PlugCut Auto
keyword Property LinkCustom02 Auto

Function IntializeCuttableWall() Native
Function OnCellLoad() Native
Function OnReset() Native
Function ReleasePanel() Native
