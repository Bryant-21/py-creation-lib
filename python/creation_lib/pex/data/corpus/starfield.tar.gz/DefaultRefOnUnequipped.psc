Scriptname DefaultRefOnUnequipped Extends DefaultRef

Event OnUnequipped(actor akActor)
EndEvent
