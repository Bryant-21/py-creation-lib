Scriptname BoS302BQuestScript Extends Quest

globalvariable Property BoS302BTomDead Auto Const
referencealias Property Alias_PAM Auto Const
actorbase Property TinkerTom Auto Const
objectreference Property BoS302BPAMMarker Auto Const
objectreference Property BoS302BTinkerTomMarker Auto Const
actorbase Property DoctorCarrington Auto Const
referencealias Property Alias_Deacon Auto Const
actorbase Property CompanionDeacon Auto Const
globalvariable Property BoS302BGloryDead Auto Const
objectreference Property BoS302BDeaconMarker Auto Const
actorbase Property PAM Auto Const
globalvariable Property BoS302BCarDead Auto Const
objectreference Property BoS302BGloryMarker Auto Const
globalvariable Property BoS302BBossKills Auto Const
objectreference Property BoS302BCarringtonMarker Auto Const
referencealias Property Alias_Glory Auto Const
referencealias Property Alias_TinkerTom Auto Const
referencealias Property Alias_Carrington Auto Const
referencealias Property Alias_Desdemona Auto Const
actorbase Property Desdemona Auto Const
globalvariable Property BoS302BDesDead Auto Const
actorbase Property Glory Auto Const
globalvariable Property BoS302BDeaconDead Auto Const
objectreference Property BoS302BDesdemonaMarker Auto Const
globalvariable Property BoS302BPAMDead Auto Const

Function DeathCheck() Native
Function MoveCheck() Native
