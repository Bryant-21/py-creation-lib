Scriptname BYOH_PF_BYOHHouseBanditAttack_010008AD Extends Package

Function Fragment_0(Actor akActor) Native
Function Fragment_1(Actor akActor) Native
String Function GetState() Native
Function GotoState(String newState) Native
