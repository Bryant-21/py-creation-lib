Scriptname defaultQuestRespawnScript Extends Quest

Int Property MinRespawnDistance Auto
objectreference[] Property RespawnMarkers Auto
Int Property DoneStage Auto
Int Property RespawnTimeMax Auto
Int Property respawnCount Auto
Bool Property ShowTraces Auto
objectreference Property RespawnMarkerFailsafe Auto
Int Property StartStage Auto
Int Property RespawnTimeMin Auto
Int Property RespawnPool Auto

objectreference Function GetRespawnMarker() Native
Bool Function ReadyToRespawn() Native
Function Respawn(referencealias aliasToRespawn) Native
Function RespawnCollection(refcollectionalias collectionToRespawn, actor actorToRespawn) Native
Function TryToRespawn(referencealias aliasToRespawn) Native
Function TryToRespawnCollection(refcollectionalias collectionToRespawn, actor actorToRespawn) Native
