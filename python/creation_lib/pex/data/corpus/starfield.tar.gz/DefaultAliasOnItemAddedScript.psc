Scriptname DefaultAliasOnItemAddedScript Extends DefaultAlias

form Property ItemFilter Auto

Function OnAliasInit() Native
Function OnItemAdded(form akBaseItem, Int aiItemCount, objectreference akItemReference, objectreference akSourceContainer, Int aiTransferReason) Native
