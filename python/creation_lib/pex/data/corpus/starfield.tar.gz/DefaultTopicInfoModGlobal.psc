Scriptname DefaultTopicInfoModGlobal Extends TopicInfo

Float Property OnEndMod Auto
globalvariable Property SetGlobalOnBegin Auto
Float Property OnBeginMod Auto
globalvariable Property SetGlobalOnEnd Auto

Function OnBegin(objectreference akSpeakerRef, Bool abHasBeenSaid) Native
Function OnEnd(objectreference akSpeakerRef, Bool abHasBeenSaid) Native
