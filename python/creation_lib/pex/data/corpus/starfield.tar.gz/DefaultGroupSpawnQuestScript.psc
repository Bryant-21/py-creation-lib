Scriptname DefaultGroupSpawnQuestScript Extends Quest

Struct SpawnGroupDoneEventArgs
    Int SpawnGroupNumber
    sq_groupoccupationscript SpawnedOccupation
    sq_groupscript SpawnedGroup
EndStruct

Struct SpawnGroup_DefinitionDatum
    faction crimeFaction
    sq_groupoccupationscript ChosenOccupation
    String Name
    Int Aggression
    Bool AllowSpawningIntoNonEmptyAliases
    Int SpawnStage
    locationalias LocationAliasToSetOwnershipOn
    globalvariable Role
    referencealias ConditionAlias
    conditionform Conditions
    sq_groupscript ChosenGroup
EndStruct

Struct SpawnEventArgs
    alias SpawnAtAlias
    alias SpawnAlias
    sq_groupoccupationscript SpawnedOccupation
    Int SpawnGroupNumber
    sq_groupscript SpawnedGroup
    Int SpawnDataIndex
EndStruct

Struct SpawnGroup_SpawnDatum
    Bool IsVendor
    Bool Register_With_REScript
    alias SpawnAlias
    Bool InitiallyDisabled
    conditionform SpawnConditions
    Int StageToSpawn
    Bool LinkToSpawnAtWithNoKeyword
    keyword LinkToSpawnAt
    Bool SpawnAllAtEach
    Int MaxToSpawn
    Int MinToSpawn
    alias SpawnAt
    globalvariable SpawnType
    globalvariable Gender
    Bool SetOverrideNameLeader
    Bool SetOverrideNameVendor
EndStruct

globalvariable Property SQ_Group_RandomOccupationIndexOverride Auto
formlist[] Property SpawnGroupB_AllowedOccupations Auto
Bool Property GroupSetupCompleted Auto
formlist[] Property SpawnGroupE_AllowedOccupations Auto
spawngroup_spawndatum[] Property SpawnGroupE_SpawnData Auto
String Property LocalScriptName Auto
formlist[] Property SpawnGroupE_AllowedGroups Auto
spawngroup_definitiondatum Property SpawnGroupE_Definition Auto
spawngroup_spawndatum[] Property SpawnGroupD_SpawnData Auto
formlist[] Property SpawnGroupD_AllowedOccupations Auto
formlist[] Property SpawnGroupD_AllowedGroups Auto
spawngroup_definitiondatum Property SpawnGroupD_Definition Auto
spawngroup_spawndatum[] Property SpawnGroupC_SpawnData Auto
formlist[] Property SpawnGroupC_AllowedOccupations Auto
formlist[] Property SpawnGroupC_AllowedGroups Auto
spawngroup_definitiondatum Property SpawnGroupC_Definition Auto
spawngroup_spawndatum[] Property SpawnGroupB_SpawnData Auto
spawngroup_definitiondatum Property SpawnGroupA_Definition Auto
formlist[] Property SpawnGroupA_AllowedGroups Auto
spawngroup_spawndatum[] Property SpawnGroupA_SpawnData Auto
formlist[] Property SpawnGroupA_AllowedOccupations Auto
sq_groups_questscript Property SQ_Groups Auto
spawngroup_definitiondatum Property SpawnGroupB_Definition Auto
formlist[] Property SpawnGroupB_AllowedGroups Auto

sq_groupscript[] Function ConvertAllowedGroupsToArray(formlist[] ArrayOfFormlistsToBuildFrom) Native
sq_groupoccupationscript[] Function ConvertAllowedOccupationsToArray(formlist[] ArrayOfFormlistsToBuildFrom) Native
Function DefineCustomLogs() Native
faction Function GetGroupOwnershipFaction(Int groupID) Native
spaceshipbase Function GetShipToSpawnForGroup(Int GroupToGetShipFor, objectreference landingMarkerRef, globalvariable SpawnType) Native
spawngroup_definitiondatum Function GetSpawnGroupDefinitionDatum(Int groupID) Native
spawngroup_spawndatum[] Function GetValidSpawnData(spawngroup_spawndatum[] SpawnData, Int iStageID) Native
Function InitialGroupSpawn(String LocalScriptName) Native
Function OnQuestInit() Native
Function OnStageSet(Int iStageID, Int iItemID) Native
Function ProcessGroupData(spawngroup_definitiondatum Definition, spawngroup_spawndatum[] SpawnData, Int StageToCheck) Native
Function ProcessGroups(Int iStageID) Native
Function SendSpawnEvent(spawneventargs Args) Native
Function SendSpawnGroupDoneEvent(spawngroupdoneeventargs Args) Native
Function SetDefaultName(spawngroup_definitiondatum GroupDefinitionToSetName, String DefaultName) Native
Function SetUpGroup(String DefaultName, spawngroup_definitiondatum Definition, formlist[] AllowedGroups, formlist[] AllowedOccupations) Native
Function SetUpGroups() Native
Bool Function Spawn(spawngroup_definitiondatum Definition, spawngroup_spawndatum[] SpawnData, spawngroup_spawndatum SpawnDatum) Native
Function Trace(ScriptObject CallingObject, String asTextToPrint, Int aiSeverity) Native
Bool Function WaitForInitialGroupSetup() Native
Function warning(ScriptObject CallingObject, String asTextToPrint, Bool DebugTrace, Int aiSeverity, Bool bShowNormalTrace, Bool bShowWarning, Bool bPrefixTraceWithLogNames) Native
