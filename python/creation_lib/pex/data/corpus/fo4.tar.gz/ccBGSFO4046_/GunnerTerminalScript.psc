Scriptname ccBGSFO4046_:GunnerTerminalScript Extends Terminal

objectreference Property NextGunnerRef Auto Const
Int Property MenuNumber Auto Const
Int Property StageToSet Auto Const
message Property SignalMessage Auto Const
quest Property RadioQuest Auto Const
quest Property CCQuest Auto Const

Function OnMenuItemRun(Int auiMenuItemID, objectreference akTerminalRef) Native
