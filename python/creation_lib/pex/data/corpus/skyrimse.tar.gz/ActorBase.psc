Scriptname ActorBase Extends Form

Class Function GetClass() Native
Int Function GetDeadCount() Native
FormList Function GetGiftFilter() Native
Race Function GetRace() Native
Int Function GetSex() Native
String Function GetState() Native
Function GotoState(String newState) Native
Bool Function IsEssential() Native
Bool Function IsInvulnerable() Native
Bool Function IsProtected() Native
Bool Function IsUnique() Native
Function SetEssential(Bool abEssential = true) Native
Function SetInvulnerable(Bool abInvulnerable = true) Native
Function SetOutfit(Outfit akOutfit, Bool abSleepOutfit = false) Native
Function SetProtected(Bool abProtected = true) Native
