Scriptname BoS201QuestScript Extends Quest

Quest Property BoS000 Auto Const
referencealias Property BoS201Danse Auto Const
Quest Property BoS200 Auto Const
inputenablelayer Property EnableLayer Auto
keyword Property pAttachSlot1 Auto
referencealias Property BoS201Kells Auto Const
referencealias Property BoS201Vertibird Auto Const
keyword Property pAttachSlot2 Auto
Quest Property BoS201 Auto Const
referencealias Property BoS201VertibirdPilot Auto Const
Quest Property BoS101 Auto Const

Function DanseKeyOff() Native
Function DanseKeyOn() Native
Function FlyoverStuff() Native
Function SilenceCombat() Native
