Scriptname BoS302EarlyExitTriggerScript Extends ObjectReference

quest Property BoS302 Auto Const

Event OnTriggerEnter(ObjectReference akActionRef)
EndEvent
