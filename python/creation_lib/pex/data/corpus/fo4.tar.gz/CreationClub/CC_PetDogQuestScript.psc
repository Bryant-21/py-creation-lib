Scriptname CreationClub:CC_PetDogQuestScript Extends Quest

perk Property CC_PetDogs_PetPerk Auto Const
idle Property PairedDogmeatHumanGreetPetKneel Auto Const
referencealias[] Property DogNames Auto
message Property RenameConfirmMsg Auto Const
idle Property PairedDogmeatHumanGreetHand Auto Const
perk Property CC_PetDogs_RenamePerk Auto Const

Function GivePlayerRenamePerk() Native
Function NameDog(objectreference dogToName) Native
Function NameDogWithConfirmation(objectreference dogToName) Native
Function PetDog(objectreference dogToPet) Native
