Scriptname CF05_HuanShip_Script Extends ReferenceAlias

ReferenceAlias Property Alias_CF05_HuanShip Auto

Function OnLoad() Native
