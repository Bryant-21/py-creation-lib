Scriptname BehemothSlamsFXScript Extends ActiveMagicEffect

explosion Property pBehemothSlamExplosion Auto Const
explosion Property pBehemothStompExplosion Auto Const

Event OnAnimationEvent(objectreference akSource, String asEventName)
EndEvent

Event OnEffectFinish(actor akTarget, actor akCaster)
EndEvent

Event OnEffectStart(actor akTarget, actor akCaster)
EndEvent
