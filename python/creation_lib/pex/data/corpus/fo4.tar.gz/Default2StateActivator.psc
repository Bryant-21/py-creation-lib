Scriptname Default2StateActivator Extends ObjectReference

Int Property myState Auto
String Property closeAnim Auto
Bool Property doOnce Auto
Bool Property isOpen Auto
Bool Property shouldOpenNext Auto
Bool Property isAnimating Auto
keyword Property TwoStateCollisionKeyword Auto
String Property startOpenAnim Auto
Bool Property shouldSetDefaultState Auto
Bool Property AllowInterrupt Auto
String Property openAnim Auto
Bool Property InvertCollision Auto
String Property openEvent Auto
String Property closeEvent Auto

Event onActivate(ObjectReference triggerRef)
EndEvent

Event OnLoad()
EndEvent

Event OnReset()
EndEvent

Event OnTimer(Int timerID)
EndEvent

Function SetDefaultState() Native
Function SetOpen(Bool abOpen = true) Native
Function SetOpenNoWait(Bool abOpen = true) Native
