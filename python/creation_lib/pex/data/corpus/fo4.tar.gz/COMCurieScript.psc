Scriptname COMCurieScript Extends Quest

cell Property pElevTransVault Auto
globalvariable Property pCOMCurieLeftVault Auto
location Property pVault81Location Auto
Int Property bRejectCompanion Auto

Function RegisterLocationChange() Native
