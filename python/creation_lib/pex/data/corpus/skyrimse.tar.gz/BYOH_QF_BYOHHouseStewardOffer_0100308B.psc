Scriptname BYOH_QF_BYOHHouseStewardOffer_0100308B Extends Quest

faction Property BYOHHouseStewardNoForcegreet Auto
referencealias Property Alias_LocationCenter Auto
locationalias Property Alias_houseLocation Auto
location Property BYOHHouse2Location Auto
referencealias Property Alias_FollowerAtHouse2 Auto
byohhousebuildingscript Property BYOHHouseBuilding Auto
referencealias Property Alias_FollowerAtHouse1 Auto
referencealias Property Alias_FollowerAtHouse3 Auto
location Property BYOHHouse1Location Auto
location Property BYOHHouse3Location Auto
referencealias Property Alias_Follower Auto

Function Fragment_0() Native
Function Fragment_2() Native
Function Fragment_4() Native
String Function GetState() Native
Function GotoState(String newState) Native
