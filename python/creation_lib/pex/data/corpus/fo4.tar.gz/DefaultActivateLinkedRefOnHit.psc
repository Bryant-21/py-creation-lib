Scriptname DefaultActivateLinkedRefOnHit Extends ObjectReference

keyword Property MyLink Auto

Event OnHit(ObjectReference akTarget, ObjectReference akAggressor, form akSource, projectile akProjectile, Bool abPowerAttack, Bool abSneakAttack, Bool abBashAttack, Bool abHitBlocked, String apMaterial)
EndEvent

Event OnLoad()
EndEvent
