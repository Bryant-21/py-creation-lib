Scriptname AddictionOddsScript Extends ActiveMagicEffect

Float Property Magnitude Auto
actorvalue Property TrackingActorValue Auto

Event OnEffectStart(objectreference akTarget, actor akCaster, magiceffect akBaseEffect, Float afMagnitude, Float afDuration)
EndEvent
