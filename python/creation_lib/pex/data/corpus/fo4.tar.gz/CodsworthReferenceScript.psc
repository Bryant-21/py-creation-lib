Scriptname CodsworthReferenceScript Extends Actor

Bool Property IsDamaged Auto

Function Damage() Native
Event OnLoad()
EndEvent
