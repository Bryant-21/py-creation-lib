Scriptname DefaultCounterQuest Extends DefaultQuest

Int Property TargetValue Auto

Function Decrement() Native
Function Increment() Native
