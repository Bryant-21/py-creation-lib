Scriptname AliasSetStageOnActorValueChanged Extends ReferenceAlias

actorvalue Property WatchedValue Auto
Int Property ShutdownStage Auto
Int Property PrereqStage Auto
Int Property StageToSet Auto
Int Property AVThreshold Auto

Function AliasValueRegistration(objectreference akTargetRef) Native
Function OnActorValueLessThan(objectreference akObjRef, actorvalue akActorValue) Native
Function OnAliasInit() Native
