Scriptname City_AkilaLife07_Script Extends Quest

globalvariable Property AkilaLife06_DocPending Auto

Function GotObject(Int nStage) Native
