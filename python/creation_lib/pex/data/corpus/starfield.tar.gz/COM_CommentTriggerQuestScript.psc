Scriptname COM_CommentTriggerQuestScript Extends Quest

scene Property CommentScene Auto
referencealias Property Alias_Target Auto
referencealias Property Alias_CommentTrigger Auto
referencealias Property Alias_Companion Auto

Function SendAffinityEvent() Native
Bool Function Trace(ScriptObject CallingObject, String asTextToPrint, Int aiSeverity, String MainLogName, String SubLogName, Bool bShowNormalTrace, Bool bShowWarning, Bool bPrefixTraceWithLogNames) Native
Bool Function warning(ScriptObject CallingObject, String asTextToPrint, Int aiSeverity, String MainLogName, String SubLogName, Bool bShowNormalTrace, Bool bShowWarning, Bool bPrefixTraceWithLogNames) Native
