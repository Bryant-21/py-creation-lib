Scriptname CA_DB_Event17 Extends ca_dialoguebump_basescript

Function InitializeEventID() Native
