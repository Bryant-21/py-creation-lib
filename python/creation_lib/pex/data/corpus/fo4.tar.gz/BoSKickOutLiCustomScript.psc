Scriptname BoSKickOutLiCustomScript Extends ReferenceAlias

quest Property BoSKickOut Auto
globalvariable Property BoSLiSlain Auto
quest Property BoS301 Auto

Event OnDying(actor akKiller)
EndEvent
