Scriptname ccFSVFO4007:KeypadScript Extends ObjectReference

Struct SafeDigit
    message Question
    Int Answer
EndStruct

ObjectReference Property myDoor Auto Const
Int Property StageToDisplay Auto Const
message Property LockedMessage Auto Const
quest Property myQuest Auto Const
Int Property StageToCheck Auto Const
safedigit[] Property Digits Auto Const
message Property WrongCode Auto Const
Int Property StageToSet Auto Const

Function onActivate(ObjectReference akActionRef) Native
