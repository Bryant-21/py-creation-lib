Scriptname BYOH_TIF__01004D04 Extends TopicInfo

miscobject Property Gold Auto
Int Property GoldAmount Auto
objectreference Property DecorateMarker Auto
globalvariable Property HDMarkarthChildRoom Auto

Function Fragment_0(objectreference akSpeakerRef) Native
String Function GetState() Native
Function GotoState(String newState) Native
