Scriptname BYOH_TIF__01003E5E Extends TopicInfo

faction Property RelationshipAdoptableFaction Auto

Function Fragment_0(ObjectReference akSpeakerRef) Native
String Function GetState() Native
Function GotoState(String newState) Native
