Scriptname BoSM02QuestScript Extends Quest

location Property BostonAirportRuinsLocation Auto
Quest Property BoSM02DanseOverrides Auto
scene Property BoSM02_ClarkeStage150_Follow0b Auto
referencealias Property BoSM02PaladinDanse Auto
Bool Property playerSeenByClarke Auto
scene Property BoSM02_ClarkeStage150_Follow0c Auto
Int Property rewardLevel Auto
referencealias Property Companion Auto
referencealias Property BoSClarke Auto

Event OnTimer(Int timerID)
EndEvent

Function StartClarkeMonitor() Native
Function StartDanseOverride() Native
Function StopDanseOverride() Native
