Scriptname BYOH_PF_BYOHUrchin_SofieWork8_0100402E Extends Package

Function Fragment_2(Actor akActor) Native
String Function GetState() Native
Function GotoState(String newState) Native
