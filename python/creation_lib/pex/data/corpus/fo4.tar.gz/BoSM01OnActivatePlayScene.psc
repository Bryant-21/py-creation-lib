Scriptname BoSM01OnActivatePlayScene Extends ObjectReference

scene Property BoSM01_Player_BattleSitePowerArmorComments Auto Const

Event OnActivate(ObjectReference akActivator)
EndEvent

Event OnLoad()
EndEvent
