Scriptname DefaultCounterIncrementOnActivate Extends ObjectReference

keyword Property LinkedRefKeyword Auto
Bool Property ShouldToggle Auto

Event OnActivate(ObjectReference akActionRef)
EndEvent
