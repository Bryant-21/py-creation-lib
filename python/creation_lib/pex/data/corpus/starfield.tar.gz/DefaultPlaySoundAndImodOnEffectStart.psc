Scriptname DefaultPlaySoundAndImodOnEffectStart Extends ActiveMagicEffect

wwiseevent Property SoundEvent Auto
Bool Property StartWhenGameIsRunning Auto
imagespacemodifier Property theImod Auto

Function OnEffectFinish(objectreference akTarget, actor akCaster, magiceffect akBaseEffect, Float afMagnitude, Float afDuration) Native
Function OnEffectStart(objectreference akTarget, actor akCaster, magiceffect akBaseEffect, Float afMagnitude, Float afDuration) Native
Function OnTimer(Int aiTimerID) Native
Function PlayEffects(Bool startPlaying) Native
