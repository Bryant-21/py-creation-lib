Scriptname abDeathclawClawsSCRIPT Extends ActiveMagicEffect

Event OnDying(actor akKiller)
EndEvent
