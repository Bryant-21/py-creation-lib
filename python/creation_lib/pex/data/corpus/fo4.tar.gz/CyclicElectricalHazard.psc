Scriptname CyclicElectricalHazard Extends objectReference

form Property xmarker Auto
Float Property TargetDistance Auto
Float Property firingTime Auto
Float Property firingPauseTime Auto
Bool Property StartsOn Auto
Float Property OffsetTimer Auto
spell Property TrapElectricArcSpell Auto
Float Property BlindFireRange Auto

Function FireElectricity() Native
Event OnActivate(objectReference akActionRef)
EndEvent

Event OnCellAttach()
EndEvent

Event OnCellDetach()
EndEvent

Event OnInit()
EndEvent

Event OnLoad()
EndEvent

Event onTimer(Int aiTimerID)
EndEvent

Function TurnOn(Bool ShouldBeOn = true) Native
