Scriptname BYOH_TIF__01003DD2 Extends TopicInfo

referencealias Property Aventus Auto
referencealias Property Francois Auto
quest Property RelationshipAdoptableOrphanage Auto
referencealias Property Hroar Auto
referencealias Property Runa Auto
referencealias Property Samuel Auto

Function Fragment_0(ObjectReference akSpeakerRef) Native
String Function GetState() Native
Function GotoState(String newState) Native
