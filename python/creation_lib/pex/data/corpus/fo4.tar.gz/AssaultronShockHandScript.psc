Scriptname AssaultronShockHandScript Extends ActiveMagicEffect

String Property myPlaceAtNode Auto
explosion Property PElectricalExplosionSmall Auto
sound Property NPCRobotHandShockLPM Auto
actorvalue Property myLimbAV Auto
visualeffect Property PRobotShockHandVE Auto

Event OnAnimationEvent(objectreference akSource, String asEventName)
EndEvent

Event OnConsciousnessStateChanged(Bool abUnconscious)
EndEvent

Event OnCripple(actorvalue akActorValue, Bool abCrippled)
EndEvent

Event OnDying(actor akKiller)
EndEvent

Event OnEffectFinish(actor akTarget, actor akCaster)
EndEvent

Event OnEffectStart(actor akTarget, actor akCaster)
EndEvent
