Scriptname BYOH_TIF__01003EA6 Extends TopicInfo

faction Property BYOHRelationshipAdoptableFaction Auto

Function Fragment_0(ObjectReference akSpeakerRef) Native
String Function GetState() Native
Function GotoState(String newState) Native
