Scriptname CRWQuestScript Extends Quest

message Property FiredMessage Auto
message Property HiredMessage Auto
referencealias Property CrewPosition Auto
faction Property PotentialCrewFaction Auto
faction Property CurrentCrewFaction Auto
faction Property AvailableCrewFaction Auto
referencealias Property CrewName Auto

Function CrewFired() Native
Function CrewHired() Native
