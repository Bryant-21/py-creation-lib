Scriptname DLC03:SFTA00DecoyShipAliasScript Extends ReferenceAlias

ReferenceAlias Property Hannibal Auto
Int Property GetDecoyStage Auto
ReferenceAlias Property PlayerChopShopFriend Auto
Int Property EnterAkilaStage Auto
scene Property SFTA00_0810a_ChopShop_Hailing Auto
ReferenceAlias Property Roach Auto
ReferenceAlias Property DecoyShipRoachSeat Auto
Int Property LeaveAkilaStage Auto
Int Property ChopShopDockStage Auto
locationalias Property ChopShopSpaceLoc Auto
locationalias Property DecoyShipLocation Auto
ReferenceAlias Property DecoyShipAdrastosPrisonerFurniture Auto

Function OnLoad() Native
Function OnLocationChange(location akOldLoc, location akNewLoc) Native
