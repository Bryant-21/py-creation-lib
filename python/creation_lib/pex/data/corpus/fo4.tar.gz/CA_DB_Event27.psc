Scriptname CA_DB_Event27 Extends ca_dialoguebump_basescript

Function InitializeEventID() Native
