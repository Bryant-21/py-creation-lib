Scriptname BoostpackEffectScript Extends ActiveMagicEffect

actorvalue Property BoostpackActive Auto

Function OnAnimationEvent(objectreference akSource, String asEventName) Native
Function OnEffectFinish(objectreference akTarget, actor akCaster, magiceffect akBaseEffect, Float afMagnitude, Float afDuration) Native
Function OnEffectStart(objectreference akTarget, actor akCaster, magiceffect akBaseEffect, Float afMagnitude, Float afDuration) Native
