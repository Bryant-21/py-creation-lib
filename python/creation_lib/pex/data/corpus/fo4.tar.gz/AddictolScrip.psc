Scriptname AddictolScrip Extends ActiveMagicEffect

spell Property Addiction Auto Const

Event OnEffectStart(actor akTarget, actor akCaster)
EndEvent
