Scriptname BYOH_QF_BYOHHouseFalkreath_0100305E Extends Quest

locationalias Property Alias_houseLocation Auto
book Property BYOHHouseJarlFriendLetter Auto
referencealias Property Alias_CarpentersWorkbench Auto
referencealias Property Alias_HouseCarriageDriver Auto
faction Property Favor110QuestGiverFaction Auto
wicourierscript Property WICourier Auto
referencealias Property Alias_DraftingTable Auto
book Property BYOHHouseJarlIntroLetter Auto
book Property Charter Auto
referencealias Property Alias_Steward Auto
locationalias Property Alias_Hold Auto
referencealias Property Alias_Jarl Auto
referencealias Property Favor110Questgiver Auto
referencealias Property Alias_IntroNote Auto
referencealias Property Alias_Charter Auto
referencealias Property Alias_HouseInteriorMarker Auto
Quest Property Favor110 Auto
referencealias Property Alias_HouseHorse Auto
globalvariable Property GameDaysPassed Auto
locationalias Property Alias_HoldCity Auto
referencealias Property Alias_CourierNote Auto

Function Fragment_0() Native
Function Fragment_1() Native
Function Fragment_10() Native
Function Fragment_12() Native
Function Fragment_14() Native
Function Fragment_15() Native
Function Fragment_16() Native
Function Fragment_18() Native
Function Fragment_20() Native
Function Fragment_21() Native
Function Fragment_23() Native
Function Fragment_26() Native
Function Fragment_27() Native
Function Fragment_28() Native
Function Fragment_29() Native
Function Fragment_3() Native
Function Fragment_4() Native
Function Fragment_5() Native
String Function GetState() Native
Function GotoState(String newState) Native
