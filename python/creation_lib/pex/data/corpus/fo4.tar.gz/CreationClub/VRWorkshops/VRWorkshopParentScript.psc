Scriptname CreationClub:VRWorkshops:VRWorkshopParentScript Extends Quest

Struct VRDestinationData
    referencealias VRDestinationMarkerRef
    message VRDestinationName
EndStruct

Struct StructBlacklistObject
    Int FormID
    String PluginFilename
    String Description
EndStruct

keyword Property VRWorkshopShared_Keyword_WorkshopTypeVR Auto Const
spell Property VRWorkshopShared_AbWaterBreathingSpell Auto Const
effectshader Property TeleportOutFXS Auto Const
sound Property VRWorkshop_TravelSoundFX Auto Const
message Property VRWorkshop_Message_MaxSettlers Auto Const
structblacklistobject[] Property ArrayStructBlacklistObjects Auto Const
sound Property VRWorkshop_ArriveSoundFX Auto Const
workshopparentscript Property WorkshopParent Auto Const
musictype Property VRWorkshopShared_MUS_NONE Auto Const
perk Property ImmuneToAcid Auto Const
perk Property VRWorkshopShared_BlockXP Auto Const
spell Property VRWorkshopShared_abVRDamageResistSpell Auto Const
imagespacemodifier Property VRWorkshop_MemoryLoungerExitImod Auto Const
creationclub:vrworkshops:vrworkshopattacksquestscript Property VRAttackQuest Auto Const
keyword Property WorkshopLinkSpawn Auto Const
perk Property VRWorkshopShared_ImmuneToDamagePerk Auto Const
perk Property ImmuneToPoison Auto Const
perk Property crNoFallDamage Auto Const
Bool Property bDisableTerminalFunctions Auto
perk Property ImmuneToRadiation Auto Const
imagespacemodifier Property VRWorkshop_MemoryLoungerEnterImod Auto Const
keyword Property VRWorkshopShared_Keyword_LinkedRefMapMarker Auto Const
sound Property TeleportSound Auto Const
formlist Property VRWorkshopShared_DisallowedObjectsList Auto
referencealias Property CompanionReturnMarkerREF Auto
Int Property MaxVRSettlers Auto Const
referencealias Property CurrentReturnPodREF Auto
referencealias Property CurrentTravelMarkerREF Auto
vrdestinationdata[] Property ArrayVRDestinations Auto Const
message Property VRWorkshopShared_Message_AlreadyInCurrentWorkshop Auto Const

Function AddPlayerBuffs() Native
Function AddVRSettler() Native
Function BuildDLCObjectBlacklist() Native
Function ChangeVRLocation(Int VRLocationEnum) Native
Function ClearImageSpace() Native
Function ClearMusic() Native
Function ExitVRSettlement() Native
Function HandleCompanionMove() Native
Function HandlePlayerChangeVRLocation() Native
Function HandlePlayerExit() Native
Event OnInit()
EndEvent

Event OnMenuOpenCloseEvent(String asMenuName, Bool abOpening)
EndEvent

Function OverrideMusic(musictype MusicToPlay) Native
Function RemovePlayerBuffs() Native
Function SetImageSpace(imagespacemodifier imageSpaceModifierToSet) Native
Function SetVRPodDestination(Int VRLocationEnum, objectreference TerminalRef, keyword LinkTerminalKeyword) Native
