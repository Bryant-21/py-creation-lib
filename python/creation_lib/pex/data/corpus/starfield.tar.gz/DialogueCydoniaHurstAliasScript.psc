Scriptname DialogueCydoniaHurstAliasScript Extends ReferenceAlias

Int Property StagePrereq Auto
globalvariable Property CY_HurstGone Auto
quest Property City_CY_RedTape02 Auto
Int Property RedTapeStagePrereq Auto

Function OnLoad() Native
