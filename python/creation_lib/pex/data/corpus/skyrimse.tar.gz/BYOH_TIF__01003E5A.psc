Scriptname BYOH_TIF__01003E5A Extends TopicInfo

faction Property RelationshipAdoptableFaction Auto

Function Fragment_1(ObjectReference akSpeakerRef) Native
String Function GetState() Native
Function GotoState(String newState) Native
