Scriptname DefaultAliasOnUnequipped Extends DefaultAlias

Bool Property PlayerUnequippedOnly Auto
referencealias[] Property UnequippedByAliases Auto
objectreference[] Property UnequippedByReferences Auto
faction[] Property UnequippedByFactions Auto

Event OnUnequipped(actor akActor)
EndEvent
