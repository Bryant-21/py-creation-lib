Scriptname DefaultAliasOnAggro Extends DefaultAlias

objectreference[] Property TargetingOrHitByOneOfTheseReferences Auto Const
Bool Property PlayerOnly Auto Const
Int Property CombatStateToCheckFor Auto Const
referencealias[] Property TargetingOrHitByOneOfTheseAliases Auto Const
faction[] Property TargetingOrHitByOneOfTheseFactions Auto Const

Event OnAliasInit()
EndEvent

Event OnCombatStateChanged(actor akTarget, Int aeCombatState)
EndEvent

Event OnHit(objectreference akTarget, objectreference akAggressor, form akSource, projectile akProjectile, Bool abPowerAttack, Bool abSneakAttack, Bool abBashAttack, Bool abHitBlocked, String asMaterialName)
EndEvent
