Scriptname DefaultTopicAddItem Extends TopicInfo

Bool Property AddItemOnBegin Auto
Int Property AmountToAdd Auto
form Property ItemToAdd Auto
Bool Property AddItemOnEnd Auto

Event OnBegin(objectreference akSpeakerRef, Bool abHasBeenSaid)
EndEvent

Event OnEnd(objectreference akSpeakerRef, Bool abHasBeenSaid)
EndEvent
