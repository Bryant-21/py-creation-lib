Scriptname BoSM01DistressPulserRefScript Extends ObjectReference

quest Property BoSM01DistressSignals Auto Const
quest Property BoSM01 Auto Const

Event OnLoad()
EndEvent
