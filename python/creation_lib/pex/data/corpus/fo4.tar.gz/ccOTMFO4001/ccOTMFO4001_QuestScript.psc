Scriptname ccOTMFO4001:ccOTMFO4001_QuestScript Extends Quest

Float Property EnclaveHomingBeaconMaxDistance Auto
Quest Property ccOTMFO4001_CreationChecker Auto
Int Property CurrentBloodMarker Auto
Int Property DisplaySignalMessageActiveStage Auto
objectreference Property ccOTMFO4001_AtlanticOfficeElevatorBlocker Auto
worldspace Property Commonwealth Auto
referencealias Property AtlanticOfficesElevator Auto
message Property ccOTMFO4001_EnclaveSignalStrengthMessage Auto
referencealias Property Transmitter Auto
Quest Property ccOTMFO4001_Radio Auto
Int Property EnclaveFieldCampTroops Auto
refcollectionalias Property EnclaveHQKlaxons Auto
Float Property EnclaveHomingBeaconRadioFrequency Auto
Float Property DistanceFromTransmitterToAdvanceQuest Auto
Int Property StageToSetWhenArriving Auto
Quest Property ccOTMFO4001_Quest Auto

Function ActivateEnclaveKlaxons() Native
Function BloodMarkerTriggered(Int BloodMarkerNumber) Native
Function EnclaveCampSoldierKilled() Native
Function OnDistanceLessThan(objectreference akObj1, objectreference akObj2, Float afDistance) Native
Function OnInit() Native
Function OnQuestInit() Native
Function OnStageSet(Int auiStageID, Int auiItemID) Native
Function OnTimer(Int aiTimerID) Native
Function SetElevatorFunctional(Bool makeFunctional) Native
Function ShutDown() Native
