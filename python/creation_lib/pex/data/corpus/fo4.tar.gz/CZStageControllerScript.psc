Scriptname CZStageControllerScript Extends ObjectReference

Struct SequenceAction
    Float Main1LightTarget
    Float Main3LightTarget
    Int upLightState
    Float UpSpeed
    Int UpAction
    Bool Main3hasLightSequence
    Float DownLightTarget
    Float SequenceTimer
    Int Main2Action
    Int Main1LightState
    Float Main2LightRamp
    Float upLightTarget
    Float upLightRamp
    Bool OverrideOrders
    Bool Main1hasLightSequence
    Int DownLightState
    Int Main3LightState
    Int Main1Action
    Bool Definition
    Float DownSpeed
    Bool Main2hasLightSequence
    Float DownLightRamp
    Int DownAction
    Bool UphasLightSequence
    Int Main3Action
    Float Main2LightTarget
    Float MainSpeed
    Bool iiiiiiiiiiiiiiUPiiiiiiiiiiiiii
    Float Main3LightRamp
    Float Main1LightRamp
    Bool iiiiiiiiiiiiiiMAINiiiiiiiiiiiiii
    Bool iiiiiiiiiiiiiiDOWNiiiiiiiiiiiiii
    Bool DownhasLightSequence
    Int Main2LightState
EndStruct

sequenceaction[] Property Sequence13 Auto
sequenceaction[] Property Sequence2 Auto
sequenceaction[] Property Sequence8 Auto
sequenceaction[] Property Sequence14 Auto
quest Property CZ_Arena Auto
czspotlightscript Property Spotlight2 Auto
czspotlightscript[] Property StageLights Auto
referencealias Property Tommy Auto
czspotlightscript[] Property UpperLights Auto
referencealias Property CaitsCombatant Auto
Int[] Property ValidAmbientSequences Auto
sequenceaction[] Property Sequence19 Auto
sequenceaction[] Property Sequence12 Auto
sequenceaction[] Property Sequence16 Auto
Int[] Property ValidFightSequences Auto
sequenceaction[] Property Sequence18 Auto
sequenceaction[] Property Sequence11 Auto
referencealias Property Combatant1 Auto
sequenceaction[] Property Sequence3 Auto
sequenceaction[] Property Sequence5 Auto
referencealias Property Ringmaster Auto
czspotlightscript Property Spotlight3 Auto
globalvariable Property CZ_CaitIntroDone Auto
sequenceaction[] Property Sequence10 Auto
sequenceaction[] Property Sequence20 Auto
sequenceaction[] Property Sequence1 Auto
referencealias Property Combatant2 Auto
sequenceaction[] Property Sequence15 Auto
referencealias Property Cait Auto
czspotlightscript Property Spotlight1 Auto
sequenceaction[] Property Sequence7 Auto
sequenceaction[] Property Sequence4 Auto
sequenceaction[] Property Sequence9 Auto
sequenceaction[] Property Sequence6 Auto
sequenceaction[] Property Sequence17 Auto
czspotlightscript Property Spotlight4 Auto

Function AddSequenceToQueue(Int SequenceNumber) Native
Function AllLightsOff() Native
Int[] Function CheckSequences(Int[] PotentiallyValidSequences) Native
Function ClearSequenceQueue() Native
Function CountSequenceDone() Native
Function EndCaitIntro() Native
czspotlightscript[] Function FillLightArray(objectreference[] LightArray) Native
sequenceaction[] Function GetSequence(Int SequenceNumber) Native
Bool Function IncrementSequenceQueue() Native
Function Init() Native
Event OnCellAttach()
EndEvent

Event OnCellDetach()
EndEvent

Event OnTimer(Int aiTimerID)
EndEvent

Int Function RandomElement(Int[] iArray) Native
Function RunNextSequenceAction() Native
Function RunSequenceAction(sequenceaction[] mySeq) Native
Function SpotlightCombatant1(Bool ShouldSpotlight = true) Native
Function SpotlightCombatant2(Bool ShouldSpotlight = true) Native
Function SpotlightOther(ObjectReference refToLight, Bool ShouldSpotlight = true) Native
Function SpotlightRingmaster(Bool ShouldSpotlight = true) Native
Function StartAmbientLights() Native
Function StartCaitIntro() Native
Function StartFight() Native
Function StartSequenceQueue() Native
Function StopAmbientLights() Native
Function StopFight() Native
Function TestSeq(Int SequenceNumber) Native
