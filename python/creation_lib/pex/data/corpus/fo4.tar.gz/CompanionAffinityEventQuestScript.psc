Scriptname CompanionAffinityEventQuestScript Extends Quest

Quest Property MQ104 Auto
Quest Property MQ206RR Auto
keyword Property CA_CustomEvent_MacCreadyDislikes Auto
Quest Property BoSR05 Auto
keyword Property CA_CustomEvent_CaitDislikes Auto
Quest Property BoS101 Auto
keyword Property CA_CustomEvent_MacCready__UNSET Auto
Quest Property MinVsInst Auto
Quest Property MQ302Min Auto
Quest Property BoS203 Auto
Quest Property DialogueGoodneighborEntrance Auto
keyword Property CA_CustomEvent_DeaconDislikes Auto
Quest Property MinRecruit09 Auto
keyword Property CA_CustomEvent_MacCreadyLoves Auto
keyword Property CA_CustomEvent_Hancock__UNSET Auto
Quest Property DN083_Barney Auto
Quest Property FFDiamondCity01 Auto
keyword Property CA_CustomEvent_ValentineLikes Auto
companionactorscript Property BoSPaladinDanseRef Auto
Quest Property DialogueVault81 Auto
Quest Property BoS302 Auto
keyword Property CA_CustomEvent_Valentine__UNSET Auto
Quest Property BoS202 Auto
Quest Property DialogueConcordArea Auto
Quest Property MQ105 Auto
Quest Property FFBunkerHill03 Auto
Quest Property BoSM02 Auto
keyword Property CA_CustomEvent_X688__UNSET Auto
Quest Property DN053 Auto
keyword Property CA_CustomEvent_CodsworthHates Auto
keyword Property CA_CustomEvent_DeaconLikes Auto
keyword Property CA_CustomEvent_HancockDislikes Auto
Quest Property DialogueDiamondCitySchoolhouse Auto
Quest Property MS14 Auto
Quest Property RR303 Auto
Quest Property InstM01 Auto
keyword Property CA_CustomEvent_CodsworthLikes Auto
Quest Property Min01 Auto
Quest Property BoSM01 Auto
keyword Property CA_CustomEvent_ValentineLoves Auto
Quest Property DN036 Auto
Quest Property InstM03 Auto
Quest Property Inst306 Auto
Quest Property MS13CookeDies Auto
keyword Property CA_CustomEvent_ValentineDislikes Auto
keyword Property CA_CustomEvent_MacCreadyHates Auto
Quest Property BoS301 Auto
Quest Property FFDiamondCity08 Auto
Quest Property DialogueDrinkingBuddy Auto
Quest Property MQ302BoS Auto
Quest Property MQ302RR Auto
Quest Property Inst302 Auto
Quest Property MS16 Auto
Quest Property MinRecruit03 Auto
Quest Property RR102 Auto
Quest Property DialogueDiamondCity Auto
Quest Property MS05BPostQuest Auto
Quest Property DialogueDrumlinDiner Auto
Quest Property DialogueDiamondCityEntrance Auto
globalvariable Property MinCastleAttacker Auto
Quest Property DiamondCitySuperMutantIntro Auto
Quest Property RETravelKMK_BoSM02 Auto
Quest Property MS01 Auto
Quest Property DialogueRailroad Auto
Quest Property MS13FindPhoto Auto
Quest Property MS17 Auto
Quest Property RRR08 Auto
globalvariable Property Cait_EventCondition_DislikesPlayerTakingChems Auto
Quest Property BoS200 Auto
companionactorscript Property X688Ref Auto
keyword Property CA_CustomEvent_X688Loves Auto
Quest Property MS13 Auto
companionactorscript Property StrongRef Auto
companionactorscript Property CurieRef Auto
companionactorscript Property CaitRef Auto
companionactorscript Property CompMacCreadyRef Auto
Quest Property DN109 Auto
Quest Property MQ00MamaMurphy Auto
keyword Property CA_CustomEvent_PiperLoves Auto
companionactorscript Property CodsworthRef Auto
companionactorscript Property PrestonRef Auto
keyword Property CA_CustomEvent_DanseLikes Auto
keyword Property CA_CustomEvent_CurieLikes Auto
companionactorscript Property PiperRef Auto
keyword Property CA_CustomEvent_X688Hates Auto
Quest Property Min207 Auto
Quest Property Min02 Auto
keyword Property CA_CustomEvent_X688Dislikes Auto
Quest Property DN102 Auto
Quest Property REAssaultSC01_DN123SkylanesAssault Auto
Quest Property MinDestBOS Auto
keyword Property CA_CustomEvent_CaitHates Auto
keyword Property CA_CustomEvent_X688Likes Auto
Quest Property BoS201 Auto
companionactorscript Property ValentineRef Auto
Quest Property Min301 Auto
keyword Property CA_CustomEvent_ValentineHates Auto
keyword Property CA_CustomEvent_Strong__UNSET Auto
Quest Property MS07c Auto
keyword Property CA_CustomEvent_HancockLoves Auto
Quest Property DN079 Auto
Quest Property Min03 Auto
Quest Property MQ206 Auto
keyword Property CA_CustomEvent_StrongHates Auto
Quest Property MQ203 Auto
keyword Property CA_CustomEvent_StrongDislikes Auto
keyword Property CA_CustomEvent_StrongLikes Auto
Quest Property DN119Fight Auto
keyword Property CA_CustomEvent_StrongLoves Auto
Quest Property DN101 Auto
Quest Property RRR04 Auto
keyword Property CA_CustomEvent_Preston__UNSET Auto
keyword Property CA_CustomEvent_CodsworthDislikes Auto
keyword Property CA_CustomEvent_MacCreadyLikes Auto
keyword Property CA_CustomEvent_PiperLikes Auto
keyword Property CA_CustomEvent_CodsworthLoves Auto
keyword Property CA_CustomEvent_HancockHates Auto
Quest Property FFDiamondCity07 Auto
Quest Property MS05B Auto
keyword Property CA_CustomEvent_PrestonLoves Auto
keyword Property CA_CustomEvent_Piper__UNSET Auto
Quest Property RESceneLC01 Auto
Quest Property MS04 Auto
keyword Property CA_CustomEvent_PiperHates Auto
Quest Property RR201 Auto
keyword Property CA_CustomEvent_PiperDislikes Auto
keyword Property CA_CustomEvent_PrestonDislikes Auto
Quest Property RR101 Auto
companionactorscript Property DeaconRef Auto
keyword Property CA_CustomEvent_PrestonHates Auto
keyword Property CA_CustomEvent_DeaconHates Auto
Quest Property InstR03NEW Auto
keyword Property CA_CustomEvent_CaitLikes Auto
Quest Property InstR05 Auto
keyword Property CA_CustomEvent_Deacon__UNSET Auto
keyword Property CA_CustomEvent_Cait__UNSET Auto
Quest Property DialogueGoodneighborRufus Auto
Quest Property FFDiamondCity10 Auto
Quest Property RETravelSC01_DN123SkylanesPointer Auto
keyword Property CA_CustomEvent_PrestonLikes Auto
Quest Property DN019JoinCult Auto
keyword Property CA_CustomEvent_HancockLikes Auto
keyword Property CA_CustomEvent_CurieLoves Auto
keyword Property CA_CustomEvent_DeaconLoves Auto
keyword Property CA_CustomEvent_Danse__UNSET Auto
Quest Property RR302 Auto
Quest Property RRM01 Auto
keyword Property CA_CustomEvent_DanseHates Auto
Quest Property RRR02aQuest Auto
keyword Property CA_CustomEvent_DanseDislikes Auto
keyword Property CA_CustomEvent_DanseLoves Auto
Quest Property RECampLC01 Auto
keyword Property CA_CustomEvent_Codsworth__UNSET Auto
keyword Property CA_CustomEvent_Curie__UNSET Auto
keyword Property CA_CustomEvent_CurieHates Auto
Quest Property BoS204 Auto
keyword Property CA_CustomEvent_CurieDislikes Auto
Quest Property DialogueGraygarden Auto
Quest Property DialogueGoodneighbor Auto
globalvariable Property MQ302Faction Auto
Quest Property DN036_Post Auto
Quest Property Inst307 Auto
Quest Property RRR05 Auto
Quest Property DN015 Auto
Quest Property DialogueWarwickHomestead Auto
Quest Property V81_03 Auto
Quest Property V81_01 Auto
Quest Property InstM02 Auto
Quest Property MS13PaulDies Auto
Quest Property DialogueBunkerHill Auto
Quest Property MS07a Auto
Quest Property BoS303 Auto
Quest Property RRM02 Auto
Quest Property BoS100 Auto
Quest Property MS13NelsonDies Auto
Quest Property MS19 Auto
Quest Property Inst301 Auto
Quest Property DialogueTheSlog Auto
Quest Property MS07b Auto
Quest Property RRAct3PickUp Auto
Quest Property MS11 Auto
Quest Property MS09 Auto
keyword Property CA_CustomEvent_CaitLoves Auto
Quest Property DialogueAbernathyFarm Auto
Quest Property MQ302 Auto
Quest Property MinDefendCastle Auto
Quest Property V81_00_Intro Auto
Quest Property DN121 Auto
Quest Property FFGoodneighbor07 Auto
Quest Property InstR04 Auto
companionactorscript Property HancockRef Auto
Quest Property MQ201 Auto

Function Cait__UNSET() Native
Function Cait_Dislikes(Bool CheckCompanionProximity = true) Native
Function Cait_Hates(Bool CheckCompanionProximity = true) Native
Function Cait_Likes(Bool CheckCompanionProximity = true) Native
Function Cait_Loves(Bool CheckCompanionProximity = true) Native
Function Cait_Neutral(Bool CheckCompanionProximity = true) Native
Function Codsworth__UNSET() Native
Function Codsworth_Dislikes(Bool CheckCompanionProximity = true) Native
Function Codsworth_Hates(Bool CheckCompanionProximity = true) Native
Function Codsworth_Likes(Bool CheckCompanionProximity = true) Native
Function Codsworth_Loves(Bool CheckCompanionProximity = true) Native
Function Codsworth_Neutral(Bool CheckCompanionProximity = true) Native
Function Curie__UNSET() Native
Function Curie_Dislikes(Bool CheckCompanionProximity = true) Native
Function Curie_Hates(Bool CheckCompanionProximity = true) Native
Function Curie_Likes(Bool CheckCompanionProximity = true) Native
Function Curie_Loves(Bool CheckCompanionProximity = true) Native
Function Curie_Neutral(Bool CheckCompanionProximity = true) Native
Function Danse__UNSET() Native
Function Danse_Dislikes(Bool CheckCompanionProximity = true) Native
Function Danse_Hates(Bool CheckCompanionProximity = true) Native
Function Danse_Likes(Bool CheckCompanionProximity = true) Native
Function Danse_Loves(Bool CheckCompanionProximity = true) Native
Function Danse_Neutral(Bool CheckCompanionProximity = true) Native
Function Deacon__UNSET() Native
Function Deacon_Dislikes(Bool CheckCompanionProximity = true) Native
Function Deacon_Hates(Bool CheckCompanionProximity = true) Native
Function Deacon_Likes(Bool CheckCompanionProximity = true) Native
Function Deacon_Loves(Bool CheckCompanionProximity = true) Native
Function Deacon_Neutral(Bool CheckCompanionProximity = true) Native
CompanionAffinityEventQuestScript Function GetScript() Global Native
Function Hancock__UNSET() Native
Function Hancock_Dislikes(Bool CheckCompanionProximity = true) Native
Function Hancock_Hates(Bool CheckCompanionProximity = true) Native
Function Hancock_Likes(Bool CheckCompanionProximity = true) Native
Function Hancock_Loves(Bool CheckCompanionProximity = true) Native
Function Hancock_Neutral(Bool CheckCompanionProximity = true) Native
Function HandleDialogueBump_BoS100(Quest eventQuest, Int eventID) Native
Function HandleDialogueBump_BoS101(Quest eventQuest, Int eventID) Native
Function HandleDialogueBump_BoS201(Quest eventQuest, Int eventID) Native
Function HandleDialogueBump_BoS202(Quest eventQuest, Int eventID) Native
Function HandleDialogueBump_BoS203(Quest eventQuest, Int eventID) Native
Function HandleDialogueBump_BoS301(Quest eventQuest, Int eventID) Native
Function HandleDialogueBump_BoS302(Quest eventQuest, Int eventID) Native
Function HandleDialogueBump_BoS303(Quest eventQuest, Int eventID) Native
Function HandleDialogueBump_BoSM01(Quest eventQuest, Int eventID) Native
Function HandleDialogueBump_BoSM02(Quest eventQuest, Int eventID) Native
Function HandleDialogueBump_BoSR05(Quest eventQuest, Int eventID) Native
Function HandleDialogueBump_DialogueAbernathyFarm(Quest eventQuest, Int eventID) Native
Function HandleDialogueBump_DialogueBunkerHill(Quest eventQuest, Int eventID) Native
Function HandleDialogueBump_DialogueConcordArea(Quest eventQuest, Int eventID) Native
Function HandleDialogueBump_DialogueDiamondCity(Quest eventQuest, Int eventID) Native
Function HandleDialogueBump_DialogueDiamondCityEntrance(Quest eventQuest, Int eventID) Native
Function HandleDialogueBump_DialogueDiamondCitySchoolhouse(Quest eventQuest, Int eventID) Native
Function HandleDialogueBump_DialogueDrumlinDiner(Quest eventQuest, Int eventID) Native
Function HandleDialogueBump_DialogueGoodneighbor(Quest eventQuest, Int eventID) Native
Function HandleDialogueBump_DialogueGoodneighborEntrance(Quest eventQuest, Int eventID) Native
Function HandleDialogueBump_DialogueGraygarden(Quest eventQuest, Int eventID) Native
Function HandleDialogueBump_DialogueRailroad(Quest eventQuest, Int eventID) Native
Function HandleDialogueBump_DialogueTheSlog(Quest eventQuest, Int eventID) Native
Function HandleDialogueBump_DialogueVault81(Quest eventQuest, Int eventID) Native
Function HandleDialogueBump_DialogueWarwickHomestead(Quest eventQuest, Int eventID) Native
Function HandleDialogueBump_DiamondCitySuperMutantIntro(Quest eventQuest, Int eventID) Native
Function HandleDialogueBump_DN019JoinCult(Quest eventQuest, Int eventID) Native
Function HandleDialogueBump_DN053(Quest eventQuest, Int eventID) Native
Function HandleDialogueBump_DN102(Quest eventQuest, Int eventID) Native
Function HandleDialogueBump_FFDiamondCity01(Quest eventQuest, Int eventID) Native
Function HandleDialogueBump_FFDiamondCity07(Quest eventQuest, Int eventID) Native
Function HandleDialogueBump_FFDiamondCity08(Quest eventQuest, Int eventID) Native
Function HandleDialogueBump_FFDiamondCity10(Quest eventQuest, Int eventID) Native
Function HandleDialogueBump_FFGoodneighbor07(Quest eventQuest, Int eventID) Native
Function HandleDialogueBump_Inst301(Quest eventQuest, Int eventID) Native
Function HandleDialogueBump_Inst302(Quest eventQuest, Int eventID) Native
Function HandleDialogueBump_Inst306(Quest eventQuest, Int eventID) Native
Function HandleDialogueBump_InstM01(Quest eventQuest, Int eventID) Native
Function HandleDialogueBump_InstM02(Quest eventQuest, Int eventID) Native
Function HandleDialogueBump_InstM03(Quest eventQuest, Int eventID) Native
Function HandleDialogueBump_Min01(Quest eventQuest, Int eventID) Native
Function HandleDialogueBump_Min03(Quest eventQuest, Int eventID) Native
Function HandleDialogueBump_MinRecruit03(Quest eventQuest, Int eventID) Native
Function HandleDialogueBump_MinRecruit09(Quest eventQuest, Int eventID) Native
Function HandleDialogueBump_MinVsInst(Quest eventQuest, Int eventID) Native
Function HandleDialogueBump_MQ00MamaMurphy(Quest eventQuest, Int eventID) Native
Function HandleDialogueBump_MQ104(Quest eventQuest, Int eventID) Native
Function HandleDialogueBump_MQ105(Quest eventQuest, Int eventID) Native
Function HandleDialogueBump_MQ201(Quest eventQuest, Int eventID) Native
Function HandleDialogueBump_MQ206(Quest eventQuest, Int eventID) Native
Function HandleDialogueBump_MQ206RR(Quest eventQuest, Int eventID) Native
Function HandleDialogueBump_MQ302BoS(Quest eventQuest, Int eventID) Native
Function HandleDialogueBump_MQ302Min(Quest eventQuest, Int eventID) Native
Function HandleDialogueBump_MQ302RR(Quest eventQuest, Int eventID) Native
Function HandleDialogueBump_MS01(Quest eventQuest, Int eventID) Native
Function HandleDialogueBump_MS04(Quest eventQuest, Int eventID) Native
Function HandleDialogueBump_MS05B(Quest eventQuest, Int eventID) Native
Function HandleDialogueBump_MS07a(Quest eventQuest, Int eventID) Native
Function HandleDialogueBump_MS09(Quest eventQuest, Int eventID) Native
Function HandleDialogueBump_MS11(Quest eventQuest, Int eventID) Native
Function HandleDialogueBump_MS13(Quest eventQuest, Int eventID) Native
Function HandleDialogueBump_MS13CookeDies(Quest eventQuest, Int eventID) Native
Function HandleDialogueBump_MS13FindPhoto(Quest eventQuest, Int eventID) Native
Function HandleDialogueBump_MS13NelsonDies(Quest eventQuest, Int eventID) Native
Function HandleDialogueBump_MS13PaulDies(Quest eventQuest, Int eventID) Native
Function HandleDialogueBump_MS14(Quest eventQuest, Int eventID) Native
Function HandleDialogueBump_MS16(Quest eventQuest, Int eventID) Native
Function HandleDialogueBump_MS17(Quest eventQuest, Int eventID) Native
Function HandleDialogueBump_MS19(Quest eventQuest, Int eventID) Native
Function HandleDialogueBump_REAssaultSC01_DN123SkylanesAssault(Quest eventQuest, Int eventID) Native
Function HandleDialogueBump_RECampLC01(Quest eventQuest, Int eventID) Native
Function HandleDialogueBump_RESceneLC01(Quest eventQuest, Int eventID) Native
Function HandleDialogueBump_RETravelKMK_BoSM02(Quest eventQuest, Int eventID) Native
Function HandleDialogueBump_RETravelSC01_DN123SkylanesPointer(Quest eventQuest, Int eventID) Native
Function HandleDialogueBump_RR101(Quest eventQuest, Int eventID) Native
Function HandleDialogueBump_RR102(Quest eventQuest, Int eventID) Native
Function HandleDialogueBump_RR302(Quest eventQuest, Int eventID) Native
Function HandleDialogueBump_RR303(Quest eventQuest, Int eventID) Native
Function HandleDialogueBump_RRM01(Quest eventQuest, Int eventID) Native
Function HandleDialogueBump_RRM02(Quest eventQuest, Int eventID) Native
Function HandleDialogueBump_RRR02a(Quest eventQuest, Int eventID) Native
Function HandleDialogueBump_RRR05(Quest eventQuest, Int eventID) Native
Function HandleDialogueBump_RRR08(Quest eventQuest, Int eventID) Native
Function HandleDialogueBump_V81_00_Intro(Quest eventQuest, Int eventID) Native
Function HandleDialogueBump_V81_01(Quest eventQuest, Int eventID) Native
Function HandleDialogueBump_V81_03(Quest eventQuest, Int eventID) Native
Function HandleQuestStageBump_BoS200(Quest eventQuest, Int eventID) Native
Function HandleQuestStageBump_BoS202(Quest eventQuest, Int eventID) Native
Function HandleQuestStageBump_BoS203(Quest eventQuest, Int eventID) Native
Function HandleQuestStageBump_BoS204(Quest eventQuest, Int eventID) Native
Function HandleQuestStageBump_BoS301(Quest eventQuest, Int eventID) Native
Function HandleQuestStageBump_BoS302(Quest eventQuest, Int eventID) Native
Function HandleQuestStageBump_BoSM01(Quest eventQuest, Int eventID) Native
Function HandleQuestStageBump_BoSM02(Quest eventQuest, Int eventID) Native
Function HandleQuestStageBump_BoSR05(Quest eventQuest, Int eventID) Native
Function HandleQuestStageBump_DialogueDrinkingBuddy(Quest eventQuest, Int eventID) Native
Function HandleQuestStageBump_DialogueGoodneighborRufus(Quest eventQuest, Int eventID) Native
Function HandleQuestStageBump_DN015(Quest eventQuest, Int eventID) Native
Function HandleQuestStageBump_DN036(Quest eventQuest, Int eventID) Native
Function HandleQuestStageBump_DN036_Post(Quest eventQuest, Int eventID) Native
Function HandleQuestStageBump_DN053(Quest eventQuest, Int eventID) Native
Function HandleQuestStageBump_DN079(Quest eventQuest, Int eventID) Native
Function HandleQuestStageBump_DN083_Barney(Quest eventQuest, Int eventID) Native
Function HandleQuestStageBump_DN101(Quest eventQuest, Int eventID) Native
Function HandleQuestStageBump_DN109(Quest eventQuest, Int eventID) Native
Function HandleQuestStageBump_DN119Fight(Quest eventQuest, Int eventID) Native
Function HandleQuestStageBump_DN121(Quest eventQuest, Int eventID) Native
Function HandleQuestStageBump_FFBunkerHill03(Quest eventQuest, Int eventID) Native
Function HandleQuestStageBump_FFGoodneighbor07(Quest eventQuest, Int eventID) Native
Function HandleQuestStageBump_Inst301(Quest eventQuest, Int eventID) Native
Function HandleQuestStageBump_Inst307(Quest eventQuest, Int eventID) Native
Function HandleQuestStageBump_InstM01(Quest eventQuest, Int eventID) Native
Function HandleQuestStageBump_InstR03NEW(Quest eventQuest, Int eventID) Native
Function HandleQuestStageBump_InstR04(Quest eventQuest, Int eventID) Native
Function HandleQuestStageBump_InstR05(Quest eventQuest, Int eventID) Native
Function HandleQuestStageBump_Min01(Quest eventQuest, Int eventID) Native
Function HandleQuestStageBump_Min02(Quest eventQuest, Int eventID) Native
Function HandleQuestStageBump_Min03(Quest eventQuest, Int eventID) Native
Function HandleQuestStageBump_Min207(Quest eventQuest, Int eventID) Native
Function HandleQuestStageBump_Min301(Quest eventQuest, Int eventID) Native
Function HandleQuestStageBump_MinDefendCastle(Quest eventQuest, Int eventID) Native
Function HandleQuestStageBump_MinDestBOS(Quest eventQuest, Int eventID) Native
Function HandleQuestStageBump_MQ203(Quest eventQuest, Int eventID) Native
Function HandleQuestStageBump_MQ302(Quest eventQuest, Int eventID) Native
Function HandleQuestStageBump_MS01(Quest eventQuest, Int eventID) Native
Function HandleQuestStageBump_MS04(Quest eventQuest, Int eventID) Native
Function HandleQuestStageBump_MS05B(Quest eventQuest, Int eventID) Native
Function HandleQuestStageBump_MS05BPostQuest(Quest eventQuest, Int eventID) Native
Function HandleQuestStageBump_MS07a(Quest eventQuest, Int eventID) Native
Function HandleQuestStageBump_MS07b(Quest eventQuest, Int eventID) Native
Function HandleQuestStageBump_MS07c(Quest eventQuest, Int eventID) Native
Function HandleQuestStageBump_MS09(Quest eventQuest, Int eventID) Native
Function HandleQuestStageBump_MS11(Quest eventQuest, Int eventID) Native
Function HandleQuestStageBump_MS16(Quest eventQuest, Int eventID) Native
Function HandleQuestStageBump_MS17(Quest eventQuest, Int eventID) Native
Function HandleQuestStageBump_RECampLC01(Quest eventQuest, Int eventID) Native
Function HandleQuestStageBump_RESceneLC01(Quest eventQuest, Int eventID) Native
Function HandleQuestStageBump_RR101(Quest eventQuest, Int eventID) Native
Function HandleQuestStageBump_RR102(Quest eventQuest, Int eventID) Native
Function HandleQuestStageBump_RR201(Quest eventQuest, Int eventID) Native
Function HandleQuestStageBump_RR303(Quest eventQuest, Int eventID) Native
Function HandleQuestStageBump_RRAct3PickUp(Quest eventQuest, Int eventID) Native
Function HandleQuestStageBump_RRM01(Quest eventQuest, Int eventID) Native
Function HandleQuestStageBump_RRM02(Quest eventQuest, Int eventID) Native
Function HandleQuestStageBump_RRR04(Quest eventQuest, Int eventID) Native
Function HandleQuestStageBump_RRR08(Quest eventQuest, Int eventID) Native
Function HandleQuestStageBump_V81_01(Quest eventQuest, Int eventID) Native
Function MacCready__UNSET() Native
Function MacCready_Dislikes(Bool CheckCompanionProximity = true) Native
Function MacCready_Hates(Bool CheckCompanionProximity = true) Native
Function MacCready_Likes(Bool CheckCompanionProximity = true) Native
Function MacCready_Loves(Bool CheckCompanionProximity = true) Native
Function MacCready_Neutral(Bool CheckCompanionProximity = true) Native
Event OnInit()
EndEvent

Function Piper__UNSET() Native
Function Piper_Dislikes(Bool CheckCompanionProximity = true) Native
Function Piper_Hates(Bool CheckCompanionProximity = true) Native
Function Piper_Likes(Bool CheckCompanionProximity = true) Native
Function Piper_Loves(Bool CheckCompanionProximity = true) Native
Function Piper_Neutral(Bool CheckCompanionProximity = true) Native
Function Preston__UNSET() Native
Function Preston_Dislikes(Bool CheckCompanionProximity = true) Native
Function Preston_Hates(Bool CheckCompanionProximity = true) Native
Function Preston_Likes(Bool CheckCompanionProximity = true) Native
Function Preston_Loves(Bool CheckCompanionProximity = true) Native
Function Preston_Neutral(Bool CheckCompanionProximity = true) Native
Function SendAffinityBumpEvent(ScriptObject sender, Int eventID) Native
Function SendAffinityEvent(keyword affinityKeyword, Bool CheckCompanionProximity = true) Native
Function Strong__UNSET() Native
Function Strong_Dislikes(Bool CheckCompanionProximity = true) Native
Function Strong_Hates(Bool CheckCompanionProximity = true) Native
Function Strong_Likes(Bool CheckCompanionProximity = true) Native
Function Strong_Loves(Bool CheckCompanionProximity = true) Native
Function Strong_Neutral(Bool CheckCompanionProximity = true) Native
Function Valentine__UNSET() Native
Function Valentine_Dislikes(Bool CheckCompanionProximity = true) Native
Function Valentine_Hates(Bool CheckCompanionProximity = true) Native
Function Valentine_Likes(Bool CheckCompanionProximity = true) Native
Function Valentine_Loves(Bool CheckCompanionProximity = true) Native
Function Valentine_Neutral(Bool CheckCompanionProximity = true) Native
Function X688__UNSET() Native
Function X688_Dislikes(Bool CheckCompanionProximity = true) Native
Function X688_Hates(Bool CheckCompanionProximity = true) Native
Function X688_Likes(Bool CheckCompanionProximity = true) Native
Function X688_Loves(Bool CheckCompanionProximity = true) Native
Function X688_Neutral(Bool CheckCompanionProximity = true) Native
