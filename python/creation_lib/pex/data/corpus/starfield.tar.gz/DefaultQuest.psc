Scriptname DefaultQuest Extends Quest

Int Property StageToSet Auto
Bool Property ShowTraces Auto
conditionform Property ConditionFormToTest Auto
Int Property TurnOffStageDone Auto
Int Property TurnOffStage Auto
Int Property PrereqStage Auto
