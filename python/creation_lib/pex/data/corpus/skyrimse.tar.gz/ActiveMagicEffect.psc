Scriptname ActiveMagicEffect

Function AddInventoryEventFilter(Form akFilter) Native
Function Dispel() Native
MagicEffect Function GetBaseObject() Native
Actor Function GetCasterActor() Native
String Function GetState() Native
Actor Function GetTargetActor() Native
Function GotoState(String newState) Native
Event OnActivate(ObjectReference akActionRef)
EndEvent

Function OnAnimationEvent(ObjectReference akSource, String asEventName) Native
Function OnAnimationEventUnregistered(ObjectReference akSource, String asEventName) Native
Function OnAttachedToCell() Native
Function onBeginState() Native
Event OnCellAttach()
EndEvent

Event OnCellDetach()
EndEvent

Event OnCellLoad()
EndEvent

Event OnClose(ObjectReference akActionRef)
EndEvent

Event OnCombatStateChanged(Actor akTarget, Int aeCombatState)
EndEvent

Event OnContainerChanged(ObjectReference akNewContainer, ObjectReference akOldContainer)
EndEvent

Event OnDeath(Actor akKiller)
EndEvent

Event OnDestructionStageChanged(Int aiOldStage, Int aiCurrentStage)
EndEvent

Function OnDetachedFromCell() Native
Event OnDying(Actor akKiller)
EndEvent

Event OnEffectFinish(Actor akTarget, Actor akCaster)
EndEvent

Event OnEffectStart(Actor akTarget, Actor akCaster)
EndEvent

Function onEndState() Native
Event OnEquipped(Actor akActor)
EndEvent

Function OnGainLOS(Actor akViewer, ObjectReference akTarget) Native
Event OnGetUp(ObjectReference akFurniture)
EndEvent

Event OnGrab()
EndEvent

Function OnHit(ObjectReference akAggressor, Form akSource, Projectile akProjectile, Bool abPowerAttack, Bool abSneakAttack, Bool abBashAttack, Bool abHitBlocked) Native
Event OnItemAdded(Form akBaseItem, Int aiItemCount, ObjectReference akItemReference, ObjectReference akSourceContainer)
EndEvent

Event OnItemRemoved(Form akBaseItem, Int aiItemCount, ObjectReference akItemReference, ObjectReference akDestContainer)
EndEvent

Event OnLoad()
EndEvent

Event OnLocationChange(Location akOldLoc, Location akNewLoc)
EndEvent

Event OnLockStateChanged()
EndEvent

Function OnLostLOS(Actor akViewer, ObjectReference akTarget) Native
Function OnLycanthropyStateChanged(Bool abIsWerewolf) Native
Function OnMagicEffectApply(ObjectReference akCaster, MagicEffect akEffect) Native
Function OnObjectEquipped(Form akBaseObject, ObjectReference akReference) Native
Function OnObjectUnequipped(Form akBaseObject, ObjectReference akReference) Native
Event OnOpen(ObjectReference akActionRef)
EndEvent

Event OnPackageChange(Package akOldPackage)
EndEvent

Event OnPackageEnd(Package akOldPackage)
EndEvent

Event OnPackageStart(Package akNewPackage)
EndEvent

Function OnPlayerBowShot(Weapon akWeapon, Ammo akAmmo, Float afPower, Bool abSunGazing) Native
Function OnPlayerFastTravelEnd(Float afTravelGameTimeHours) Native
Event OnPlayerLoadGame()
EndEvent

Event OnRaceSwitchComplete()
EndEvent

Event OnRead()
EndEvent

Event OnRelease()
EndEvent

Event OnReset()
EndEvent

Event OnSell(Actor akSeller)
EndEvent

Event OnSit(ObjectReference akFurniture)
EndEvent

Function OnSleepStart(Float afSleepStartTime, Float afDesiredSleepEndTime) Native
Function OnSleepStop(Bool abInterrupted) Native
Event OnSpellCast(Form akSpell)
EndEvent

Function OnTrackedStatsEvent(String arStatName, Int aiStatValue) Native
Event OnTranslationComplete()
EndEvent

Event OnTranslationFailed()
EndEvent

Function OnTrapHit(ObjectReference akTarget, Float afXVel, Float afYVel, Float afZVel, Float afXPos, Float afYPos, Float afZPos, Int aeMaterial, Bool abInitialHit, Int aeMotionType) Native
Event OnTrapHitStart(ObjectReference akTarget, Float afXVel, Float afYVel, Float afZVel, Float afXPos, Float afYPos, Float afZPos, Int aeMaterial, Bool abInitialHit, Int aeMotionType)
EndEvent

Event OnTrapHitStop(ObjectReference akTarget)
EndEvent

Function OnTrigger(ObjectReference akActionRef) Native
Event OnTriggerEnter(ObjectReference akActionRef)
EndEvent

Event OnTriggerLeave(ObjectReference akActionRef)
EndEvent

Event OnUnequipped(Actor akActor)
EndEvent

Event OnUnload()
EndEvent

Function OnUpdate() Native
Function OnUpdateGameTime() Native
Function OnVampireFeed(Actor akTarget) Native
Function OnVampirismStateChanged(Bool abIsVampire) Native
Function OnWardHit(ObjectReference akCaster, Spell akSpell, Int aiStatus) Native
Bool Function RegisterForAnimationEvent(ObjectReference akSender, String asEventName) Native
Function RegisterForLOS(Actor akViewer, ObjectReference akTarget) Native
Function RegisterForSingleLOSGain(Actor akViewer, ObjectReference akTarget) Native
Function RegisterForSingleLOSLost(Actor akViewer, ObjectReference akTarget) Native
Function RegisterForSingleUpdate(Float afInterval) Native
Function RegisterForSingleUpdateGameTime(Float afInterval) Native
Function RegisterForSleep() Native
Function RegisterForTrackedStatsEvent() Native
Function RegisterForUpdate(Float afInterval) Native
Function RegisterForUpdateGameTime(Float afInterval) Native
Function RemoveAllInventoryEventFilters() Native
Function RemoveInventoryEventFilter(Form akFilter) Native
Function StartObjectProfiling() Native
Function StopObjectProfiling() Native
Function UnregisterForAnimationEvent(ObjectReference akSender, String asEventName) Native
Function UnregisterForLOS(Actor akViewer, ObjectReference akTarget) Native
Function UnregisterForSleep() Native
Function UnregisterForTrackedStatsEvent() Native
Function UnregisterForUpdate() Native
Function UnregisterForUpdateGameTime() Native
