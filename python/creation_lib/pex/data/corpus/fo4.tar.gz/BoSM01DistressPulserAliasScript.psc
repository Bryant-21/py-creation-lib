Scriptname BoSM01DistressPulserAliasScript Extends ReferenceAlias

ReferenceAlias Property myTransmitter Auto
Int Property myTransmitterRadius Auto
Int Property myReplacementTransmitterRadius Auto Const
Bool Property tracesOn Auto
message Property BoSM01PulserSignalStrengthMessage Auto Const
objectreference Property myReplacementTransmitter Auto Const
Float Property myTransmitterFrequency Auto

Event OnAliasInit()
EndEvent

Event OnContainerChanged(objectreference akNewContainer, objectreference akOldContainer)
EndEvent

Event OnDistanceLessThan(objectreference akObj1, objectreference akObj2, Float afDistance)
EndEvent

Event OnLoad()
EndEvent

Event OnTimer(Int timerID)
EndEvent

Event OnUnload()
EndEvent
