Scriptname CIS_ScriptEventSenderActorScript Extends Actor

keyword Property CIS_ScriptEvent_Start Auto
Float Property SendScriptEventFrequency Auto

Event OnLoad()
EndEvent

Event OnTimerGameTime(Int aiTimerID)
EndEvent

Event OnUnload()
EndEvent

Function StartScriptEventTimer() Native
