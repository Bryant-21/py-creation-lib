Scriptname AttachArtRandomizerScript Extends Actor

visualeffect Property slotA02 Auto Const
visualeffect Property slotB03 Auto Const
visualeffect Property slotA01 Auto Const
visualeffect Property slotB01 Auto Const
visualeffect Property slotB02 Auto Const
visualeffect Property slotA03 Auto Const

Event OnLoad()
EndEvent
