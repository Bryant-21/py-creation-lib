Scriptname AssaultronHeadModScript Extends ActiveMagicEffect

actorvalue Property LeftMobilityCondition Auto Const
visualeffect Property pAssaultronHeadChargeV Auto Const
actorvalue Property RightAttackCondition Auto Const
actorvalue Property RightMobilityCondition Auto Const
sound Property LaserFireSound Auto Const
sound Property laserReadySound Auto Const
spell Property PcrThermalCoreCloak Auto Const
weapon Property pAssaultronLaser Auto Const
sound Property LaserTailSound Auto Const
Int Property laserState Auto
actorvalue Property LeftAttackCondition Auto Const
ammo Property AmmoAssaultron Auto Const
imagespacemodifier Property laserImod Auto Const
actorvalue Property headlaserAV Auto Const
sound Property laserChargeSound Auto Const

Function beginChargingLaser(actor selfRef) Native
Function endLaser(actor selfRef) Native
Function fireLaser(actor selfRef) Native
Function laserCrippled(actor selfRef) Native
Function limbCrippledReduceLaserCoolTime() Native
Event OnAnimationEvent(objectreference akSource, String asEventName)
EndEvent

Event OnCombatStateChanged(actor akTarget, Int aeCombatState)
EndEvent

Event OnCripple(actorvalue akActorValue, Bool abCrippled)
EndEvent

Event OnDying(actor akKiller)
EndEvent

Event OnEffectFinish(actor akTarget, actor akCaster)
EndEvent

Event OnEffectStart(actor akTarget, actor akCaster)
EndEvent

Event OnTimer(Int aiTimerID)
EndEvent

Function readyLaser(actor selfRef) Native
