Scriptname CircuitBreakerScript Extends ObjectReference

keyword Property LinkCustom01 Auto
Bool Property LockToOnPosition Auto
Bool Property OnPosition Auto
Bool Property DenyOnPosition Auto
keyword Property LinkCustom03 Auto
keyword Property LinkCustom02 Auto

Event OnActivate(ObjectReference akActionRef)
EndEvent

Event OnLoad()
EndEvent
