Scriptname BoSM01TransmitterScript Extends DefaultAlias

bosm01questscript Property BoSM01 Auto

Event OnPipboyRadioDetection(Bool abDetected)
EndEvent
