Scriptname BoSM01DistressPulserAliasScript Extends ReferenceAlias

ReferenceAlias Property myTransmitter Auto
Int Property myTransmitterRadius Auto
Int Property myReplacementTransmitterRadius Auto
Bool Property tracesOn Auto
message Property BoSM01PulserSignalStrengthMessage Auto
objectreference Property myReplacementTransmitter Auto
Float Property myTransmitterFrequency Auto

Event OnAliasInit()
EndEvent

Event OnContainerChanged(objectreference akNewContainer, objectreference akOldContainer)
EndEvent

Event OnDistanceLessThan(objectreference akObj1, objectreference akObj2, Float afDistance)
EndEvent

Event OnLoad()
EndEvent

Event OnTimer(Int timerID)
EndEvent

Event OnUnload()
EndEvent
