Scriptname CF03QuestScript Extends Quest

Int Property StageToSet Auto

Function OnTimer(Int aiTimerID) Native
Function WaitQT() Native
