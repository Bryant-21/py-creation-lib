Scriptname DefaultAddItemOnLoad Extends ObjectReference

Int Property Count Auto
form Property ItemToAdd Auto

Event OnLoad()
EndEvent
