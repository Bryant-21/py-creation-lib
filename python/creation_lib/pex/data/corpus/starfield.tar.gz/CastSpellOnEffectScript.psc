Scriptname CastSpellOnEffectScript Extends ActiveMagicEffect

spell Property OnEffectSpell Auto

Event OnEffectStart(objectreference akTarget, actor akCaster, magiceffect akBaseEffect, Float afMagnitude, Float afDuration)
EndEvent
