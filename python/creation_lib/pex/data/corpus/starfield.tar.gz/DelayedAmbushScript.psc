Scriptname DelayedAmbushScript Extends Actor

Bool Property ambushOnTrigger Auto
keyword Property LinkAmbushChild Auto
Float Property fAggressionOnReset Auto
actorvalue Property Suspicious Auto
actorvalue Property Aggression Auto
Bool Property TopLevelActor Auto
Float Property fActorVariable Auto
Float Property fActorVariableOnReset Auto
Float Property fAggression Auto
keyword Property linkKeyword Auto

Function Initialize() Native
Event onActivate(objectreference triggerRef)
EndEvent

Event OnCombatStateChanged(objectreference actorRef, Int aeCombatState)
EndEvent

Event OnDeath(objectreference akKiller)
EndEvent

Event onEndState(String asNewState)
EndEvent

Event onGetUp(objectreference myFurniture)
EndEvent

Event onHit(objectreference akTarget, objectreference akAggressor, form akWeapon, projectile akProjectile, Bool abPowerAttack, Bool abSneakAttack, Bool abBashAttack, Bool abHitBlocked, String asMaterialName)
EndEvent

Event OnLoad()
EndEvent

Event onReset()
EndEvent

Event OnUnload()
EndEvent
