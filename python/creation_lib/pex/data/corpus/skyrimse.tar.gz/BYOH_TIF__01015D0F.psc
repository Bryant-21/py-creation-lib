Scriptname BYOH_TIF__01015D0F Extends TopicInfo

quest Property pDialogueFollower Auto

Function Fragment_0(ObjectReference akSpeakerRef) Native
String Function GetState() Native
Function GotoState(String newState) Native
