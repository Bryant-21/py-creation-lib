Scriptname ccOTMFO4001:ccOTMFO4001_EnclaveComTowerScript Extends ObjectReference

quest Property ccOTMFO4001_Quest Auto
Float Property MaxDaysForRespawn Auto
String Property AnimationOn Auto
Bool Property StartsOn Auto
globalvariable Property ActiveStateGlobal Auto
message Property ccOTMFO4001_EnclaveComTowerOffMessage Auto
Float Property MinDaysForRespawn Auto
message Property ccOTMFO4001_EnclaveComTowerOnMessage Auto
String Property AnimationOff Auto
keyword Property ccOTMFO4001_EnclaveComTowerLink Auto

Function OnActivate(ObjectReference akActionRef) Native
Function OnCellAttach() Native
Function OnCellDetach() Native
Function OnInit() Native
Function TryToPrepareForRespawn() Native
