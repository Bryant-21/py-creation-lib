Scriptname BYOH_TIF__01003DE4 Extends TopicInfo

faction Property BYOHRelationshipAdoptableFaction Auto

Function Fragment_0(ObjectReference akSpeakerRef) Native
String Function GetState() Native
Function GotoState(String newState) Native
