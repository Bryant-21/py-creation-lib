Scriptname CZAliasSetCombatStyle Extends ReferenceAlias

Int Property QuestStageToSetCombatStyle Auto Const
Int Property QuestStageToClearCombatStyle Auto Const
combatstyle Property CombatstyleToSet Auto Const

Event OnInit()
EndEvent
