Scriptname COMNickScript Extends Quest

Int Property iInfatuationResponse Auto
keyword Property COMNickMysteriousStrangerTopic Auto Const
referencealias Property NickValentine Auto Const
Int Property iPlayerApologized Auto
Bool Property bPlayerKnowsNicksPast Auto
globalvariable Property COMNickStrangerThresholdMax Auto Const
Int Property CompanionDistance Auto Const

Event OnInit()
EndEvent

Event OnTrackedStatsEvent(String asStat, Int aiStatValue)
EndEvent
