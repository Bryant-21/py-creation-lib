Scriptname CA_DB_Event09 Extends ca_dialoguebump_basescript

Function InitializeEventID() Native
