Scriptname ArenaScript Extends Quest

globalvariable Property Arena_FightOver Auto Const
globalvariable Property Arena_FightOn Auto Const
referencealias Property AnnouncerHeadtrackMarker4 Auto Const
keyword Property WeaponTypeMelee1H Auto Const
referencealias Property StageController Auto Const
scene Property Arena_Announcement_Pre Auto Const
Bool Property IsPlayerInRing Auto
referencealias Property AnnouncerHeadtrackMarker2 Auto Const
scene Property Arena_Announcement_StartFight Auto Const
referencealias Property AnnouncerHeadtrackMarker5 Auto Const
referencealias Property CombatantSpawn Auto Const
referencealias Property PlayerEntranceTrigger Auto Const
referencealias Property Combatant1 Auto Const
globalvariable Property CZMaxRank Auto
globalvariable Property CZPlayerFoughtCait Auto
referencealias Property AnnouncerHeadtrackMarker1 Auto Const
actorvalue Property Health Auto Const
idle Property IdleFightWinner Auto Const
referencealias Property AnnounceMarker Auto Const
referencealias Property AnnouncerHeadtrackMarker3 Auto Const
referencealias Property Combatant2 Auto Const
actorbase[] Property Combatants Auto Const
globalvariable Property Arena_FightWaiting Auto Const
spell Property Arena_PacifyCombatant Auto Const
referencealias Property CageDoor Auto Const
keyword Property WeaponTypeMelee2H Auto Const
referencealias Property Corner1 Auto Const
referencealias Property Corner2 Auto Const
miscobject Property Caps001 Auto Const
faction Property Arena_Rank_Faction Auto Const
faction Property Arena_Fight_Faction Auto Const
referencealias Property WagerContainer Auto Const
scene Property Arena_Announcement_Post Auto Const
referencealias Property Ringmaster Auto Const

Function AnnounceFight() Native
Function CollectEarnings() Native
Function CollectPrize() Native
Function CombatantDown(referencealias DownedAlias) Native
actorbase Function GetCombatantActorBase(Int Rank = 0) Native
Event OnTimer(Int aiTimerID)
EndEvent

Int Function OpenWagerContainerAndGetAmount() Native
Function PlaceWager(Int Combatant) Native
Function PlayerFailedToEnterRing() Native
Function PlayerInEntranceTrigger() Native
Function PlayTriumphantIdle(actor ActorToTryToPlayIdle) Native
Function PrizeWon(actor WinningActor) Native
Function ResetEarningsAndWagerObjectives() Native
Function SetCombatantAliases(Int Rank = 0, actor Combatant1Ref = None, actor Combatant2Ref = None) Native
Function SetPlaceWagerObjective(Bool IsAcceptingWagers) Native
Function SetUpMatch(actor RingmasterActor, objectreference AnnounceMarkerRef, objectreference StageControllerRef, objectreference CageDoorRef, objectreference Corner1Ref, objectreference Corner2Ref, objectreference PlayerEntranceTriggerRef, objectreference SpawnMarker = None, Int Rank = 0, actor Combatant1Ref = None, actor Combatant2Ref = None, objectreference AnnouncerHeadtrackMarker1Ref = none, objectreference AnnouncerHeadtrackMarker2Ref = none, objectreference AnnouncerHeadtrackMarker3Ref = none) Native
Function SpotlightCombatant1(Bool turnOnLight) Native
Function SpotlightCombatant2(Bool turnOnLight) Native
Function StartFight() Native
Function StopFight() Native
Function ToggleRegistrationForRemoteEvents(Bool ShouldWatchForEvents) Native
Function WagerLost() Native
Function WagerWon() Native
