Scriptname DefaultActivateSelf Extends ObjectReference

objectreference[] Property TriggeredByReferences Auto
Bool Property PlayerOnly Auto
faction[] Property TriggeredByFactions Auto
Int Property PlayerMinLevel Auto
referencealias[] Property TriggeredByAliases Auto

Event onTriggerEnter(ObjectReference triggerRef)
EndEvent
