Scriptname AbLegendaryExplodeScript Extends ActiveMagicEffect

explosion Property DeathExplosion Auto

Event OnDeath(actor akKiller)
EndEvent
