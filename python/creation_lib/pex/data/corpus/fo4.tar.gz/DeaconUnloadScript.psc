Scriptname DeaconUnloadScript Extends Actor

Int Property nStage Auto
quest Property qQuest Auto

Event OnUnload()
EndEvent
