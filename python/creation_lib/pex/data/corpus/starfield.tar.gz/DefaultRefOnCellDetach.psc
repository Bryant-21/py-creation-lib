Scriptname DefaultRefOnCellDetach Extends DefaultRefParent

Event OnCellDetach()
EndEvent
