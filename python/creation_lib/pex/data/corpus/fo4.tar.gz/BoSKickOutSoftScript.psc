Scriptname BoSKickOutSoftScript Extends Quest

Quest Property BoS204 Auto
Quest Property BoS303 Auto
Quest Property BoS101POI Auto
Quest Property BoS201B Auto
Quest Property BoS302 Auto
Quest Property BoS000 Auto
Quest Property BoS304 Auto
Quest Property BoS203 Auto
Quest Property BoS301 Auto
Quest Property BoS202 Auto
Quest Property BoS302B Auto
Quest Property DNPrime_BoS304 Auto
Quest Property BoS202LinkMQ Auto
Quest Property BoS200 Auto
referencealias Property BoSRBerylliumAgitatorQuestItem Auto
Quest Property BoSM01 Auto
Quest Property BoS101 Auto
Quest Property BoSPostQuest Auto
Quest Property BoSKickOutSoft Auto
Quest Property BoS201 Auto
Quest Property BoS100 Auto

Function SoftKickOut() Native
