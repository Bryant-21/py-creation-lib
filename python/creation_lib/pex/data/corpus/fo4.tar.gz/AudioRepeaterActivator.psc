Scriptname AudioRepeaterActivator Extends ObjectReference

sound Property SoundDescriptor Auto Const
Float Property delayMin Auto Const
Float Property delayMax Auto Const

Float Function GetWaitTime() Native
Event OnCellAttach()
EndEvent

Event OnCellDetach()
EndEvent

Event OnTimer(Int aiTimerID)
EndEvent
