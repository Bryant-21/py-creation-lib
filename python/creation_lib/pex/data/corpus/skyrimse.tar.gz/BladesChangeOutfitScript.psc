Scriptname BladesChangeOutfitScript Extends ReferenceAlias

String Function GetState() Native
Function GotoState(String newState) Native
Function OnLoad() Native
