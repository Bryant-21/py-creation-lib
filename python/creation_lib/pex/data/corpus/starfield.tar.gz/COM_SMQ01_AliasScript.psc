Scriptname COM_SMQ01_AliasScript Extends ReferenceAlias

Int Property CompletionStage Auto
globalvariable Property COM_SMQ01_GenetagsSpawnTotal Auto
miscobject Property COM_SMQ01_Genetag Auto
Int Property GenetagObjectiveStartStage Auto
Int Property GenetagObjIndex Auto
Int Property SpawnBoss Auto
Int Property GenetagSearchStage Auto
globalvariable Property COM_SMQ01_GenetagsCollected Auto
globalvariable Property COM_SMQ01_GenetagsTotal Auto

Function OnAliasInit() Native
Function OnItemAdded(form akBaseItem, Int aiItemCount, objectreference akItemReference, objectreference akSourceContainer, Int aiTransferReason) Native
Function RegisterPlayerForGentagPickup() Native
Function SpawnBossOrEnd() Native
