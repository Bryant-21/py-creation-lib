Scriptname AliasOnItemAddedSetGlobal Extends ReferenceAlias

formlist Property UniqueResourcesOrganicList Auto
Int Property StageToSet Auto
quest Property QuestToSetStage Auto
globalvariable Property GlobalToSet Auto
Float Property ValueToSet Auto

Function OnItemAdded(form akBaseItem, Int aiItemCount, objectreference akItemReference, objectreference akSourceContainer, Int aiTransferReason) Native
