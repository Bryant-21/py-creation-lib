Scriptname CompanionOnDismissScript Extends Actor

Int Property StageToSet Auto
quest Property QuestWithStageToSet Auto

Event OnInit()
EndEvent
