Scriptname AbLegendaryExplodeScript Extends ActiveMagicEffect

explosion Property DeathExplosion Auto Const

Event OnDeath(actor akKiller)
EndEvent
