Scriptname BoSR01Script Extends Quest

locationalias Property Dungeon Auto Const
Int Property StageToSet Auto Const
