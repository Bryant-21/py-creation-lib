Scriptname Curve Extends Form

Float Function GetValueAt(Float afInput) Native
Float[] Function GetValues(Float[] Inputs) Native
Bool Function HasValueAt(Float afInput) Native
