Scriptname DefaultAliasOnUnequipped Extends DefaultAlias

Bool Property PlayerUnequippedOnly Auto Const
referencealias[] Property UnequippedByAliases Auto Const
objectreference[] Property UnequippedByReferences Auto Const
faction[] Property UnequippedByFactions Auto Const

Event OnUnequipped(actor akActor)
EndEvent
