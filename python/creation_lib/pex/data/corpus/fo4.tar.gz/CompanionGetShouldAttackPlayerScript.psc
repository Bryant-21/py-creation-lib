Scriptname CompanionGetShouldAttackPlayerScript Extends ActiveMagicEffect

Event OnEffectStart(actor akTarget, actor akCaster)
EndEvent
