Scriptname BYOH_TIF__01003E2D Extends TopicInfo

referencealias Property MarkarthHouse Auto
referencealias Property SolitudeHouse Auto
referencealias Property RiftenHouse Auto
referencealias Property WindhelmHouse Auto
referencealias Property WhiterunHouse Auto

Function Fragment_0(ObjectReference akSpeakerRef) Native
String Function GetState() Native
Function GotoState(String newState) Native
