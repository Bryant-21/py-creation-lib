Scriptname DefaultAliasOnCellLoad Extends DefaultAlias

Event OnCellLoad()
EndEvent
