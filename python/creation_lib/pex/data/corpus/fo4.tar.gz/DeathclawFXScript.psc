Scriptname DeathclawFXScript Extends Actor

armor Property SkinDeathclawCrippleLArm Auto
actorvalue Property DeathclawAttackConditionAV Auto
actorvalue Property DeathclawEnduranceConditionAV Auto
armor Property SkinDeathclawCrippleRArm Auto
impactdataset Property NPCDeathclawFootWoodRunImpactSet Auto

Event OnCripple(actorvalue akActorValue, Bool abCrippled)
EndEvent

Event OnHit(objectreference akTarget, objectreference akAggressor, form akSource, projectile akProjectile, Bool abPowerAttack, Bool abSneakAttack, Bool abBashAttack, Bool abHitBlocked, String asMaterialName)
EndEvent

Event OnLoad()
EndEvent

Event OnUnload()
EndEvent
