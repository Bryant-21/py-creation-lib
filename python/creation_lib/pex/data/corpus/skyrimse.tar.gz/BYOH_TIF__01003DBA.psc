Scriptname BYOH_TIF__01003DBA Extends TopicInfo

Function Fragment_1(ObjectReference akSpeakerRef) Native
String Function GetState() Native
Function GotoState(String newState) Native
