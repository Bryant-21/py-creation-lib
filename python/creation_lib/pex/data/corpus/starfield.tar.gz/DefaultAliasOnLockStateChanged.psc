Scriptname DefaultAliasOnLockStateChanged Extends DefaultAliasParent

Bool Property CheckForUnlock Auto

Event OnLockStateChanged()
EndEvent
