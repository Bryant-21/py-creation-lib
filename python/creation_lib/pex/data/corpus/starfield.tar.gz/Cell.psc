Scriptname Cell Extends Form

Function EnableFastTravel(Bool abEnable = true) Native
actorbase Function GetActorOwner() Native
faction Function GetFactionOwner() Native
objectreference Function GetParentRef() Native
Bool Function IsAttached() Native
Bool Function IsInterior() Native
Bool Function IsLoaded() Native
Function Reset() Native
Function SetActorOwner(actorbase akActor) Native
Function SetFactionOwner(faction akFaction) Native
Function SetFogColor(Int aiNearRed, Int aiNearGreen, Int aiNearBlue, Int aiFarRed, Int aiFarGreen, Int aiFarBlue) Native
Function SetFogPlanes(Float afNear, Float afFar) Native
Function SetFogPower(Float afPower) Native
Function SetGravityScale(Float aScale) Native
Function SetOffLimits(Bool abOffLimits) Native
Function SetPublic(Bool abPublic = true) Native
