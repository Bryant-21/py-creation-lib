Scriptname ccOTMFO4001:Fragments:Quests:QF_ccOTMFO4001_VB_010000E8 Extends Quest

referencealias Property Alias_Soldier02 Auto Const
referencealias Property Alias_Soldier01 Auto Const
refcollectionalias Property Alias_EnclaveHQTroops Auto Const
Quest Property ccOTMFO4001_Quest Auto Const
refcollectionalias Property Alias_VertibirdCrew Auto Const

Function Fragment_Stage_0000_Item_00() Native
Function Fragment_Stage_0100_Item_00() Native
Function Fragment_Stage_10000_Item_00() Native
