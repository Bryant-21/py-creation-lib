Scriptname CompanionAffinityScript Extends Actor

Struct AngerEvent
    affinityevent EventCausingAnger
    globalvariable AngerReason
    globalvariable AngerLevel
EndStruct

sq_companionsscript Property SQ_Companions Auto
angerevent[] Property AngerEventData Auto

Function OnAffinityEvent(affinityevent akAffinityEvent, actorvalue akActorValue, globalvariable akReactionValue, objectreference akTarget) Native
Function OnInit() Native
Bool Function Trace(ScriptObject CallingObject, String asTextToPrint, Int aiSeverity, String MainLogName, String SubLogName, Bool bShowNormalTrace, Bool bShowWarning, Bool bPrefixTraceWithLogNames) Native
Bool Function warning(ScriptObject CallingObject, String asTextToPrint, Int aiSeverity, String MainLogName, String SubLogName, Bool bShowNormalTrace, Bool bShowWarning, Bool bPrefixTraceWithLogNames) Native
