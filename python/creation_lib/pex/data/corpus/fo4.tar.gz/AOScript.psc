Scriptname AOScript Extends Quest

Struct AO_Dogmeat_Find_Datum
    globalvariable NextAllowed
    globalvariable Type
    globalvariable CoolDown
EndStruct

Int Property iTimerID_Dogmeat_Find Auto
keyword Property AO_Dogmeat_Find_Start Auto
Int Property iTimerID_Companion_Search Auto
ao_dogmeat_find_datum[] Property AO_Dogmeat_Find_Data Auto
keyword[] Property TempAOKeywords Auto
globalvariable Property AO_Dogmeat_Find_Allowed Auto
keyword Property AO_Finished Auto
keyword Property AO_Companion_Search_Start Auto
globalvariable Property AO_Companion_Search_Allowed Auto
Float Property TimerInterval_Companion_Search Auto
keyword Property AOKeywordForLockDoors Auto
referencealias Property Companion Auto
keyword Property AO_Dogmeat_FindItem_Commanded_Start Auto
keyword Property AO_Dogmeat_FindContainer_Commanded_Start Auto
Float Property TimerInterval_Dogmeat_Find Auto
keyword Property AO_Dogmeat_FindHostile_Commanded_Start Auto
keyword Property TempAOStart Auto
formlist Property TempAOList Auto
referencealias Property DogmeatCompanion Auto

Function DogmeatFindEventEnded(globalvariable AO_Dogmeat_FindType_GLOBAL) Native
Function DogmeatFindEventStarted() Native
Function DogmeatLoading(Bool isDogmeatLoading = true) Native
Function FlagObjectAliasFinished(referencealias AliasToFlagWithKeyword) Global Native
Function FlagObjectFinished(objectreference ObjectToFlagWithKeyword) Global Native
AOScript Function GetScript() Global Native
Function HandleTimer_Companion_Search() Native
Function HandleTimer_DogmeatFind() Native
Function HandleTimer_DogmeatFindCoolDown() Native
Event OnInit()
EndEvent

Event OnTimer(Int aiTimerID)
EndEvent

Bool Function SendDogmeatFindContainerStoryManagerEvent() Native
Bool Function SendDogmeatFindHostileStoryManagerEvent() Native
Bool Function SendDogmeatFindItemStoryManagerEvent() Native
